# Retrofit / OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn retrofit2.**
-keepattributes Signature, InnerClasses, EnclosingMethod
-keepattributes RuntimeVisibleAnnotations, RuntimeVisibleParameterAnnotations
-keepclassmembers,allowshrinking,allowobfuscation interface * {
    @retrofit2.http.* <methods>;
}

# Moshi
-dontwarn com.squareup.moshi.**
-keep class com.squareup.moshi.** { *; }

# Room
-keep class * extends androidx.room.RoomDatabase { <init>(); }

# Kotlin coroutines
-dontwarn kotlinx.coroutines.**
