package ng.jamb.threehundredplus.data

import android.content.Context
import android.net.Uri
import com.squareup.moshi.JsonReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import ng.jamb.threehundredplus.data.db.AttemptEntity
import ng.jamb.threehundredplus.data.db.JambDatabase
import ng.jamb.threehundredplus.data.db.MistakeEntity
import ng.jamb.threehundredplus.data.db.MockEntity
import ng.jamb.threehundredplus.data.db.QuestionEntity
import ng.jamb.threehundredplus.data.db.ScheduleTaskEntity
import ng.jamb.threehundredplus.data.db.StudySessionEntity
import ng.jamb.threehundredplus.data.db.TopicEntity
import ng.jamb.threehundredplus.data.db.TopicStatus
import ng.jamb.threehundredplus.data.db.XpLedgerEntity
import ng.jamb.threehundredplus.data.prefs.AppSettings
import ng.jamb.threehundredplus.data.prefs.SettingsStore
import ng.jamb.threehundredplus.domain.SubjectCatalogue
import okio.Buffer

data class BackupSummary(
    val topics: Int,
    val questions: Int,
    val mocks: Int,
    val attempts: Int,
    val mistakes: Int,
    val schedule: Int,
    val sessions: Int,
    val xpRows: Int,
    val includedApiKey: Boolean
)

sealed class RestoreResult {
    data class Success(val summary: BackupSummary) : RestoreResult()
    data class Failure(val reason: String) : RestoreResult()
}

class BackupManager(
    private val context: Context,
    private val db: JambDatabase,
    private val settings: SettingsStore
) {
    companion object {
        const val FORMAT = "jamb300plus.backup.v1"
    }

    // ---------------- export ----------------

    suspend fun export(uri: Uri, current: AppSettings): BackupSummary = withContext(Dispatchers.IO) {
        val topics = db.topicDao().getAll()
        val questions = db.questionDao().totalCount()
        val mocks = db.mockDao().getAll()
        val schedule = db.scheduleDao().getFrom(0)
        val attempts = db.attemptDao().getAll()
        val mistakes = db.mistakeDao().getAll()
        val sessions = db.sessionDao().getAll()

        val sb = StringBuilder()
        sb.append("{\n")
        sb.append("  \"format\": \"").append(FORMAT).append("\",\n")
        sb.append("  \"version\": 1,\n")
        sb.append("  \"app\": \"JAMB 300+\",\n")
        sb.append("  \"includeApiKey\": ").append(current.includeApiKeyInBackup).append(",\n")
        sb.append("  \"apiKey\": ")
        if (current.includeApiKeyInBackup && current.apiKey.isNotBlank()) {
            sb.append('"').append(Json.escape(current.apiKey)).append('"')
        } else {
            sb.append("null")
        }
        sb.append(",\n")

        sb.append("  \"settings\": {")
        sb.append("\"onboardingDone\": ").append(current.onboardingDone).append(", ")
        sb.append("\"selectedSubjects\": [").append(current.selectedSubjects.joinToString(",") { "\"${Json.escape(it)}\"" }).append("], ")
        sb.append("\"targetScore\": ").append(current.targetScore).append(", ")
        sb.append("\"themeMode\": \"${Json.escape(current.themeMode)}\", ")
        sb.append("\"remoteConfigUrl\": \"${Json.escape(current.remoteConfigUrl)}\", ")
        sb.append("\"reminderLeadMinutes\": ").append(current.reminderLeadMinutes).append(", ")
        sb.append("\"remindersEnabled\": ").append(current.remindersEnabled).append(", ")
        sb.append("\"slotTimes\": [").append(current.slotTimes.joinToString(",") { "\"${Json.escape(it)}\"" }).append("], ")
        sb.append("\"examDateOverride\": \"${Json.escape(current.examDateOverride)}\", ")
        sb.append("\"examDateEpochMs\": ").append(current.examDateEpochMs).append(", ")
        sb.append("\"cachedConfigJson\": \"${Json.escape(current.cachedConfigJson)}\"")
        sb.append("},\n")

        sb.append("  \"topics\": [")
        topics.forEachIndexed { i, t ->
            if (i > 0) sb.append(',')
            sb.append("{\"subject\":\"").append(Json.escape(t.subject)).append("\",")
            sb.append("\"fingerprint\":\"").append(Json.escape(t.fingerprint)).append("\",")
            sb.append("\"title\":\"").append(Json.escape(t.title)).append("\",")
            sb.append("\"orderIndex\":").append(t.orderIndex).append(',')
            sb.append("\"status\":\"").append(Json.escape(t.status)).append("\",")
            sb.append("\"isCustom\":").append(t.isCustom).append('}')
        }
        sb.append("],\n")

        sb.append("  \"schedule\": [")
        schedule.forEachIndexed { i, t ->
            if (i > 0) sb.append(',')
            sb.append("{\"dateEpochDay\":").append(t.dateEpochDay)
            sb.append(",\"slotIndex\":").append(t.slotIndex)
            sb.append(",\"subject\":\"").append(Json.escape(t.subject)).append('"')
            sb.append(",\"topicId\":").append(t.topicId ?: 0)
            sb.append(",\"topicTitle\":\"").append(Json.escape(t.topicTitle)).append('"')
            sb.append(",\"type\":\"").append(Json.escape(t.type)).append('"')
            sb.append(",\"done\":").append(t.done)
            sb.append(",\"skipped\":").append(t.skipped)
            sb.append(",\"createdAt\":").append(t.createdAt).append('}')
        }
        sb.append("],\n")

        sb.append("  \"mistakes\": [")
        mistakes.forEachIndexed { i, m ->
            if (i > 0) sb.append(',')
            sb.append("{\"questionId\":").append(m.questionId)
            sb.append(",\"subject\":\"").append(Json.escape(m.subject)).append('"')
            sb.append(",\"timesMissed\":").append(m.timesMissed)
            sb.append(",\"timesReviewed\":").append(m.timesReviewed)
            sb.append(",\"firstMissedAt\":").append(m.firstMissedAt)
            sb.append(",\"lastMissedAt\":").append(m.lastMissedAt)
            sb.append(",\"nextReviewAt\":").append(m.nextReviewAt)
            sb.append(",\"reviewStage\":").append(m.reviewStage)
            sb.append(",\"resolved\":").append(m.resolved).append('}')
        }
        sb.append("],\n")

        sb.append("  \"sessions\": [")
        sessions.forEachIndexed { i, s ->
            if (i > 0) sb.append(',')
            sb.append("{\"startedAt\":").append(s.startedAt)
            sb.append(",\"endedAt\":").append(s.endedAt)
            sb.append(",\"minutes\":").append(s.minutes)
            sb.append(",\"subject\":").append(s.subject?.let { "\"${Json.escape(it)}\"" } ?: "null")
            sb.append(",\"topicTitle\":").append(s.topicTitle?.let { "\"${Json.escape(it)}\"" } ?: "null")
            sb.append(",\"source\":\"").append(Json.escape(s.source)).append("\"}")
        }
        sb.append("],\n")

        sb.append("  \"xp\": {")
        val xpRows = db.xpDao().getAll()
        sb.append("\"totalXp\": ").append(xpRows.sumOf { it.xp }).append(',')
        sb.append("\"entries\": [")
        xpRows.forEachIndexed { i, e ->
            if (i > 0) sb.append(',')
            sb.append("{\"day\":").append(e.dayEpoch).append(",\"reason\":\"").append(Json.escape(e.reason)).append("\",\"xp\":").append(e.xp).append('}')
        }
        sb.append("]},")

        sb.append("  \"attemptsCount\": ").append(attempts.size).append(",\n")
        sb.append("  \"mocksCount\": ").append(mocks.size).append(",\n")
        sb.append("  \"cachedQuestions\": ").append(questions).append("\n")
        sb.append("}\n")

        context.contentResolver.openOutputStream(uri)?.use { out ->
            out.write(sb.toString().toByteArray(Charsets.UTF_8))
        } ?: throw IllegalStateException("Could not open the chosen file for writing.")

        BackupSummary(
            topics = topics.size,
            questions = questions,
            mocks = mocks.size,
            attempts = attempts.size,
            mistakes = mistakes.size,
            schedule = schedule.size,
            sessions = sessions.size,
            xpRows = xpRows.size,
            includedApiKey = current.includeApiKeyInBackup && current.apiKey.isNotBlank()
        )
    }

    // ---------------- import ----------------

    suspend fun import(uri: Uri, current: AppSettings): RestoreResult = withContext(Dispatchers.IO) {
        val text = try {
            context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
        } catch (_: Exception) {
            null
        } ?: return@withContext RestoreResult.Failure("The selected file could not be opened.")

        if (text.isBlank() || text.length > 20_000_000) {
            return@withContext RestoreResult.Failure("The file is empty or too large to be a valid backup.")
        }

        val root = try {
            JsonReader.of(Buffer().writeUtf8(text)).also { it.isLenient = true }
        } catch (_: Exception) {
            return@withContext RestoreResult.Failure("The file is not readable JSON.")
        }

        try {
            if (root.peek() != JsonReader.Token.BEGIN_OBJECT) {
                return@withContext RestoreResult.Failure("The file is not a JAMB 300+ backup document.")
            }
            root.beginObject()
            var format: String? = null
            var version = 0
            var apiKey: String? = null
            var includeKey = false
            var settingsJson: String? = null
            val topics = ArrayList<TopicEntity>()
            val schedule = ArrayList<ScheduleTaskEntity>()
            val mistakes = ArrayList<MistakeEntity>()
            val sessions = ArrayList<StudySessionEntity>()

            while (root.hasNext()) {
                when (root.nextName()) {
                    "format" -> format = root.nextStringOrNull()
                    "version" -> version = root.nextIntSafe()
                    "apiKey" -> apiKey = root.nextStringOrNull()
                    "includeApiKey" -> includeKey = root.nextBooleanSafe()
                    "settings" -> settingsJson = root.readRawObject()
                    "topics" -> readTopicArray(root, topics)
                    "schedule" -> readScheduleArray(root, schedule)
                    "mistakes" -> readMistakeArray(root, mistakes)
                    "sessions" -> readSessionArray(root, sessions)
                    else -> root.skipValue()
                }
            }
            root.endObject()

            if (format != FORMAT) {
                return@withContext RestoreResult.Failure(
                    "Unsupported backup format. This file was not produced by JAMB 300+."
                )
            }
            if (version != 1) {
                return@withContext RestoreResult.Failure("Unsupported backup version ($version).")
            }

            // Validate parsed rows before touching anything.
            val validStatuses = TopicStatus.entries.map { it.name }.toSet()
            val goodTopics = topics.filter { it.subject.isNotBlank() && it.title.isNotBlank() }
            val goodSchedule = schedule.filter { it.subject.isNotBlank() }
            val goodMistakes = mistakes.filter { it.questionId > 0 }
            val goodSessions = sessions.filter { it.minutes in 0..(60 * 24) }

            if (goodTopics.isEmpty() && goodSchedule.isEmpty() && goodMistakes.isEmpty() && goodSessions.isEmpty()) {
                return@withContext RestoreResult.Failure("The backup contained no restorable data. Nothing was changed.")
            }

            if (goodTopics.isNotEmpty()) {
                // Everything was validated above, so applying now cannot corrupt the store.
                db.topicDao().deleteAll()
                db.topicDao().insertAll(
                    goodTopics.map { it.copy(status = if (it.status in validStatuses) it.status else TopicStatus.NOT_STARTED.name) }
                )
            }
            if (goodSchedule.isNotEmpty()) {
                db.scheduleDao().clear()
                db.scheduleDao().insertAll(goodSchedule)
            }
            if (goodMistakes.isNotEmpty()) {
                db.mistakeDao().clear()
                db.mistakeDao().insertAll(goodMistakes)
            }
            if (goodSessions.isNotEmpty()) {
                db.sessionDao().clear()
                db.sessionDao().insertAll(goodSessions)
            }

            settingsJson?.let { raw ->
                val merged = parseSettings(raw, current, apiKey, includeKey)
                if (merged != null) settings.applyAll(merged)
            }

            RestoreResult.Success(
                BackupSummary(
                    topics = goodTopics.size,
                    questions = 0,
                    mocks = 0,
                    attempts = 0,
                    mistakes = goodMistakes.size,
                    schedule = goodSchedule.size,
                    sessions = goodSessions.size,
                    xpRows = 0,
                    includedApiKey = includeKey && !apiKey.isNullOrBlank()
                )
            )
        } catch (_: Exception) {
            RestoreResult.Failure("The backup file is malformed. Nothing was changed.")
        }
    }

    private fun parseSettings(
        raw: String,
        current: AppSettings,
        apiKey: String?,
        includeKey: Boolean
    ): AppSettings? = try {
        val r = JsonReader.of(Buffer().writeUtf8(raw))
        r.isLenient = true
        var s = current
        r.beginObject()
        while (r.hasNext()) {
            when (r.nextName()) {
                "onboardingDone" -> s = s.copy(onboardingDone = r.nextBooleanSafe())
                "selectedSubjects" -> {
                    val list = r.readStringArray()
                    if (list.isNotEmpty()) {
                        val valid = list.filter { SubjectCatalogue.byId.containsKey(it) }.distinct()
                        if (valid.contains(SubjectCatalogue.ENGLISH)) {
                            val three = valid.filter { it != SubjectCatalogue.ENGLISH }.take(3)
                            s = s.copy(selectedSubjects = listOf(SubjectCatalogue.ENGLISH) + three)
                        }
                    }
                }
                "targetScore" -> s = s.copy(targetScore = r.nextIntSafe().coerceIn(1, 400))
                "themeMode" -> s = s.copy(themeMode = if (r.nextStringOrNull() == "LIGHT") "LIGHT" else "DARK")
                "remoteConfigUrl" -> s = s.copy(remoteConfigUrl = r.nextStringOrNull() ?: "")
                "reminderLeadMinutes" -> s = s.copy(reminderLeadMinutes = r.nextIntSafe().coerceIn(0, 120))
                "remindersEnabled" -> s = s.copy(remindersEnabled = r.nextBooleanSafe())
                "slotTimes" -> {
                    val list = r.readStringArray()
                    val ok = list.filter { it.contains("-") && it.length >= 11 }
                    if (ok.isNotEmpty()) s = s.copy(slotTimes = ok)
                }
                "examDateOverride" -> s = s.copy(examDateOverride = r.nextStringOrNull() ?: "")
                "examDateEpochMs" -> s = s.copy(examDateEpochMs = r.nextIntSafe().toLong())
                "cachedConfigJson" -> s = s.copy(cachedConfigJson = r.nextStringOrNull() ?: "")
                else -> r.skipValue()
            }
        }
        r.endObject()
        // The API key is only restored when the backup explicitly opted in AND the user
        // is importing it deliberately.
        if (includeKey && !apiKey.isNullOrBlank()) s.copy(apiKey = apiKey) else s.copy(apiKey = current.apiKey)
    } catch (_: Exception) {
        null
    }

    // -------- Moshi reader helpers (never throw) --------

    private fun com.squareup.moshi.JsonReader.nextStringOrNull(): String? = try {
        when (peek()) {
            JsonReader.Token.STRING, JsonReader.Token.NUMBER, JsonReader.Token.BOOLEAN -> nextString()
            JsonReader.Token.NULL -> { nextNull<Unit?>(); null }
            else -> { skipValue(); null }
        }
    } catch (_: Exception) { runCatching { skipValue() }; null }

    private fun com.squareup.moshi.JsonReader.nextIntSafe(): Int = try {
        when (peek()) {
            JsonReader.Token.NUMBER -> nextInt()
            JsonReader.Token.STRING -> nextString().trim().toIntOrNull() ?: 0
            else -> { skipValue(); 0 }
        }
    } catch (_: Exception) { runCatching { skipValue() }; 0 }

    private fun com.squareup.moshi.JsonReader.nextBooleanSafe(): Boolean = try {
        when (peek()) {
            JsonReader.Token.BOOLEAN -> nextBoolean()
            JsonReader.Token.STRING -> nextString().trim().equals("true", true)
            else -> { skipValue(); false }
        }
    } catch (_: Exception) { runCatching { skipValue() }; false }

    private fun com.squareup.moshi.JsonReader.readStringArray(): List<String> = try {
        if (peek() != JsonReader.Token.BEGIN_ARRAY) { skipValue(); emptyList() }
        else {
            val out = ArrayList<String>()
            beginArray()
            while (hasNext()) out.add(nextStringOrNull().orEmpty())
            endArray()
            out
        }
    } catch (_: Exception) { runCatching { skipValue() }; emptyList() }

    private fun com.squareup.moshi.JsonReader.readRawObject(): String? = try {
        if (peek() != JsonReader.Token.BEGIN_OBJECT) { skipValue(); null }
        else {
            val buf = Buffer()
            val w = com.squareup.moshi.JsonWriter.of(buf)
            copyCurrentValue(this, w)
            w.close()
            buf.readUtf8()
        }
    } catch (_: Exception) { runCatching { skipValue() }; null }

    private fun copyCurrentValue(r: com.squareup.moshi.JsonReader, w: com.squareup.moshi.JsonWriter) {
        when (r.peek()) {
            JsonReader.Token.BEGIN_OBJECT -> {
                w.beginObject()
                r.beginObject()
                while (r.hasNext()) {
                    w.name(r.nextName())
                    copyCurrentValue(r, w)
                }
                r.endObject()
                w.endObject()
            }
            JsonReader.Token.BEGIN_ARRAY -> {
                w.beginArray()
                r.beginArray()
                while (r.hasNext()) copyCurrentValue(r, w)
                r.endArray()
                w.endArray()
            }
            JsonReader.Token.STRING -> w.value(r.nextString())
            JsonReader.Token.NUMBER -> w.value(r.nextString())
            JsonReader.Token.BOOLEAN -> w.value(r.nextBoolean())
            JsonReader.Token.NULL -> { r.nextNull<Unit?>(); w.nullValue() }
            else -> { r.skipValue(); w.nullValue() }
        }
    }

    private fun readTopicArray(r: com.squareup.moshi.JsonReader, out: MutableList<TopicEntity>) = try {
        if (r.peek() != JsonReader.Token.BEGIN_ARRAY) r.skipValue() else {
            r.beginArray()
            while (r.hasNext()) {
                if (r.peek() != JsonReader.Token.BEGIN_OBJECT) { r.skipValue(); continue }
                var subject = ""; var fp = ""; var title = ""; var order = 0
                var status = TopicStatus.NOT_STARTED.name; var custom = false
                r.beginObject()
                while (r.hasNext()) {
                    when (r.nextName()) {
                        "subject" -> subject = r.nextStringOrNull().orEmpty()
                        "fingerprint" -> fp = r.nextStringOrNull().orEmpty()
                        "title" -> title = r.nextStringOrNull().orEmpty()
                        "orderIndex" -> order = r.nextIntSafe()
                        "status" -> status = r.nextStringOrNull() ?: TopicStatus.NOT_STARTED.name
                        "isCustom" -> custom = r.nextBooleanSafe()
                        else -> r.skipValue()
                    }
                }
                r.endObject()
                out.add(
                    TopicEntity(
                        subject = subject,
                        fingerprint = if (fp.isNotBlank()) fp else SubjectCatalogue.fingerprint(subject, title),
                        title = title,
                        orderIndex = order,
                        status = status,
                        isCustom = custom
                    )
                )
            }
            r.endArray()
        }
    } catch (_: Exception) { runCatching { r.skipValue() } }

    private fun readScheduleArray(r: com.squareup.moshi.JsonReader, out: MutableList<ScheduleTaskEntity>) = try {
        if (r.peek() != JsonReader.Token.BEGIN_ARRAY) r.skipValue() else {
            r.beginArray()
            while (r.hasNext()) {
                if (r.peek() != JsonReader.Token.BEGIN_OBJECT) { r.skipValue(); continue }
                var day = 0L; var slot = 0; var subject = ""; var topicId = 0L
                var title = ""; var type = "LEARN"; var done = false; var skipped = false; var created = 0L
                r.beginObject()
                while (r.hasNext()) {
                    when (r.nextName()) {
                        "dateEpochDay" -> day = r.nextIntSafe().toLong()
                        "slotIndex" -> slot = r.nextIntSafe()
                        "subject" -> subject = r.nextStringOrNull().orEmpty()
                        "topicId" -> topicId = r.nextIntSafe().toLong()
                        "topicTitle" -> title = r.nextStringOrNull().orEmpty()
                        "type" -> type = r.nextStringOrNull() ?: "LEARN"
                        "done" -> done = r.nextBooleanSafe()
                        "skipped" -> skipped = r.nextBooleanSafe()
                        "createdAt" -> created = r.nextIntSafe().toLong()
                        else -> r.skipValue()
                    }
                }
                r.endObject()
                out.add(
                    ScheduleTaskEntity(
                        dateEpochDay = day,
                        slotIndex = slot,
                        subject = subject,
                        topicId = topicId.takeIf { it > 0 },
                        topicTitle = title,
                        type = type,
                        done = done,
                        skipped = skipped,
                        createdAt = created
                    )
                )
            }
            r.endArray()
        }
    } catch (_: Exception) { runCatching { r.skipValue() } }

    private fun readMistakeArray(r: com.squareup.moshi.JsonReader, out: MutableList<MistakeEntity>) = try {
        if (r.peek() != JsonReader.Token.BEGIN_ARRAY) r.skipValue() else {
            r.beginArray()
            while (r.hasNext()) {
                if (r.peek() != JsonReader.Token.BEGIN_OBJECT) { r.skipValue(); continue }
                var qid = 0L; var subject = ""; var missed = 0; var reviewed = 0
                var first = 0L; var last = 0L; var next = 0L; var stage = 0; var resolved = false
                r.beginObject()
                while (r.hasNext()) {
                    when (r.nextName()) {
                        "questionId" -> qid = r.nextIntSafe().toLong()
                        "subject" -> subject = r.nextStringOrNull().orEmpty()
                        "timesMissed" -> missed = r.nextIntSafe()
                        "timesReviewed" -> reviewed = r.nextIntSafe()
                        "firstMissedAt" -> first = r.nextIntSafe().toLong()
                        "lastMissedAt" -> last = r.nextIntSafe().toLong()
                        "nextReviewAt" -> next = r.nextIntSafe().toLong()
                        "reviewStage" -> stage = r.nextIntSafe()
                        "resolved" -> resolved = r.nextBooleanSafe()
                        else -> r.skipValue()
                    }
                }
                r.endObject()
                out.add(
                    MistakeEntity(
                        questionId = qid,
                        subject = subject,
                        timesMissed = missed,
                        timesReviewed = reviewed,
                        firstMissedAt = first,
                        lastMissedAt = last,
                        nextReviewAt = next,
                        reviewStage = stage,
                        resolved = resolved
                    )
                )
            }
            r.endArray()
        }
    } catch (_: Exception) { runCatching { r.skipValue() } }

    private fun readSessionArray(r: com.squareup.moshi.JsonReader, out: MutableList<StudySessionEntity>) = try {
        if (r.peek() != JsonReader.Token.BEGIN_ARRAY) r.skipValue() else {
            r.beginArray()
            while (r.hasNext()) {
                if (r.peek() != JsonReader.Token.BEGIN_OBJECT) { r.skipValue(); continue }
                var started = 0L; var ended = 0L; var minutes = 0
                var subject: String? = null; var topic: String? = null; var source = ""
                r.beginObject()
                while (r.hasNext()) {
                    when (r.nextName()) {
                        "startedAt" -> started = r.nextIntSafe().toLong()
                        "endedAt" -> ended = r.nextIntSafe().toLong()
                        "minutes" -> minutes = r.nextIntSafe()
                        "subject" -> subject = r.nextStringOrNull()
                        "topicTitle" -> topic = r.nextStringOrNull()
                        "source" -> source = r.nextStringOrNull().orEmpty()
                        else -> r.skipValue()
                    }
                }
                r.endObject()
                out.add(
                    StudySessionEntity(
                        startedAt = started,
                        endedAt = ended,
                        minutes = minutes,
                        subject = subject,
                        topicTitle = topic,
                        source = source
                    )
                )
            }
            r.endArray()
        }
    } catch (_: Exception) { runCatching { r.skipValue() } }
}
