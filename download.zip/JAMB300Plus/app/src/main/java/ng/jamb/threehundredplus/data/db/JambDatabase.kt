package ng.jamb.threehundredplus.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        SelectedSubjectEntity::class,
        TopicEntity::class,
        QuestionEntity::class,
        MockEntity::class,
        AttemptEntity::class,
        MistakeEntity::class,
        ScheduleTaskEntity::class,
        StudySessionEntity::class,
        XpLedgerEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class JambDatabase : RoomDatabase() {
    abstract fun subjectDao(): SubjectDao
    abstract fun topicDao(): TopicDao
    abstract fun questionDao(): QuestionDao
    abstract fun mockDao(): MockDao
    abstract fun attemptDao(): AttemptDao
    abstract fun mistakeDao(): MistakeDao
    abstract fun scheduleDao(): ScheduleDao
    abstract fun sessionDao(): SessionDao
    abstract fun xpDao(): XpDao

    companion object {
        @Volatile private var instance: JambDatabase? = null

        fun get(context: Context): JambDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    JambDatabase::class.java,
                    "jamb300plus.db"
                )
                    // Debug build: destructive migration keeps a fresh install always launchable.
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { instance = it }
            }
    }
}
