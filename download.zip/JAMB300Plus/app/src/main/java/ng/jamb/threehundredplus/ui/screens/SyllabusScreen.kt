package ng.jamb.threehundredplus.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import ng.jamb.threehundredplus.data.db.TopicEntity
import ng.jamb.threehundredplus.data.db.TopicStatus
import ng.jamb.threehundredplus.domain.SubjectCatalogue
import ng.jamb.threehundredplus.ui.AppViewModel
import ng.jamb.threehundredplus.ui.Bar
import ng.jamb.threehundredplus.ui.InfoCard
import ng.jamb.threehundredplus.ui.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SyllabusScreen(vm: AppViewModel, nav: NavHostController) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val overall by vm.overallPercent.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Syllabus tracker") }) }
    ) { p ->
        LazyColumn(
            modifier = Modifier.padding(p).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Search topics") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                InfoCard(
                    title = "Study headings, not the official syllabus",
                    body = "These topic structures are a study checklist bundled with the app. They are not a statement of the " +
                        "official JAMB syllabus for any year. Open Official Updates to confirm the current syllabus on jamb.gov.ng.",
                    actionLabel = "Official Updates",
                    onAction = { nav.navigate(Routes.UPDATES) }
                )
            }
            item {
                Text("Overall completion: $overall%", style = MaterialTheme.typography.titleMedium)
            }
            items(settings.selectedSubjects, key = { it }) { subject ->
                val pr = progress[subject]
                Card(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 64.dp)
                        .clickable { nav.navigate("${Routes.TOPICS}/$subject") }
                ) {
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(SubjectCatalogue.nameOf(subject), style = MaterialTheme.typography.titleSmall)
                            Text(
                                "${pr?.percent ?: 0}%",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        Bar(
                            "${pr?.done ?: 0} done • ${pr?.learning ?: 0} learning • ${pr?.needsRevision ?: 0} revise",
                            pr?.percent ?: 0
                        )
                    }
                }
            }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubjectTopicsScreen(vm: AppViewModel, subject: String, nav: NavHostController) {
    val topics by vm.topicsFor(subject).collectAsStateWithLifecycle(initialValue = emptyList())
    val progress by vm.progress.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }
    var adding by remember { mutableStateOf(false) }
    var newTitle by remember { mutableStateOf("") }

    val filtered = remember(topics, query) {
        if (query.isBlank()) topics else topics.filter { it.title.contains(query.trim(), ignoreCase = true) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(SubjectCatalogue.nameOf(subject)) },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { adding = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Add topic")
            }
        }
    ) { p ->
        LazyColumn(
            modifier = Modifier.padding(p).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            item {
                val pr = progress[subject]
                Text(
                    "${pr?.done ?: 0} of ${pr?.total ?: 0} done",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Search") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
            }
            if (filtered.isEmpty()) {
                item {
                    Text(
                        if (topics.isEmpty()) "No topics loaded yet." else "No topics match your search.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            items(filtered, key = { it.id }) { topic ->
                TopicRow(
                    topic = topic,
                    onStatus = { vm.setTopicStatus(topic, it) },
                    onDelete = if (topic.isCustom) ({ vm.deleteCustomTopic(topic.id) }) else null
                )
            }
            item { Spacer(Modifier.height(80.dp)) }
        }
    }

    if (adding) {
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text("Add custom topic") },
            text = {
                OutlinedTextField(
                    value = newTitle,
                    onValueChange = { newTitle = it },
                    label = { Text("Topic title") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.addCustomTopic(subject, newTitle)
                    newTitle = ""
                    adding = false
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("Cancel") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopicRow(
    topic: TopicEntity,
    onStatus: (TopicStatus) -> Unit,
    onDelete: (() -> Unit)?
) {
    var menuOpen by remember { mutableStateOf(false) }
    Card(
        Modifier.fillMaxWidth().heightIn(min = 56.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable { menuOpen = true }
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(topic.title, style = MaterialTheme.typography.bodyLarge)
                Text(
                    statusLabel(topic.status) + if (topic.isCustom) " • custom" else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = statusColor(topic.status)
                )
            }
            if (onDelete != null) {
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, contentDescription = "Delete topic")
                }
            }
        }
    }

    if (menuOpen) {
        AlertDialog(
            onDismissRequest = { menuOpen = false },
            title = { Text(topic.title, style = MaterialTheme.typography.titleSmall) },
            text = {
                Column {
                    TopicStatus.entries.forEach { s ->
                        TextButton(
                            onClick = { onStatus(s); menuOpen = false },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                        ) { Text(statusLabel(s.name)) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { menuOpen = false }) { Text("Close") } }
        )
    }
}

private fun statusLabel(status: String): String = when (status) {
    TopicStatus.DONE.name -> "Done"
    TopicStatus.LEARNING.name -> "Learning"
    TopicStatus.NEEDS_REVISION.name -> "Needs revision"
    else -> "Not started"
}

@Composable
private fun statusColor(status: String) = when (status) {
    TopicStatus.DONE.name -> MaterialTheme.colorScheme.secondary
    TopicStatus.LEARNING.name -> MaterialTheme.colorScheme.primary
    TopicStatus.NEEDS_REVISION.name -> MaterialTheme.colorScheme.error
    else -> MaterialTheme.colorScheme.onSurfaceVariant
}
