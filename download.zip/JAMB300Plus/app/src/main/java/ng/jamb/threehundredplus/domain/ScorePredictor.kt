package ng.jamb.threehundredplus.domain

import kotlin.math.roundToInt

/**
 * Deterministic score estimate. It never invents history: every input is a real
 * measurement taken from the user's own data, and with no data at all the estimate
 * is simply 0.
 */
data class PredictionInputs(
    val syllabusCompletionPercent: Int,
    val lastMockPercent: Int?,      // 0..100 average across subjects, or null if never sat
    val mocksTaken: Int,
    val activeStudyDays: Int,
    val currentStreakDays: Int,
    val openMistakes: Int
)

data class Prediction(
    val score: Int,                 // 0..400
    val breakdown: List<Component>,
    val target: Int,
    val hasData: Boolean
) {
    val gapToTarget: Int get() = target - score
}

data class Component(val label: String, val weight: Int, val contribution: Int)

object ScorePredictor {

    private const val W_SYLLABUS = 40
    private const val W_MOCK = 40
    private const val W_CONSISTENCY = 20

    fun predict(inputs: PredictionInputs, target: Int): Prediction {
        val parts = ArrayList<Component>()

        val syllabusScore = (inputs.syllabusCompletionPercent.coerceIn(0, 100))
        val syllabusContribution = (W_SYLLABUS * syllabusScore / 100.0).roundToInt()
        parts.add(Component("Syllabus coverage", W_SYLLABUS, syllabusContribution))

        val mockScore = inputs.lastMockPercent?.coerceIn(0, 100) ?: 0
        // Mocks only carry weight once the student has actually sat some.
        val mockWeight = when {
            inputs.mocksTaken <= 0 -> 0
            inputs.mocksTaken == 1 -> (W_MOCK * 0.5).roundToInt()
            else -> W_MOCK
        }
        val mockContribution = (mockWeight * mockScore / 100.0).roundToInt()
        parts.add(Component("Mock performance", mockWeight, mockContribution))

        val consistencyRaw = when {
            inputs.activeStudyDays <= 0 -> 0
            else -> {
                val breadth = (inputs.activeStudyDays * 100 / 30).coerceAtMost(70)
                val streak = (inputs.currentStreakDays * 100 / 14).coerceAtMost(30)
                breadth + streak
            }
        }
        val consistencyContribution = (W_CONSISTENCY * consistencyRaw / 100.0).roundToInt()
        parts.add(Component("Study consistency", W_CONSISTENCY, consistencyContribution))

        val percent = (syllabusContribution + mockContribution + consistencyContribution).coerceIn(0, 100)
        val score = (percent * 4.0).roundToInt().coerceIn(0, 400)

        return Prediction(
            score = score,
            breakdown = parts,
            target = target.coerceIn(1, 400),
            hasData = inputs.activeStudyDays > 0 || inputs.mocksTaken > 0 || inputs.syllabusCompletionPercent > 0
        )
    }
}

data class Rank(val title: String, val minXp: Int, val tier: Int)

object Ranks {
    val ALL = listOf(
        Rank("Beginner", 0, 0),
        Rank("Learner", 200, 1),
        Rank("Explorer", 600, 2),
        Rank("Achiever", 1200, 3),
        Rank("Strategist", 2400, 4),
        Rank("Scholar", 4200, 5),
        Rank("Performer", 6800, 6),
        Rank("Specialist", 10000, 7),
        Rank("300+ Champion", 14000, 8)
    )

    fun forXp(xp: Int): Rank = ALL.last { xp >= it.minXp }

    fun next(xp: Int): Rank? = ALL.firstOrNull { it.minXp > xp }
}
