package ng.jamb.threehundredplus.data.net

import com.squareup.moshi.JsonReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import okio.Buffer
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

interface AlocPrimaryService {
    @GET("api/v1/questions")
    suspend fun questions(
        @Header("X-API-Key") apiKey: String,
        @Query("subject") subject: String,
        @Query("examType") examType: String,
        @Query("year") year: String? = null
    ): ResponseBody
}

interface AlocFallbackService {
    @GET("api/v2/m")
    suspend fun questions(
        @Header("AccessToken") apiKey: String,
        @Query("subject") subject: String
    ): ResponseBody
}

data class FetchResult(val questions: List<AlocQuestionDto>, val endpoint: String)

class AlocClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(40, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val primary: AlocPrimaryService = Retrofit.Builder()
        .baseUrl("https://dev.aloc.com.ng/")
        .client(client)
        .build()
        .create(AlocPrimaryService::class.java)

    private val fallback: AlocFallbackService = Retrofit.Builder()
        .baseUrl("https://questions.aloc.com.ng/")
        .client(client)
        .build()
        .create(AlocFallbackService::class.java)

    private suspend fun call(block: suspend () -> ResponseBody): String = withContext(Dispatchers.IO) {
        try {
            val body = block()
            val raw = body.string()
            body.close()
            raw
        } catch (e: HttpException) {
            throw e.toAlocError()
        } catch (e: SocketTimeoutException) {
            throw AlocError.Timeout
        } catch (e: UnknownHostException) {
            throw AlocError.NoNetwork
        } catch (e: IOException) {
            throw AlocError.NoNetwork
        }
    }

    suspend fun fetchPrimary(apiKey: String, subjectCode: String, year: String?): String =
        call { primary.questions(apiKey, subjectCode, "jamb", year) }

    suspend fun fetchFallback(apiKey: String, subjectCode: String): String =
        call { fallback.questions(apiKey, subjectCode) }

    fun parse(body: String): List<AlocQuestionDto> = AlocJson.parse(body)

    /**
     * Parses a remote-config document. Only accepts the documented shape and only
     * keeps values that are actually present and well formed.
     */
    fun parseRemoteConfig(body: String): RemoteConfigDto? {
        if (body.isBlank() || body.length > 1_000_000) return null
        return try {
            val reader = JsonReader.of(Buffer().writeUtf8(body))
            reader.isLenient = true
            var examDate: String? = null
            var regStart: String? = null
            var regEnd: String? = null
            var syllabusVersion: String? = null
            var lastUpdated: String? = null
            var sawObject = false
            if (reader.peek() == JsonReader.Token.BEGIN_OBJECT) {
                sawObject = true
                reader.beginObject()
                while (reader.hasNext()) {
                    val key = reader.nextName()
                    when (key) {
                        "examDate" -> examDate = readScalar(reader)
                        "registrationStart" -> regStart = readScalar(reader)
                        "registrationEnd" -> regEnd = readScalar(reader)
                        "syllabusVersion" -> syllabusVersion = readScalar(reader)
                        "lastUpdated" -> lastUpdated = readScalar(reader)
                        else -> reader.skipValue()
                    }
                }
                reader.endObject()
            } else {
                reader.skipValue()
            }
            if (!sawObject) null
            else RemoteConfigDto(examDate, regStart, regEnd, syllabusVersion, lastUpdated)
        } catch (_: Exception) {
            null
        }
    }

    private fun readScalar(reader: JsonReader): String? = try {
        when (reader.peek()) {
            JsonReader.Token.STRING -> reader.nextString().trim().takeIf { it.isNotEmpty() }
            JsonReader.Token.NUMBER -> reader.nextString().trim().takeIf { it.isNotEmpty() }
            JsonReader.Token.BOOLEAN -> reader.nextString()
            JsonReader.Token.NULL -> { reader.nextNull<Unit?>(); null }
            else -> { reader.skipValue(); null }
        }
    } catch (_: Exception) { runCatching { reader.skipValue() }; null }
}

private fun HttpException.toAlocError(): AlocError = when (code()) {
    401 -> AlocError.Unauthorized
    403 -> AlocError.Forbidden
    429 -> AlocError.RateLimited
    404 -> AlocError.Empty
    in 500..599 -> AlocError.ServerError
    else -> AlocError.Generic("The question service could not complete the request (HTTP ${code()}).")
}

data class RemoteConfigDto(
    val examDate: String?,
    val registrationStart: String?,
    val registrationEnd: String?,
    val syllabusVersion: String?,
    val lastUpdated: String?
)
