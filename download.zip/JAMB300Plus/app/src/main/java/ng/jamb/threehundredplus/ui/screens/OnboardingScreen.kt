package ng.jamb.threehundredplus.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ng.jamb.threehundredplus.data.net.RemoteConfigService
import ng.jamb.threehundredplus.domain.SubjectCatalogue
import ng.jamb.threehundredplus.ui.AppViewModel
import ng.jamb.threehundredplus.ui.InfoCard
import ng.jamb.threehundredplus.ui.Pill

@Composable
fun OnboardingScreen(vm: AppViewModel) {
    val settings by vm.settings.collectAsStateWithLifecycle()

    var chosen by remember {
        mutableStateOf(setOf(SubjectCatalogue.ENGLISH, "mathematics", "physics", "chemistry"))
    }
    var target by remember { mutableStateOf(300f) }
    var step by remember { mutableStateOf(0) }

    val examText = if (settings.examDateEpochMs > 0) settings.examDateOverride
    else RemoteConfigService.UNCONFIRMED

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text("JAMB 300+", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(4.dp))
        Text(
            "Plan your revision, sit real past questions, and track progress towards your target score.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(20.dp))

        if (step == 0) {
            Text("Choose your 4 subjects", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(6.dp))
            Text(
                "Use of English is compulsory and locked. Pick exactly three more.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))

            SubjectCatalogue.ALL.forEach { def ->
                val locked = def.id == SubjectCatalogue.ENGLISH
                val isChosen = chosen.contains(def.id)
                val enabled = locked || isChosen || chosen.size < 4
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 56.dp)
                        .padding(vertical = 4.dp)
                        .clickable(enabled = enabled) {
                            chosen = if (isChosen && !locked) chosen - def.id else chosen + def.id
                        },
                    colors = CardDefaults.cardColors(
                        containerColor = when {
                            isChosen -> MaterialTheme.colorScheme.primaryContainer
                            else -> MaterialTheme.colorScheme.surfaceContainer
                        }
                    )
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(def.name, style = MaterialTheme.typography.titleSmall)
                            Text(
                                "${def.topics.size} tracked topics",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (locked) {
                            Text(
                                "REQUIRED",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        } else if (isChosen) {
                            Text("✓", fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        } else {
            Text("Target score", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(4.dp))
            Text(
                "${target.toInt()} / 400",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Slider(
                value = target,
                onValueChange = { target = it },
                onValueChangeFinished = { },
                valueRange = 100f..400f,
                steps = 29,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(16.dp))

            InfoCard(
                title = "Exam date",
                body = examText + if (settings.examDateEpochMs > 0L) {
                    "\nThis value came from the configuration source you set. Confirm it on jamb.gov.ng."
                } else {
                    "\nNo configuration source has supplied a date yet. You can set one in Settings."
                }
            )
            Spacer(Modifier.height(12.dp))
            InfoCard(
                title = "Reminders",
                body = "JAMB 300+ can alert you before each study slot. On Android 13 and newer you will be asked for " +
                    "notification permission. If notifications are blocked, the rest of the app still works normally."
            )
        }

        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (step == 1) {
                OutlinedButton(onClick = { step = 0 }, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) {
                    Text("Back")
                }
            }
            Button(
                onClick = {
                    if (step == 0) step = 1 else {
                        val list = listOf(SubjectCatalogue.ENGLISH) + (chosen - SubjectCatalogue.ENGLISH)
                        vm.completeOnboarding(list, target.toInt())
                    }
                },
                enabled = step == 1 || chosen.size == 4,
                modifier = Modifier.weight(1f).heightIn(min = 48.dp)
            ) { Text(if (step == 0) "Continue" else "Start") }
        }
        if (step == 0 && chosen.size != 4) {
            Spacer(Modifier.height(8.dp))
            Text(
                "Select ${4 - chosen.size} more subject${if (4 - chosen.size == 1) "" else "s"}.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }
        Spacer(Modifier.height(30.dp))
    }
}

