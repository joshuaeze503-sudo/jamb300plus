package ng.jamb.threehundredplus.reminders

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import ng.jamb.threehundredplus.JambApp

/** Handles the Start / Snooze / Skip notification actions. */
class ActionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val id = intent.getIntExtra(ReminderScheduler.EXTRA_ID, 0)
        val title = intent.getStringExtra(ReminderScheduler.EXTRA_TITLE).orEmpty()
        val body = intent.getStringExtra(ReminderScheduler.EXTRA_BODY).orEmpty()
        val deepLink = intent.getStringExtra(ReminderScheduler.EXTRA_DEEP_LINK)
        val slot = intent.getIntExtra(ReminderScheduler.EXTRA_SLOT, -1)
        val day = intent.getLongExtra(ReminderScheduler.EXTRA_DAY, 0L)
        val pending = goAsync()

        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val container = (app as JambApp).container
                when (intent.action) {
                    ReminderScheduler.ACTION_SNOOZE -> {
                        Notifications.cancel(app, id)
                        ReminderScheduler.snooze(app, id, title, body, deepLink, slot, day)
                    }

                    ReminderScheduler.ACTION_SKIP -> {
                        Notifications.cancel(app, id)
                        if (slot >= 0 && day > 0) {
                            val tasks = container.scheduleDao.getFrom(day)
                                .filter { it.dateEpochDay == day && it.slotIndex == slot }
                            tasks.forEach { container.scheduleDao.setSkipped(it.id) }
                        }
                        container.rescheduleReminders()
                    }

                    ReminderScheduler.ACTION_START -> {
                        Notifications.cancel(app, id)
                        val open = Intent(app, ng.jamb.threehundredplus.MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                            putExtra(ng.jamb.threehundredplus.MainActivity.EXTRA_DEEP_LINK, deepLink)
                        }
                        // Start opens the matching task in the focus timer.
                        runCatching {
                            app.startActivity(
                                open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    }
                }
                val settings = container.settingsStore.settings.first()
                if (!settings.remindersEnabled) Notifications.cancel(app, id)
            } catch (_: Exception) {
                // Notification actions are best-effort.
            } finally {
                runCatching { pending.finish() }
            }
        }
    }
}
