package ng.jamb.threehundredplus

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import ng.jamb.threehundredplus.reminders.Notifications
import ng.jamb.threehundredplus.ui.AppRoot
import ng.jamb.threehundredplus.ui.AppViewModel
import ng.jamb.threehundredplus.ui.theme.JambTheme
import ng.jamb.threehundredplus.ui.theme.ThemeMode

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Notifications.ensureChannels(this)

        val deepLink = intent?.getStringExtra(EXTRA_DEEP_LINK)

        setContent {
            val vm: AppViewModel = viewModel(factory = AppViewModel.factory(application))
            val settings by vm.settings.collectAsStateWithLifecycle()
            JambTheme(if (settings.darkTheme) ThemeMode.DARK else ThemeMode.LIGHT) {
                Surface(color = MaterialTheme.colorScheme.background) {
                    AppRoot(vm = vm, deepLink = deepLink)
                }
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }

    companion object { const val EXTRA_DEEP_LINK = "deep_link" }
}
