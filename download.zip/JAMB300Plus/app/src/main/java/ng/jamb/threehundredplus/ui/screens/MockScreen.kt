package ng.jamb.threehundredplus.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import ng.jamb.threehundredplus.data.Json
import ng.jamb.threehundredplus.data.MockStatus
import ng.jamb.threehundredplus.data.QuestionRepository
import ng.jamb.threehundredplus.domain.SubjectCatalogue
import ng.jamb.threehundredplus.ui.AppViewModel
import ng.jamb.threehundredplus.ui.EmptyState
import ng.jamb.threehundredplus.ui.InfoCard
import ng.jamb.threehundredplus.ui.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MockScreen(vm: AppViewModel, nav: NavHostController) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val active by vm.activeMock.collectAsStateWithLifecycle()
    val questions by vm.mockQuestions.collectAsStateWithLifecycle()
    val result by vm.mockResult.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()

    val report by vm.availability.collectAsStateWithLifecycle()
    var confirmStart by remember { mutableStateOf(false) }
    var confirmSubmit by remember { mutableStateOf(false) }
    var showPalette by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { vm.refreshActiveMock() }

    LaunchedEffect(result?.mockId) {
        if (result != null) {
            nav.navigate(Routes.MOCK_RESULT)
        }
    }

    val m = active
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("CBT mock") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { p ->
        if (m != null) {
            val answers = Json.readIntMap(m.answersJson)
            val flags = Json.readLongSet(m.flagsJson)
            val remainingSec = ((m.endEpochMs - now) / 1000L).coerceAtLeast(0)
            val q = questions.getOrNull(m.currentIndex)

            Column(
                Modifier
                    .padding(p)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Card(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                formatClock(remainingSec),
                                style = MaterialTheme.typography.headlineMedium,
                                color = if (remainingSec < 300) MaterialTheme.colorScheme.error
                                else MaterialTheme.colorScheme.primary
                            )
                            Text(
                                "${answers.size} of ${questions.size} answered",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        OutlinedButton(
                            onClick = { showPalette = true },
                            modifier = Modifier.heightIn(min = 44.dp)
                        ) { Text("Palette") }
                    }
                }
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { if (questions.isEmpty()) 0f else answers.size / questions.size.toFloat() },
                    modifier = Modifier.fillMaxWidth().height(6.dp)
                )
                Spacer(Modifier.height(14.dp))

                if (q == null) {
                    Text("Loading questions…", style = MaterialTheme.typography.bodyMedium)
                } else {
                    Text(
                        "${SubjectCatalogue.shortOf(q.subject)} • question ${m.currentIndex + 1} of ${questions.size}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(q.questionText, style = MaterialTheme.typography.bodyLarge)
                    Spacer(Modifier.height(6.dp))
                    MetaLine(q)
                    Spacer(Modifier.height(12.dp))

                    Json.readStringList(q.optionsJson).forEachIndexed { i, opt ->
                        val selected = answers[q.id] == i
                        Card(
                            Modifier
                                .fillMaxWidth()
                                .heightIn(min = 52.dp)
                                .padding(vertical = 4.dp)
                                .clickable { vm.setMockAnswer(q.id, i) },
                            colors = CardDefaults.cardColors(
                                containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surfaceContainerHigh
                            )
                        ) {
                            Row(Modifier.padding(12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                Text(
                                    ('A'.code + i).toString() + ".",
                                    style = MaterialTheme.typography.titleSmall,
                                    modifier = Modifier.width(28.dp)
                                )
                                Text(opt, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                                if (selected) Icon(Icons.Filled.Check, contentDescription = "Selected")
                            }
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { vm.setMockIndex(m.currentIndex - 1) },
                        enabled = m.currentIndex > 0,
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                    ) { Text("Previous") }
                    if (m.currentIndex < questions.size - 1) {
                        OutlinedButton(
                            onClick = { vm.setMockIndex(m.currentIndex + 1) },
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                        ) { Text("Next") }
                    } else {
                        OutlinedButton(
                            onClick = { confirmSubmit = true },
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                        ) { Text("Submit") }
                    }
                }
                Spacer(Modifier.height(8.dp))
                q?.let {
                    OutlinedButton(
                        onClick = { vm.toggleMockFlag(it.id) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                    ) { Text(if (it.id in flags) "Remove flag" else "Flag for review") }
                }
                Spacer(Modifier.height(24.dp))
            }
        } else {
            LazyColumn(
                modifier = Modifier.padding(p).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    InfoCard(
                        title = "Standard JAMB format",
                        body = "Use of English: 60 questions. Each of your other three subjects: 40 questions. " +
                            "180 questions in total, 2 hours, auto-submitted when time expires. Each subject is scored out " +
                            "of 100 for a maximum of 400."
                    )
                }
                item {
                    Button(
                        onClick = {
                            if (!settings.hasApiKey) {
                                vm.fetchAllMissing(vm.orderedSelected())
                            } else {
                                vm.prepareFullMock()
                            }
                        },
                        enabled = !busy.loading,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)
                    ) { Text("Prepare full mock") }
                }

                if (busy.loading) {
                    item { Text(busy.message ?: "Working…", style = MaterialTheme.typography.bodyMedium) }
                }

                val rep = report
                if (rep != null) {
                    item {
                        InfoCard(
                            title = "Real questions available",
                            body = rep.joinToString("\n") { a ->
                                "${SubjectCatalogue.nameOf(a.subject)}: ${a.cached} cached, ${a.required} needed"
                            } + "\n\nThe mock only starts when every subject has enough real questions. The app never " +
                                "substitutes generated questions."
                        )
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { vm.fetchAllMissing(rep.filter { !it.enough }.map { it.subject }) },
                                enabled = rep.any { !it.enough } && !busy.loading,
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                            ) { Text("Fetch more") }
                            OutlinedButton(
                                onClick = { vm.fetchAllMissing(vm.orderedSelected()) },
                                enabled = !busy.loading,
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                            ) { Text("Retry") }
                        }
                    }
                    if (rep.all { it.enough }) {
                        item {
                            Button(
                                onClick = { vm.startFullMock() },
                                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                            ) { Text("Start mock now") }
                        }
                    }
                }

                item {
                    Text("Resume", style = MaterialTheme.typography.titleMedium)
                }
                item {
                    Text(
                        "An interrupted mock is restored automatically when you return. Answers, flags, the question you " +
                            "were on and the remaining time are all preserved.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }

    if (confirmStart) {
        AlertDialog(
            onDismissRequest = { confirmStart = false },
            title = { Text("Start full mock?") },
            text = { Text("You will have 2 hours. The mock auto-submits when the timer reaches zero.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmStart = false
                    vm.startFullMock()
                }) { Text("Start") }
            },
            dismissButton = { TextButton(onClick = { confirmStart = false }) { Text("Cancel") } }
        )
    }

    if (confirmSubmit) {
        AlertDialog(
            onDismissRequest = { confirmSubmit = false },
            title = { Text("Submit mock?") },
            text = {
                Text("Unanswered questions will be marked wrong. This cannot be undone for this mock.")
            },
            confirmButton = {
                TextButton(onClick = { confirmSubmit = false; vm.submitActiveMock() }) { Text("Submit") }
            },
            dismissButton = { TextButton(onClick = { confirmSubmit = false }) { Text("Keep going") } }
        )
    }

    if (showPalette && active != null) {
        val answers = Json.readIntMap(active!!.answersJson)
        val flags = Json.readLongSet(active!!.flagsJson)
        AlertDialog(
            onDismissRequest = { showPalette = false },
            title = { Text("Question palette") },
            text = {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(6),
                    modifier = Modifier.height(260.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(questions.size) { i ->
                        val qq = questions[i]
                        TextButton(
                            onClick = { vm.setMockIndex(i); showPalette = false },
                            modifier = Modifier.size(40.dp)
                        ) {
                            Text(
                                if (qq.id in flags) "⚑" else "${i + 1}",
                                fontSize = androidx.compose.ui.unit.TextUnit(12f, androidx.compose.ui.unit.TextUnitType.Sp),
                                fontWeight = if (answers.containsKey(qq.id)) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPalette = false }) { Text("Close") } }
        )
    }
}

private fun formatClock(seconds: Long): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return "%d:%02d:%02d".format(h, m, s)
}
