package ng.jamb.threehundredplus.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import ng.jamb.threehundredplus.data.db.MockEntity
import ng.jamb.threehundredplus.data.db.MistakeEntity
import ng.jamb.threehundredplus.domain.Ranks
import ng.jamb.threehundredplus.domain.SubjectCatalogue
import ng.jamb.threehundredplus.ui.AppViewModel
import ng.jamb.threehundredplus.ui.Bar
import ng.jamb.threehundredplus.ui.EmptyState
import ng.jamb.threehundredplus.ui.InfoCard
import ng.jamb.threehundredplus.ui.ProgressRing
import ng.jamb.threehundredplus.ui.Routes
import ng.jamb.threehundredplus.ui.StatTile
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressScreen(vm: AppViewModel, nav: NavHostController) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val overall by vm.overallPercent.collectAsStateWithLifecycle()
    val xp by vm.xp.collectAsStateWithLifecycle()
    val rank by vm.rank.collectAsStateWithLifecycle()
    val streak by vm.streakDays.collectAsStateWithLifecycle()
    val minutes by vm.totalMinutes.collectAsStateWithLifecycle()
    val days by vm.activeDays.collectAsStateWithLifecycle()
    val prediction by vm.prediction.collectAsStateWithLifecycle()
    val mocks by vm.mockRepoSubmitted.collectAsStateWithLifecycle(initialValue = emptyList())
    val mistakes by vm.openMistakes.collectAsStateWithLifecycle(initialValue = emptyList())

    Scaffold(
        topBar = { TopAppBar(title = { Text("Progress") }) }
    ) { p ->
        LazyColumn(
            modifier = Modifier.padding(p).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Predicted score", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        ProgressRing(
                            percent = (prediction.score / 4.0).toInt(),
                            label = "of 400",
                            caption = "",
                            sizeDp = 140,
                            modifier = Modifier.height(140.dp)
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "${prediction.score} / 400",
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            if (prediction.gapToTarget > 0) "Gap to target: ${prediction.gapToTarget} points"
                            else "Target of ${prediction.target} exceeded by ${-prediction.gapToTarget} points",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "This is an estimate based on your own data — not a guaranteed JAMB score.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item { Text("How the estimate is built", style = MaterialTheme.typography.titleMedium) }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        prediction.breakdown.forEach { c ->
                            Bar(
                                "${c.label} (${c.weight}% weight)",
                                if (c.weight == 0) 0 else (c.contribution * 100 / c.weight),
                                "${c.contribution} pts"
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            if (prediction.hasData) "Based on your real study data recorded in this app."
                            else "No study data recorded yet, so the estimate is 0.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatTile("$days", "Active days", Modifier.weight(1f), MaterialTheme.colorScheme.secondary)
                    StatTile("${minutes / 60}h ${minutes % 60}m", "Study time", Modifier.weight(1f), MaterialTheme.colorScheme.tertiary)
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatTile("$xp", "XP", Modifier.weight(1f))
                    StatTile("$streak", "Streak", Modifier.weight(1f), MaterialTheme.colorScheme.secondary)
                    StatTile("${mocks.count { it.status == "SUBMITTED" }}", "Mocks", Modifier.weight(1f), MaterialTheme.colorScheme.tertiary)
                }
            }

            item { Text("Rank", style = MaterialTheme.typography.titleMedium) }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Text("${rank.title} • ${xp} XP", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(6.dp))
                        val next = Ranks.next(xp)
                        if (next != null) {
                            Bar("Next: ${next.title}", (((xp - rank.minXp) * 100) / (next.minXp - rank.minXp).coerceAtLeast(1)),
                                "${next.minXp - xp} XP to go")
                        } else {
                            Text(
                                "You have reached the highest rank. Keep your streak alive.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Ranks are awarded from XP. XP is granted once per day per activity, so repeating an action " +
                                "does not farm XP.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item { Text("Syllabus completion by subject", style = MaterialTheme.typography.titleMedium) }
            items(settings.selectedSubjects) { s ->
                val pr = progress[s]
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Text(SubjectCatalogue.nameOf(s), style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(4.dp))
                        Bar(
                            "${pr?.done ?: 0} done • ${pr?.learning ?: 0} learning • ${pr?.needsRevision ?: 0} revise",
                            pr?.percent ?: 0
                        )
                    }
                }
            }

            item {
                Text("Mistake notebook (${mistakes.size} open)", style = MaterialTheme.typography.titleMedium)
            }
            item {
                OutlinedButton(
                    onClick = { nav.navigate(Routes.MISTAKES) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) { Text("Open mistake notebook") }
            }

            item { Text("Mock history", style = MaterialTheme.typography.titleMedium) }
            if (mocks.isEmpty()) {
                item {
                    EmptyState(
                        title = "No completed mocks",
                        body = "Sit your first full mock to see scores and a subject breakdown here.",
                        actionLabel = "Go to Practice",
                        onAction = { nav.navigate(Routes.PRACTICE) }
                    )
                }
            } else {
                items(mocks) { mock ->
                    MockHistoryRow(mock) { vm.openMockResult(mock); nav.navigate(Routes.MOCK_RESULT) }
                }
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun MockHistoryRow(mock: MockEntity, onClick: () -> Unit) {
    val when0 = mock.submittedAt?.let {
        Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("d MMM yyyy, HH:mm"))
    } ?: "In progress"
    Card(Modifier.fillMaxWidth().heightIn(min = 64.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "${mock.totalScore.toInt()} / 400",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(when0, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            OutlinedButton(onClick = onClick, modifier = Modifier.heightIn(min = 44.dp)) { Text("Review") }
        }
    }
}
