package ng.jamb.threehundredplus.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import ng.jamb.threehundredplus.data.Json
import ng.jamb.threehundredplus.domain.SubjectCatalogue
import ng.jamb.threehundredplus.ui.AppViewModel
import ng.jamb.threehundredplus.ui.Bar
import ng.jamb.threehundredplus.ui.EmptyState
import ng.jamb.threehundredplus.ui.InfoCard
import ng.jamb.threehundredplus.ui.ProgressRing
import ng.jamb.threehundredplus.ui.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MockResultScreen(vm: AppViewModel, nav: NavHostController) {
    val result by vm.mockResult.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val r = result

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mock result") },
                navigationIcon = {
                    IconButton(onClick = { vm.clearMockResult(); nav.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { p ->
        if (r == null) {
            Column(Modifier.padding(p).padding(16.dp)) {
                EmptyState(
                    title = "No result open",
                    body = "Sit a mock from the Practice tab, or open a past result from Progress."
                )
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier.padding(p).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ProgressRing(
                            percent = ((r.total / 4.0) * 100).toInt().coerceIn(0, 100),
                            label = "of 400",
                            caption = "",
                            sizeDp = 112,
                            modifier = Modifier.height(112.dp)
                        )
                        Spacer(Modifier.width(18.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                "${r.total.toInt()} / 400",
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            val gap = settings.targetScore - r.total.toInt()
                            Text(
                                if (gap > 0) "$gap points below your target of ${settings.targetScore}"
                                else "${-gap} points above your target of ${settings.targetScore}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            item { Text("Subject breakdown", style = MaterialTheme.typography.titleMedium) }

            items(r.perSubject) { ss ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(SubjectCatalogue.nameOf(ss.subject), style = MaterialTheme.typography.titleSmall)
                            Text(
                                "${ss.score.toInt()} / 100",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(Modifier.height(4.dp))
                        Bar("${ss.correct} correct of ${ss.total}", ss.score.toInt(), "${ss.score.toInt()}")
                    }
                }
            }

            item {
                Text(
                    "${r.unanswered} question${if (r.unanswered == 1) "" else "s"} were left unanswered and scored as wrong.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            item {
                Text("Wrong answers (${r.wrongQuestions.size})", style = MaterialTheme.typography.titleMedium)
            }

            if (r.wrongQuestions.isEmpty()) {
                item {
                    EmptyState(
                        title = "No wrong answers",
                        body = "You answered every question you attempted correctly."
                    )
                }
            } else {
                items(r.wrongQuestions) { (q, selected) ->
                    Card(
                        Modifier.fillWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(14.dp)) {
                            Text(q.questionText, style = MaterialTheme.typography.bodyMedium)
                            Spacer(Modifier.height(6.dp))
                            MetaLine(q)
                            Spacer(Modifier.height(8.dp))
                            val opts = Json.readStringList(q.optionsJson)
                            opts.forEachIndexed { i, opt ->
                                val isCorrect = q.answerIndex == i
                                val isChosen = selected == i
                                if (isCorrect || isChosen) {
                                    Text(
                                        "${('A'.code + i)}. $opt" + when {
                                            isCorrect -> "  ✓ correct"
                                            else -> "  ✗ your answer"
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (isCorrect) MaterialTheme.colorScheme.secondary
                                        else MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                            if (q.explanation != null) {
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    "Explanation (${q.source ?: "source"}): ${q.explanation}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "The provider did not supply an explanation for this question.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            item {
                InfoCard(
                    title = "Saved to your mistake notebook",
                    body = "Every wrong answer is queued for spaced review at 1, 3, 7 and 14 days. Questions you keep missing " +
                        "are prioritised for Sunday revision.",
                    actionLabel = "Open mistakes",
                    onAction = { vm.clearMockResult(); nav.navigate(Routes.MISTAKES) }
                )
            }
            item {
                Button(
                    onClick = { vm.clearMockResult(); nav.popBackStack(Routes.PRACTICE, false) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) { Text("Done") }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

private fun Modifier.fillWidth() = this.fillMaxWidth()
