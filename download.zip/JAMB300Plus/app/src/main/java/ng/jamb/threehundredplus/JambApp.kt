package ng.jamb.threehundredplus

import android.app.Application
import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import ng.jamb.threehundredplus.data.BackupManager
import ng.jamb.threehundredplus.data.MockRepository
import ng.jamb.threehundredplus.data.QuestionRepository
import ng.jamb.threehundredplus.data.ScheduleCoordinator
import ng.jamb.threehundredplus.data.SyllabusRepository
import ng.jamb.threehundredplus.data.MistakeRepository
import ng.jamb.threehundredplus.data.StatsRepository
import ng.jamb.threehundredplus.data.SubjectSelectionRepository
import ng.jamb.threehundredplus.data.db.JambDatabase
import ng.jamb.threehundredplus.data.net.AlocClient
import ng.jamb.threehundredplus.data.net.RemoteConfigService
import ng.jamb.threehundredplus.data.prefs.SettingsStore
import ng.jamb.threehundredplus.reminders.Notifications
import java.time.LocalDate

/** Manual dependency container — no DI framework by design. */
class AppContainer(context: Context) {
    val appContext: Context = context.applicationContext
    val database: JambDatabase = JambDatabase.get(appContext)
    val settingsStore = SettingsStore(appContext)
    val alocClient = AlocClient()
    val remoteConfig = RemoteConfigService(alocClient, settingsStore)

    val questionRepo = QuestionRepository(database.questionDao(), alocClient)
    val syllabusRepo = SyllabusRepository(database.topicDao(), database.subjectDao())
    val statsRepo = StatsRepository(database.xpDao(), database.sessionDao(), database.attemptDao())
    val mistakeRepo = MistakeRepository(database.mistakeDao(), database.questionDao())
    val mockRepo = MockRepository(database.mockDao(), database.attemptDao(), questionRepo)
    val subjectRepo = SubjectSelectionRepository(database.subjectDao())
    val backupManager = BackupManager(appContext, database, settingsStore)
    val scheduleCoordinator = ScheduleCoordinator(
        appContext,
        database.scheduleDao(),
        database.topicDao(),
        database.mistakeDao(),
        settingsStore
    )

    val scheduleDao get() = database.scheduleDao()
    val topicDao get() = database.topicDao()

    suspend fun rescheduleReminders() {
        runCatching {
            val settings = settingsStore.settings.first()
            if (!settings.remindersEnabled) {
                ng.jamb.threehundredplus.reminders.ReminderScheduler.cancelAll(appContext)
                return
            }
            val tasks = database.scheduleDao().getFrom(LocalDate.now().toEpochDay())
            ng.jamb.threehundredplus.reminders.ReminderScheduler.rescheduleAll(
                appContext, tasks, settings.reminderLeadMinutes, settings.slotTimes
            )
        }
    }
}

class JambApp : Application() {

    lateinit var container: AppContainer
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        Notifications.ensureChannels(this)

        scope.launch {
            runCatching {
                val settings = container.settingsStore.settings.first()
                if (settings.onboardingDone) {
                    container.syllabusRepo.seedIfNeeded()
                    if (settings.selectedSubjects != databaseSubjectsFallback()) {
                        container.subjectRepo.save(settings.selectedSubjects)
                    }
                    container.scheduleCoordinator.ensureSchedule()
                    container.rescheduleReminders()
                }
            }
        }
    }

    private suspend fun databaseSubjectsFallback(): List<String> =
        container.database.subjectDao().get().map { it.subject }
}
