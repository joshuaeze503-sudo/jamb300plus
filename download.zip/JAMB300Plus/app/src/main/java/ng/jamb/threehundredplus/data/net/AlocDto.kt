package ng.jamb.threehundredplus.data.net

import com.squareup.moshi.JsonReader
import okio.Buffer

/**
 * DTOs for the ALOC past-question service.
 *
 * These are transport objects only — they never touch the database directly.
 * Every field is optional because the service is not guaranteed to send a
 * complete document for every question. Parsing never throws on missing data.
 */
data class AlocQuestionDto(
    val question: String,
    val options: List<String>,
    val answerIndex: Int?,
    val explanation: String?,
    val year: String?,
    val examType: String?,
    val subject: String?,
    val source: String?,
    val remoteId: String?
)

/** Thrown for user-presentable, secret-free failures. */
sealed class AlocError(val userMessage: String) : Exception(userMessage) {
    object NoNetwork : AlocError("No internet connection. Connect to a network and try again.")
    object Timeout : AlocError("The request timed out. Check your connection and try again.")
    object Unauthorized : AlocError("Your ALOC API key was rejected (401). Check the key in Settings → Question Source.")
    object Forbidden : AlocError("Access was refused (403). Your key may not have access to this subject.")
    object RateLimited : AlocError("Too many requests (429). Wait a moment before trying again.")
    object ServerError : AlocError("The question service is temporarily unavailable. Try again shortly.")
    object Malformed : AlocError("The question service returned a response the app could not read. Try again shortly.")
    object Empty : AlocError("No questions were returned for that subject.")
    object NoKey : AlocError("Add your ALOC API key in Settings → Question Source to load past questions.")
    data class Generic(val safe: String) : AlocError(safe)
}

object AlocJson {

    private const val MAX_RAW = 6_000_000

    /**
     * Parses an ALOC payload into DTOs. Understands the common shapes the service
     * uses: a bare array, {"questions":[...]}, {"data":[...]}, {"result":[...]},
     * {"data":{"questions":[...]}} and single-object variants.
     * Returns an empty list when nothing usable is found — it never throws.
     */
    fun parse(body: String): List<AlocQuestionDto> {
        if (body.isBlank() || body.length > MAX_RAW) return emptyList()
        return try {
            val reader = JsonReader.of(Buffer().writeUtf8(body))
            reader.isLenient = true
            val found = ArrayList<AlocQuestionDto>()
            readRoot(reader, found, 0)
            found.filter { it.question.isNotBlank() && it.options.size >= 2 }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun readRoot(reader: JsonReader, out: MutableList<AlocQuestionDto>, depth: Int) {
        if (depth > 6) return
        when (reader.peek()) {
            JsonReader.Token.BEGIN_ARRAY -> {
                while (reader.hasNext()) readNode(reader, out, depth + 1)
            }
            JsonReader.Token.BEGIN_OBJECT -> {
                while (reader.hasNext()) {
                    val name = reader.nextName()
                    when (name.lowercase()) {
                        "questions", "data", "result", "results", "items", "pastquestions", "past_questions", "obj" -> {
                            if (reader.peek() == JsonReader.Token.BEGIN_OBJECT || reader.peek() == JsonReader.Token.BEGIN_ARRAY) {
                                readRoot(reader, out, depth + 1)
                            } else {
                                reader.skipValue()
                            }
                        }
                        else -> reader.skipValue()
                    }
                }
            }
            else -> reader.skipValue()
        }
    }

    private fun readNode(reader: JsonReader, out: MutableList<AlocQuestionDto>, depth: Int) {
        when (reader.peek()) {
            JsonReader.Token.BEGIN_ARRAY -> while (reader.hasNext()) readNode(reader, out, depth + 1)
            JsonReader.Token.BEGIN_OBJECT -> {
                val dto = readQuestionObject(reader)
                if (dto != null) out.add(dto)
            }
            else -> reader.skipValue()
        }
    }

    private fun readQuestionObject(reader: JsonReader): AlocQuestionDto? {
        var question: String? = null
        var explanation: String? = null
        var year: String? = null
        var examType: String? = null
        var subject: String? = null
        var source: String? = null
        var remoteId: String? = null
        var answerIndex: Int? = null
        val options = ArrayList<String>()

        while (reader.hasNext()) {
            val key = reader.nextName()
            when (key.lowercase()) {
                "question", "questiontext", "question_text", "text", "stem", "body" ->
                    question = readStringOrObject(reader)

                "explanation", "solution", "rationale", "reason", "answerreason", "explanationtext" ->
                    explanation = readStringOrObject(reader)

                "year" -> year = normalizeYear(readStringOrObject(reader))
                "examyear", "sessionalyear" -> if (year == null) year = normalizeYear(readStringOrObject(reader))
                "examtype", "exam_type", "type", "exam" -> examType = readStringOrObject(reader)
                "subject", "subjectname", "subject_name" -> subject = readStringOrObject(reader)
                "source", "sourcelabel", "origin" -> source = readStringOrObject(reader)
                "id", "questionid", "question_id", "_id", "uuid", "ref" ->
                    remoteId = readStringOrObject(reader) ?: readPrimitiveAsString(reader)

                "options", "choices", "answers", "optionlist", "option_list" ->
                    readOptions(reader, options)

                "answer", "correctanswer", "correct_answer", "correctoption", "answerkey", "correct", "correctanswerindex" -> {
                    val idx = readAnswerIndex(reader)
                    if (idx != null) answerIndex = idx
                }

                "optiona", "a" -> readSingleOption(reader, options, 0)
                "optionb", "b" -> readSingleOption(reader, options, 1)
                "optionc", "c" -> readSingleOption(reader, options, 2)
                "optiond", "d" -> readSingleOption(reader, options, 3)
                "optione", "e" -> readSingleOption(reader, options, 4)

                "explanationa" -> Unit
                else -> reader.skipValue()
            }
        }

        val q = question?.trim().orEmpty()
        if (q.isEmpty()) return null
        val opts = options.map { it.trim() }.filter { it.isNotEmpty() }
        if (opts.size < 2) return null
        val idx = answerIndex?.takeIf { it in opts.indices }
        return AlocQuestionDto(
            question = q,
            options = opts,
            answerIndex = idx,
            explanation = explanation?.trim()?.takeIf { it.isNotEmpty() && it.lowercase() != "null" },
            year = year,
            examType = examType?.trim()?.takeIf { it.isNotEmpty() },
            subject = subject?.trim()?.takeIf { it.isNotEmpty() },
            source = source?.trim()?.takeIf { it.isNotEmpty() },
            remoteId = remoteId?.trim()?.takeIf { it.isNotEmpty() }
        )
    }

    private fun readStringOrObject(reader: JsonReader): String? = try {
        when (reader.peek()) {
            JsonReader.Token.STRING -> reader.nextString()
            JsonReader.Token.NUMBER -> reader.nextString()
            JsonReader.Token.BOOLEAN -> reader.nextString()
            JsonReader.Token.BEGIN_OBJECT -> {
                // Some responses wrap the string: {"value": "..."}
                var found: String? = null
                reader.beginObject()
                while (reader.hasNext()) {
                    val k = reader.nextName()
                    if (k.lowercase() in setOf("value", "text", "content", "name", "label") && found == null) {
                        found = if (reader.peek() == JsonReader.Token.STRING || reader.peek() == JsonReader.Token.NUMBER) reader.nextString() else {
                            reader.skipValue(); null
                        }
                    } else reader.skipValue()
                }
                reader.endObject()
                found
            }
            JsonReader.Token.BEGIN_ARRAY -> { reader.skipValue(); null }
            JsonReader.Token.NULL -> { reader.nextNull<Unit?>(); null }
            else -> { reader.skipValue(); null }
        }
    } catch (_: Exception) {
        runCatching { reader.skipValue() }
        null
    }

    private fun readPrimitiveAsString(reader: JsonReader): String? = try {
        when (reader.peek()) {
            JsonReader.Token.STRING, JsonReader.Token.NUMBER, JsonReader.Token.BOOLEAN -> reader.nextString()
            else -> { reader.skipValue(); null }
        }
    } catch (_: Exception) { runCatching { reader.skipValue() }; null }

    private fun readOptions(reader: JsonReader, out: MutableList<String>) {
        try {
            when (reader.peek()) {
                JsonReader.Token.BEGIN_ARRAY -> {
                    reader.beginArray()
                    while (reader.hasNext()) {
                        out.add(readOptionEntry(reader))
                    }
                    reader.endArray()
                }
                JsonReader.Token.BEGIN_OBJECT -> {
                    // {"0":"...","1":"..."} or {"A":"...","B":"..."}
                    reader.beginObject()
                    val map = LinkedHashMap<String, String>()
                    while (reader.hasNext()) {
                        val k = reader.nextName()
                        map[k] = readOptionEntry(reader)
                    }
                    reader.endObject()
                    val numeric = map.keys.all { it.toIntOrNull() != null }
                    if (numeric) map.entries.sortedBy { it.key.toInt() }.forEach { out.add(it.value) }
                    else map.values.forEach { out.add(it) }
                }
                else -> { reader.skipValue(); out.add(readOptionEntry(reader)) }
            }
        } catch (_: Exception) { runCatching { reader.skipValue() } }
    }

    private fun readOptionEntry(reader: JsonReader): String = try {
        when (reader.peek()) {
            JsonReader.Token.STRING -> reader.nextString()
            JsonReader.Token.NUMBER -> reader.nextString()
            JsonReader.Token.BEGIN_OBJECT -> {
                var text: String? = null
                reader.beginObject()
                while (reader.hasNext()) {
                    val k = reader.nextName()
                    if (k.lowercase() in setOf("text", "option", "value", "content", "label") && text == null) {
                        text = if (reader.peek() == JsonReader.Token.STRING || reader.peek() == JsonReader.Token.NUMBER) reader.nextString() else {
                            reader.skipValue(); null
                        }
                    } else if (k.lowercase() in setOf("iscorrect", "correct", "is_correct") && text == null) {
                        val isCorrect = if (reader.peek() == JsonReader.Token.BOOLEAN) reader.nextBoolean() else { reader.skipValue(); false }
                        if (isCorrect) text = " " // marker handled below
                    } else reader.skipValue()
                }
                reader.endObject()
                text.orEmpty()
            }
            JsonReader.Token.BEGIN_ARRAY -> { reader.skipValue(); "" }
            else -> { reader.skipValue(); "" }
        }
    } catch (_: Exception) { runCatching { reader.skipValue() }; "" }

    private fun readSingleOption(reader: JsonReader, out: MutableList<String>, index: Int) {
        val v = readStringOrObject(reader) ?: readPrimitiveAsString(reader) ?: return
        while (out.size < index) out.add("")
        if (out.size == index) out.add(v) else out[index] = v
    }

    private fun readAnswerIndex(reader: JsonReader): Int? = try {
        when (reader.peek()) {
            JsonReader.Token.NUMBER -> reader.nextInt()
            JsonReader.Token.STRING -> {
                val s = reader.nextString().trim()
                s.toIntOrNull()
                    ?: "abcdefghij".indexOfFirst { it.toString().equals(s, true) }.takeIf { it >= 0 }
            }
            JsonReader.Token.BEGIN_OBJECT -> {
                var idx: Int? = null
                reader.beginObject()
                while (reader.hasNext()) {
                    val k = reader.nextName()
                    if (k.lowercase() in setOf("index", "optionindex", "answerindex", "answer_index", "correctindex", "position", "no", "number")) {
                        idx = if (reader.peek() == JsonReader.Token.NUMBER) reader.nextInt() else {
                            val s = readPrimitiveAsString(reader)
                            s?.trim()?.toIntOrNull()
                                ?: "abcdefghij".indexOfFirst { it.toString().equals(s?.trim(), true) }.takeIf { it >= 0 }
                        }
                    } else reader.skipValue()
                }
                reader.endObject()
                idx
            }
            else -> { reader.skipValue(); null }
        }
    } catch (_: Exception) { runCatching { reader.skipValue() }; null }

    private fun normalizeYear(raw: String?): String? {
        val s = raw?.trim() ?: return null
        if (s.isEmpty()) return null
        val digits = s.filter { it.isDigit() }
        return when {
            digits.length == 4 -> digits
            else -> null
        }
    }
}
