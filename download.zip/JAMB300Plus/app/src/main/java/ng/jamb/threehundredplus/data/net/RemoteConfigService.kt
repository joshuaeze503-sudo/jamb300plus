package ng.jamb.threehundredplus.data.net

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import ng.jamb.threehundredplus.data.prefs.SettingsStore
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.security.MessageDigest

sealed class ConfigResult {
    data class Loaded(val config: RemoteConfigDto) : ConfigResult()
    data class Failed(val message: String) : ConfigResult()
}

/**
 * Fetches the optional remote configuration document.
 *
 * The app never claims this data is "official JAMB information" — it is whatever the
 * user has configured as their source. Missing values always display as
 * "Unconfirmed — check jamb.gov.ng".
 */
class RemoteConfigService(
    private val client: AlocClient,
    private val settings: SettingsStore
) {
    companion object {
        const val UNCONFIRMED = "Unconfirmed — check jamb.gov.ng"
    }

    fun validateUrl(url: String): String? {
        val clean = url.trim()
        if (clean.isEmpty()) return "Enter a configuration URL."
        if (!clean.startsWith("https://")) return "The URL must start with https://"
        val host = clean.removePrefix("https://").substringBefore('/')
        if (host.isBlank() || !host.contains('.')) return "That does not look like a valid web address."
        if (host.any { it.isWhitespace() }) return "The URL cannot contain spaces."
        return null
    }

    suspend fun fetch(url: String): ConfigResult = withContext(Dispatchers.IO) {
        val problem = validateUrl(url)
        if (problem != null) return@withContext ConfigResult.Failed(problem)
        val clean = url.trim()
        try {
            val parsed = client.parseRemoteConfig(java.net.URL(clean).openStream().use { it.readBytes().toString(Charsets.UTF_8) })
                ?: return@withContext ConfigResult.Failed("The response was not a valid configuration document.")
            settings.setCachedConfig(encode(parsed))
            if (parsed.examDate != null) {
                parseIsoDate(parsed.examDate)?.let { settings.setExamDateOverride(parsed.examDate, it) }
            }
            ConfigResult.Loaded(parsed)
        } catch (e: SocketTimeoutException) {
            ConfigResult.Failed("The configuration request timed out.")
        } catch (e: UnknownHostException) {
            ConfigResult.Failed("No internet connection. Your cached configuration is still being used.")
        } catch (e: IOException) {
            ConfigResult.Failed("The configuration could not be downloaded. Your cached values are still in use.")
        } catch (_: Exception) {
            ConfigResult.Failed("The configuration could not be read. Your cached values are still in use.")
        }
    }

    fun encode(c: RemoteConfigDto): String = buildString {
        append("{")
        append("\"examDate\":").append(c.examDate?.let { "\"${it.replace("\"", "")}\"" } ?: "null").append(',')
        append("\"registrationStart\":").append(c.registrationStart?.let { "\"${it.replace("\"", "")}\"" } ?: "null").append(',')
        append("\"registrationEnd\":").append(c.registrationEnd?.let { "\"${it.replace("\"", "")}\"" } ?: "null").append(',')
        append("\"syllabusVersion\":").append(c.syllabusVersion?.let { "\"${it.replace("\"", "")}\"" } ?: "null").append(',')
        append("\"lastUpdated\":").append(c.lastUpdated?.let { "\"${it.replace("\"", "")}\"" } ?: "null")
        append("}")
    }

    fun parseIsoDate(text: String): Long? = try {
        val d = java.time.LocalDate.parse(text.trim())
        d.atTime(9, 0).atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
    } catch (_: Exception) { null }

    fun fingerprint(s: String): String = MessageDigest.getInstance("SHA-256")
        .digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
        .take(12)
}
