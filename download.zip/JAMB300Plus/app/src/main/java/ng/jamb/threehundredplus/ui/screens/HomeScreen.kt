package ng.jamb.threehundredplus.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import ng.jamb.threehundredplus.data.net.RemoteConfigService
import ng.jamb.threehundredplus.domain.SubjectCatalogue
import ng.jamb.threehundredplus.ui.AppViewModel
import ng.jamb.threehundredplus.ui.InfoCard
import ng.jamb.threehundredplus.ui.ProgressRing
import ng.jamb.threehundredplus.ui.Routes
import ng.jamb.threehundredplus.ui.StatTile
import java.time.Duration
import java.time.Instant
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: AppViewModel, nav: NavHostController) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val overall by vm.overallPercent.collectAsStateWithLifecycle()
    val tasks by vm.todayTasks.collectAsStateWithLifecycle()
    val nextSlot by vm.nextSlot.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val xp by vm.xp.collectAsStateWithLifecycle()
    val rank by vm.rank.collectAsStateWithLifecycle()
    val streak by vm.streakDays.collectAsStateWithLifecycle()
    val prediction by vm.prediction.collectAsStateWithLifecycle()

    val subjects = settings.selectedSubjects
    val daysToExam: String = if (settings.examDateEpochMs > 0) {
        val diff = Duration.between(Instant.ofEpochMilli(now), Instant.ofEpochMilli(settings.examDateEpochMs)).toDays()
        when {
            diff < 0L -> "Passed"
            else -> diff.toString()
        }
    } else "—"

    val daysCaption: String = if (settings.examDateEpochMs > 0) {
        if (Duration.between(Instant.ofEpochMilli(now), Instant.ofEpochMilli(settings.examDateEpochMs)).toDays() < 0L)
            "Exam date reached" else "Days to exam"
    } else RemoteConfigService.UNCONFIRMED

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("JAMB 300+") },
                actions = {
                    IconButton(onClick = { nav.navigate(Routes.SETTINGS) }) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { p ->
        LazyColumn(
            modifier = Modifier.padding(p).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ProgressRing(
                            percent = overall,
                            label = "syllabus",
                            caption = "",
                            sizeDp = 104,
                            modifier = Modifier.size(104.dp)
                        )
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Overall progress", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "Predicted score: ${prediction.score}/400",
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                "Target ${prediction.target} • gap ${prediction.gapToTarget.coerceAtLeast(0)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatTile(daysToExam, daysCaption, Modifier.weight(1f))
                    StatTile("$streak", "Day streak", Modifier.weight(1f), MaterialTheme.colorScheme.secondary)
                    StatTile("$xp", "XP", Modifier.weight(1f), MaterialTheme.colorScheme.tertiary)
                    StatTile(rank.title, "Rank", Modifier.weight(1f))
                }
            }

            item {
                val slot = nextSlot
                InfoCard(
                    title = "Next study slot",
                    body = if (slot == null) {
                        "No study slots are configured yet. Add them in Settings."
                    } else {
                        val mins = ((slot.second - now).coerceAtLeast(0) / 60000.0).toInt()
                        val hh = mins / 60
                        val mm = mins % 60
                        if (hh > 0) "Starts in ${hh}h ${mm}m" else "Starts in ${mm}m"
                    }
                )
            }

            item {
                Text("Today's plan", style = MaterialTheme.typography.titleMedium)
            }

            if (tasks.isEmpty()) {
                item {
                    InfoCard(
                        title = "No tasks yet",
                        body = "Open Schedule and generate a plan to get daily revision tasks.",
                        actionLabel = "Go to Schedule",
                        onAction = { nav.navigate(Routes.SCHEDULE) }
                    )
                }
            } else {
                items(tasks, key = { it.id }) { task ->
                    Card(
                        Modifier.fillMaxWidth().heightIn(min = 56.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (task.done) MaterialTheme.colorScheme.surfaceContainer
                            else MaterialTheme.colorScheme.surfaceContainerHigh
                        )
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = task.done,
                                onCheckedChange = { vm.toggleTask(task) }
                            )
                            Column(Modifier.weight(1f).padding(vertical = 6.dp)) {
                                Text(
                                    task.topicTitle,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = if (task.done) FontWeight.Normal else FontWeight.SemiBold
                                )
                                Text(
                                    "${SubjectCatalogue.shortOf(task.subject)} • ${task.type}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            item {
                Text("Subject progress", style = MaterialTheme.typography.titleMedium)
            }

            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(subjects, key = { it }) { s ->
                        val p = progress[s]
                        Card(
                            Modifier.size(width = 140.dp, height = 168.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
                        ) {
                            Column(
                                Modifier.fillMaxWidth().padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    SubjectCatalogue.shortOf(s),
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Spacer(Modifier.height(8.dp))
                                ProgressRing(
                                    percent = p?.percent ?: 0,
                                    label = "done",
                                    caption = "",
                                    sizeDp = 86,
                                    modifier = Modifier.size(86.dp)
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "${p?.done ?: 0}/${p?.total ?: 0}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            item {
                InfoCard(
                    title = "Estimate, not a promise",
                    body = "The predicted score is calculated from your syllabus coverage, your own mock results and how " +
                        "consistently you study. It is an estimate and not a guaranteed JAMB score.",
                    actionLabel = "Open Progress",
                    onAction = { nav.navigate(Routes.PROGRESS) }
                )
            }

            item { Spacer(Modifier.height(20.dp)) }
        }
    }
}
