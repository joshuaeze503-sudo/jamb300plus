package ng.jamb.threehundredplus.reminders

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import ng.jamb.threehundredplus.data.db.ScheduleTaskEntity
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Alarm scheduling for study slots.
 *
 * Exact alarms are used when the OS grants them; otherwise the reminder silently
 * falls back to an inexact alarm. The app never crashes when the capability is
 * missing — the user is told about it in Settings instead.
 */
object ReminderScheduler {

    const val EXTRA_ID = "reminder_id"
    const val EXTRA_TITLE = "reminder_title"
    const val EXTRA_BODY = "reminder_body"
    const val EXTRA_DEEP_LINK = "reminder_deep_link"
    const val EXTRA_SLOT = "reminder_slot"
    const val EXTRA_DAY = "reminder_day"
    const val ACTION_START = "ng.jamb.threehundredplus.START"
    const val ACTION_SNOOZE = "ng.jamb.threehundredplus.SNOOZE"
    const val ACTION_SKIP = "ng.jamb.threehundredplus.SKIP"

    private const val LOOKAHEAD_DAYS = 14

    fun canScheduleExact(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val am = context.getSystemService(AlarmManager::class.java) ?: return false
        return try { am.canScheduleExactAlarms() } catch (_: Exception) { false }
    }

    fun exactAlarmSettingsIntent(context: Context): Intent? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return null
        return try {
            Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                .setData(android.net.Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        } catch (_: Exception) { null }
    }

    fun notificationSettingsIntent(context: Context): Intent? = try {
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    } catch (_: Exception) { null }

    fun batterySettingsIntent(): Intent? = try {
        Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    } catch (_: Exception) { null }

    fun cancelAll(context: Context) {
        val am = context.getSystemService(AlarmManager::class.java) ?: return
        val pm = context.packageName
        for (i in 0 until 400) {
            val pi = pendingIntent(context, i, "", "", null, i, 0, cancelOnly = true) ?: continue
            runCatching { am.cancel(pi) }
            pi.cancel()
        }
        // Also drop any notifications already shown.
        runCatching {
            context.getSystemService(android.app.NotificationManager::class.java)
                ?.cancelAll()
        }
    }

    fun rescheduleAll(context: Context, tasks: List<ScheduleTaskEntity>, leadMinutes: Int, slots: List<String>) {
        val am = context.getSystemService(AlarmManager::class.java) ?: return
        val today = LocalDate.now()
        val zone = ZoneId.systemDefault()
        val nowMs = System.currentTimeMillis()
        val parsed = ng.jamb.threehundredplus.domain.ScheduleGenerator.parseSlots(slots)
        if (parsed.isEmpty()) return
        for (task in tasks) {
            if (task.done || task.skipped) continue
            val day = LocalDate.ofEpochDay(task.dateEpochDay)
            if (day.isBefore(today) || day.isAfter(today.plusDays(LOOKAHEAD_DAYS.toLong()))) continue
            val slot = parsed.getOrNull(task.slotIndex) ?: continue
            val start = LocalDateTime.of(day, slot.start).atZone(zone).toInstant().toEpochMilli()
            val fireAt = start - leadMinutes * 60_000L
            if (fireAt <= nowMs) continue
            val id = reminderId(task.dateEpochDay, task.slotIndex)
            val title = "${ng.jamb.threehundredplus.domain.SubjectCatalogue.shortOf(task.subject)} • %02d:%02d".format(slot.start.hour, slot.start.minute)
            val body = task.topicTitle.ifBlank { "Study session" }
            val deepLink = "focus?taskId=${task.id}"
            val pi = pendingIntent(context, id, title, body, deepLink, task.slotIndex, task.dateEpochDay)
            if (pi == null) continue
            try {
                if (canScheduleExact(context)) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fireAt, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fireAt, pi)
                }
            } catch (_: SecurityException) {
                runCatching { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fireAt, pi) }
            } catch (_: Exception) {
                // Never let a single alarm failure take the app down.
            }
        }
    }

    fun snooze(context: Context, id: Int, title: String, body: String, deepLink: String?, slot: Int, day: Long) {
        val am = context.getSystemService(AlarmManager::class.java) ?: return
        val pi = pendingIntent(context, id, title, body, deepLink, slot, day) ?: return
        val fireAt = System.currentTimeMillis() + 10 * 60_000L
        try {
            if (canScheduleExact(context)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fireAt, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fireAt, pi)
        } catch (_: Exception) {
            runCatching { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fireAt, pi) }
        }
    }

    fun reminderId(dayEpoch: Long, slotIndex: Int): Int =
        ((dayEpoch % 1000) * 10 + slotIndex).toInt().let { if (it <= 0) (it + 100000) else it }

    private fun pendingIntent(
        context: Context,
        id: Int,
        title: String,
        body: String,
        deepLink: String?,
        slot: Int,
        day: Long,
        cancelOnly: Boolean = false
    ): PendingIntent? = try {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            action = ReminderReceiver.ACTION_FIRE
            putExtra(EXTRA_ID, id)
            putExtra(EXTRA_TITLE, title)
            putExtra(EXTRA_BODY, body)
            putExtra(EXTRA_DEEP_LINK, deepLink)
            putExtra(EXTRA_SLOT, slot)
            putExtra(EXTRA_DAY, day)
        }
        PendingIntent.getBroadcast(
            context,
            id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    } catch (_: Exception) { null }
}
