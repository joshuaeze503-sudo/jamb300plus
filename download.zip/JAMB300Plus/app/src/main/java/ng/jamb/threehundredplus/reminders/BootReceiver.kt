package ng.jamb.threehundredplus.reminders

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import ng.jamb.threehundredplus.JambApp
import java.time.LocalDate

/** Restores pending reminders after reboot, app update, or a clock/timezone change. */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action !in HANDLED) return
        val app = context.applicationContext
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val container = (app as JambApp).container
                val settings = container.settingsStore.settings.first()
                if (!settings.remindersEnabled) {
                    ReminderScheduler.cancelAll(app)
                } else {
                    val today = LocalDate.now().toEpochDay()
                    val tasks = container.scheduleDao.getFrom(today)
                    ReminderScheduler.rescheduleAll(
                        app, tasks, settings.reminderLeadMinutes, settings.slotTimes
                    )
                }
            } catch (_: Exception) {
                // Never crash on boot.
            } finally {
                runCatching { pending.finish() }
            }
        }
    }

    companion object {
        private val HANDLED = setOf(
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED
        )
    }
}
