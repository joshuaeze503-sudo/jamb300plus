package ng.jamb.threehundredplus.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import ng.jamb.threehundredplus.data.Json
import ng.jamb.threehundredplus.data.MistakeRepository
import ng.jamb.threehundredplus.data.db.MistakeEntity
import ng.jamb.threehundredplus.data.db.QuestionEntity
import ng.jamb.threehundredplus.domain.SubjectCatalogue
import ng.jamb.threehundredplus.ui.AppViewModel
import ng.jamb.threehundredplus.ui.EmptyState
import ng.jamb.threehundredplus.ui.InfoCard
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MistakesScreen(vm: AppViewModel, nav: NavHostController) {
    val mistakes by vm.openMistakes.collectAsStateWithLifecycle(initialValue = emptyList())
    var dueNow by remember { mutableStateOf<List<Pair<MistakeEntity, QuestionEntity>>>(emptyList()) }
    var reviewing by remember { mutableStateOf<Pair<MistakeEntity, QuestionEntity>?>(null) }
    var selectedOption by remember { mutableStateOf<Int?>(null) }

    LaunchedEffect(mistakes.size) {
        val pairs = vm.container.mistakeRepo.questionsFor(mistakes)
            .mapNotNull { q -> mistakes.firstOrNull { it.questionId == q.id }?.let { it to q } }
        dueNow = pairs
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mistake notebook") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { p ->
        if (mistakes.isEmpty()) {
            Column(Modifier.padding(p).padding(16.dp)) {
                EmptyState(
                    title = "No mistakes recorded",
                    body = "Questions you answer incorrectly in practice or a mock are added here automatically with " +
                        "spaced reviews at 1, 3, 7 and 14 days."
                )
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier.padding(p).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                InfoCard(
                    title = "Spaced review",
                    body = "Each miss resets the review schedule. The more often a question is missed, the higher its " +
                        "priority for Sunday revision."
                )
            }
            items(dueNow, key = { it.first.id }) { (m, q) ->
                val next = Instant.ofEpochMilli(m.nextReviewAt).atZone(ZoneId.systemDefault())
                    .format(DateTimeFormatter.ofPattern("d MMM, HH:mm"))
                Card(
                    Modifier.fillMaxWidth().heightIn(min = 64.dp)
                        .clickable { reviewing = m to q; selectedOption = null },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
                ) {
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Text(
                            SubjectCatalogue.shortOf(m.subject),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(q.questionText, style = MaterialTheme.typography.bodyMedium, maxLines = 3)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Missed ${m.timesMissed}× • next review $next",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            if (dueNow.size < mistakes.size) {
                item {
                    Text(
                        "${mistakes.size - dueNow.size} older entries reference questions that are no longer cached.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }

    val pair = reviewing
    if (pair != null) {
        val (m, q) = pair
        AlertDialog(
            onDismissRequest = { reviewing = null; selectedOption = null },
            title = { Text(q.questionText, style = MaterialTheme.typography.bodyMedium) },
            text = {
                Column(Modifier.heightIn(max = 380.dp)) {
                    MetaLine(q)
                    Spacer(Modifier.height(10.dp))
                    Json.readStringList(q.optionsJson).forEachIndexed { i, opt ->
                        val chosen = selectedOption == i
                        val correct = q.answerIndex == i
                        val revealed = selectedOption != null
                        Card(
                            Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .padding(vertical = 3.dp)
                                .clickable { selectedOption = i },
                            colors = CardDefaults.cardColors(
                                containerColor = when {
                                    revealed && correct -> MaterialTheme.colorScheme.secondaryContainer
                                    revealed && chosen -> MaterialTheme.colorScheme.errorContainer
                                    chosen -> MaterialTheme.colorScheme.primaryContainer
                                    else -> MaterialTheme.colorScheme.surfaceContainerHigh
                                }
                            )
                        ) {
                            Text("${('A'.code + i)}. $opt", modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    if (selectedOption != null && q.explanation != null) {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "Explanation (${q.source ?: "source"}): ${q.explanation}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (selectedOption != null) {
                        vm.reviewMistake(m, selectedOption == q.answerIndex)
                        reviewing = null
                        selectedOption = null
                    }
                }, enabled = selectedOption != null) { Text("Record review") }
            },
            dismissButton = {
                TextButton(onClick = { vm.resolveMistake(m.id); reviewing = null; selectedOption = null }) {
                    Text("Mark resolved")
                }
            }
        )
    }
}
