package ng.jamb.threehundredplus.domain

import ng.jamb.threehundredplus.data.db.ScheduleTaskEntity
import ng.jamb.threehundredplus.data.db.TopicEntity
import ng.jamb.threehundredplus.data.db.TopicStatus
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.max

object ScheduleGenerator {

    const val TYPE_LEARN = "LEARN"
    const val TYPE_REVISE = "REVISE"
    const val TYPE_PRACTICE = "PRACTICE"

    data class Input(
        val subjects: List<String>,
        val topicsBySubject: Map<String, List<TopicEntity>>,
        val slots: List<String>,
        val startDate: LocalDate,
        val horizonDays: Int,
        val carriedOver: List<ScheduleTaskEntity>,
        val mistakesBySubject: Map<String, Int>
    )

    /**
     * Builds a plan of dated tasks.
     *
     * Rules enforced here:
     *  - Sunday contains ONLY revision / past-question practice. No new topics.
     *  - Completed topics are never scheduled as new-learning tasks.
     *  - Unfinished tasks from earlier days that were not completed are rolled forward
     *    into the earliest free slots ahead.
     *  - Subjects with more open mistakes get more revision weight.
     */
    fun generate(input: Input): List<ScheduleTaskEntity> {
        val now = System.currentTimeMillis()
        val slots = input.slots.ifEmpty { return emptyList() }
        val days = (0 until max(1, input.horizonDays)).map { input.startDate.plusDays(it.toLong()) }

        val result = ArrayList<ScheduleTaskEntity>()

        // Topics that still need learning, in catalogue order, per subject.
        val learnPool = LinkedHashMap<String, java.util.ArrayDeque<TopicEntity>>()
        input.subjects.forEach { s ->
            val pool = java.util.ArrayDeque<TopicEntity>()
            input.topicsBySubject[s]
                ?.filter { it.status != TopicStatus.DONE.name }
                ?.sortedBy { it.orderIndex }
                ?.forEach { pool.addLast(it) }
            learnPool[s] = pool
        }

        // Subjects ordered by mistake pressure, then catalogue order.
        val revisionOrder = input.subjects.sortedByDescending { input.mistakesBySubject[it] ?: 0 }

        // Carry-over queue: the oldest unfinished task first.
        val carry = java.util.ArrayDeque(
            input.carriedOver
                .filter { !it.done && !it.skipped }
                .sortedBy { it.dateEpochDay * 100 + it.slotIndex }
        )

        val learnRotation = java.util.ArrayDeque(input.subjects)

        for (day in days) {
            val isSunday = day.dayOfWeek == DayOfWeek.SUNDAY
            for ((slotIndex, _) in slots.withIndex()) {
                val existingCarry = carry.pollFirst()
                if (existingCarry != null) {
                    result.add(
                        existingCarry.copy(
                            id = 0,
                            dateEpochDay = day.toEpochDay(),
                            slotIndex = slotIndex,
                            done = false,
                            skipped = false,
                            createdAt = now
                        )
                    )
                    continue
                }

                val subject: String
                val type: String
                if (isSunday) {
                    // Sunday: revision + past-question practice only.
                    type = if (slotIndex % 2 == 0) TYPE_REVISE else TYPE_PRACTICE
                    subject = revisionOrder[(day.toEpochDay() + slotIndex).toInt().mod(revisionOrder.size.coerceAtLeast(1))]
                } else {
                    val rotating = learnRotation.pollFirst()
                    if (rotating != null) learnRotation.addLast(rotating)
                    subject = rotating ?: input.subjects.firstOrNull() ?: continue
                    val revisionPressure = input.mistakesBySubject[subject] ?: 0
                    val doRevision = revisionPressure > 0 && (slotIndex + day.dayOfWeek.value) % 4 == 3
                    type = if (doRevision) TYPE_REVISE else TYPE_LEARN
                }

                val topic = when (type) {
                    TYPE_LEARN -> learnPool[subject]?.pollFirst()
                    TYPE_REVISE -> input.topicsBySubject[subject]
                        ?.filter { it.status == TopicStatus.NEEDS_REVISION.name || it.status == TopicStatus.LEARNING.name || it.status == TopicStatus.DONE.name }
                        ?.sortedBy { it.orderIndex }
                        ?.getOrNull(((day.toEpochDay() + slotIndex).toInt().mod(12)))
                    else -> null
                }

                val title = when (type) {
                    TYPE_LEARN -> topic?.title?.let { "Learn: $it" } ?: "Continue syllabus: ${SubjectCatalogue.shortOf(subject)}"
                    TYPE_REVISE -> topic?.title?.let { "Revise: $it" } ?: "Revise ${SubjectCatalogue.shortOf(subject)}"
                    else -> "Past-question practice: ${SubjectCatalogue.shortOf(subject)}"
                }

                result.add(
                    ScheduleTaskEntity(
                        dateEpochDay = day.toEpochDay(),
                        slotIndex = slotIndex,
                        subject = subject,
                        topicId = topic?.id,
                        topicTitle = title,
                        type = type,
                        done = false,
                        skipped = false,
                        createdAt = now
                    )
                )
            }
        }
        return result
    }

    data class Slot(val index: Int, val start: LocalTime, val end: LocalTime)

    fun parseSlots(raw: List<String>): List<Slot> = raw.mapIndexedNotNull { index, s ->
        val parts = s.split("-")
        if (parts.size != 2) return@mapIndexedNotNull null
        val start = parseTime(parts[0].trim()) ?: return@mapIndexedNotNull null
        val end = parseTime(parts[1].trim()) ?: return@mapIndexedNotNull null
        Slot(index, start, end)
    }

    fun parseTime(t: String): LocalTime? = try {
        val p = t.split(":")
        if (p.size < 2) null else LocalTime.of(p[0].trim().toInt(), p[1].trim().toInt())
    } catch (_: Exception) { null }

    fun formatTime(t: LocalTime): String = "%02d:%02d".format(t.hour, t.minute)

    /** Next upcoming slot start as epoch millis, or null when today's slots are done. */
    fun nextSlotStart(slots: List<Slot>, from: java.time.ZonedDateTime): Pair<Int, Long>? {
        for (s in slots) {
            val dt = from.toLocalDate().atTime(s.start).atZone(from.zone)
            val ms = dt.toInstant().toEpochMilli()
            if (ms > from.toInstant().toEpochMilli()) return s.index to ms
        }
        val tomorrow = from.toLocalDate().plusDays(1)
        val first = slots.firstOrNull() ?: return null
        return first.index to tomorrow.atTime(first.start).atZone(from.zone).toInstant().toEpochMilli()
    }
}
