package ng.jamb.threehundredplus.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import ng.jamb.threehundredplus.data.db.ScheduleTaskEntity
import ng.jamb.threehundredplus.domain.ScheduleGenerator
import ng.jamb.threehundredplus.domain.SubjectCatalogue
import ng.jamb.threehundredplus.ui.AppViewModel
import ng.jamb.threehundredplus.ui.InfoCard
import ng.jamb.threehundredplus.ui.Routes
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScheduleScreen(vm: AppViewModel, nav: NavHostController) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val today by vm.todayTasks.collectAsStateWithLifecycle()
    val upcoming by vm.upcomingTasks.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()

    val parsedSlots = ScheduleGenerator.parseSlots(settings.slotTimes)
    val grouped = upcoming.groupBy { it.dateEpochDay }.toList().sortedBy { it.first }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Study schedule") }) }
    ) { p ->
        LazyColumn(
            modifier = Modifier.padding(p).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                OutlinedButton(
                    onClick = { vm.regenerateSchedule() },
                    enabled = !busy.loading,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) { Text(if (busy.loading) "Working…" else "Regenerate schedule") }
            }

            item {
                InfoCard(
                    title = "Sundays are for revision only",
                    body = "Every Sunday slot is either a revision task or past-question practice. New topics are never " +
                        "scheduled on a Sunday. Unfinished tasks are rolled forward into the next free slots."
                )
            }

            item { Text("Today", style = MaterialTheme.typography.titleLarge) }

            if (today.isEmpty()) {
                item {
                    InfoCard(
                        title = "Nothing planned for today",
                        body = "Tap “Regenerate schedule” to build a plan from your selected subjects and syllabus topics."
                    )
                }
            } else {
                items(today, key = { it.id }) { task -> TaskCard(task, vm, nav) }
            }

            if (parsedSlots.isNotEmpty()) {
                item {
                    Spacer(Modifier.height(8.dp))
                    Text("Your slot times", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    parsedSlots.forEach { s ->
                        Text(
                            "Slot ${s.index + 1}: ${ScheduleGenerator.formatTime(s.start)} – ${ScheduleGenerator.formatTime(s.end)}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Change these in Settings.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (grouped.isNotEmpty()) {
                item {
                    Spacer(Modifier.height(8.dp))
                    Text("Coming up", style = MaterialTheme.typography.titleMedium)
                }
                grouped.take(14).forEach { (day, tasks) ->
                    item {
                        Text(
                            LocalDate.ofEpochDay(day).format(DateTimeFormatter.ofPattern("EEE d MMM")),
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    items(tasks, key = { it.id }) { task -> TaskCard(task, vm, nav, compact = true) }
                }
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun TaskCard(
    task: ScheduleTaskEntity,
    vm: AppViewModel,
    nav: NavHostController,
    compact: Boolean = false
) {
    Card(
        Modifier.fillMaxWidth().heightIn(min = 56.dp),
        colors = CardDefaults.cardColors(
            containerColor = when {
                task.done -> MaterialTheme.colorScheme.surfaceContainer
                task.type == "REVISE" || task.type == "PRACTICE" ->
                    MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.35f)
                else -> MaterialTheme.colorScheme.surfaceContainerHigh
            }
        )
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(checked = task.done, onCheckedChange = { vm.toggleTask(task) })
            Column(Modifier.weight(1f).padding(vertical = 4.dp)) {
                Text(
                    task.topicTitle,
                    style = if (compact) MaterialTheme.typography.bodyMedium else MaterialTheme.typography.bodyLarge,
                    fontWeight = if (task.done) FontWeight.Normal else FontWeight.SemiBold
                )
                Text(
                    "${SubjectCatalogue.shortOf(task.subject)} • ${task.type}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (!task.done) {
                OutlinedButton(
                    onClick = { nav.navigate(Routes.FOCUS) },
                    modifier = Modifier.heightIn(min = 44.dp)
                ) { Text("Start") }
            }
        }
    }
}
