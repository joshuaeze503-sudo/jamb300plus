package ng.jamb.threehundredplus.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import ng.jamb.threehundredplus.ui.screens.AboutScreen
import ng.jamb.threehundredplus.ui.screens.FixRemindersScreen
import ng.jamb.threehundredplus.ui.screens.FocusScreen
import ng.jamb.threehundredplus.ui.screens.HomeScreen
import ng.jamb.threehundredplus.ui.screens.MistakesScreen
import ng.jamb.threehundredplus.ui.screens.MockResultScreen
import ng.jamb.threehundredplus.ui.screens.MockScreen
import ng.jamb.threehundredplus.ui.screens.OnboardingScreen
import ng.jamb.threehundredplus.ui.screens.OfficialUpdatesScreen
import ng.jamb.threehundredplus.ui.screens.PracticeScreen
import ng.jamb.threehundredplus.ui.screens.ProgressScreen
import ng.jamb.threehundredplus.ui.screens.ScheduleScreen
import ng.jamb.threehundredplus.ui.screens.SettingsScreen
import ng.jamb.threehundredplus.ui.screens.SyllabusScreen
import ng.jamb.threehundredplus.ui.screens.SubjectTopicsScreen

object Routes {
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val SYLLABUS = "syllabus"
    const val SCHEDULE = "schedule"
    const val PRACTICE = "practice"
    const val PROGRESS = "progress"
    const val SETTINGS = "settings"
    const val ABOUT = "about"
    const val UPDATES = "updates"
    const val FIX_REMINDERS = "fix_reminders"
    const val MOCK = "mock"
    const val MOCK_RESULT = "mock_result"
    const val MISTAKES = "mistakes"
    const val FOCUS = "focus"
    const val TOPICS = "topics"
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val TABS = listOf(
    Tab(Routes.HOME, "Home", Icons.Filled.Home),
    Tab(Routes.SYLLABUS, "Syllabus", Icons.Filled.List),
    Tab(Routes.SCHEDULE, "Schedule", Icons.Filled.DateRange),
    Tab(Routes.PRACTICE, "Practice", Icons.Filled.CheckCircle),
    Tab(Routes.PROGRESS, "Progress", Icons.Filled.Person)
)

@Composable
fun AppRoot(vm: AppViewModel, deepLink: String? = null) {
    val nav = rememberNavController()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val busy by vm.busy.collectAsStateWithLifecycle()

    LaunchedEffect(busy.message) {
        val m = busy.message
        if (!m.isNullOrBlank()) {
            snackbar.showSnackbar(m)
            vm.clearMessage()
        }
    }

    LaunchedEffect(deepLink) {
        val link = deepLink ?: return@LaunchedEffect
        when {
            link.startsWith("focus") -> nav.navigate(Routes.FOCUS)
            link.startsWith("mock") -> nav.navigate(Routes.MOCK)
        }
    }

    LaunchedEffect(settings.onboardingDone) {
        if (!settings.onboardingDone) {
            nav.navigate(Routes.ONBOARDING) { launchSingleTop = true }
        }
    }

    val backStack by nav.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    if (currentRoute == Routes.ONBOARDING) {
        OnboardingScreen(vm)
        return
    }

    val showBars = currentRoute in TABS.map { it.route }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            if (showBars) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                    TABS.forEach { tab ->
                        NavigationBarItem(
                            selected = currentRoute == tab.route,
                            onClick = {
                                if (currentRoute != tab.route) {
                                    nav.navigate(tab.route) {
                                        popUpTo(Routes.HOME) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        AppNavHost(nav, vm, Modifier.padding(padding))
    }
}

@Composable
private fun AppNavHost(nav: NavHostController, vm: AppViewModel, modifier: Modifier) {
    NavHost(navController = nav, startDestination = Routes.HOME, modifier = modifier) {
        composable(Routes.HOME) { HomeScreen(vm, nav) }
        composable(Routes.SYLLABUS) { SyllabusScreen(vm, nav) }
        composable(Routes.SCHEDULE) { ScheduleScreen(vm, nav) }
        composable(Routes.PRACTICE) { PracticeScreen(vm, nav) }
        composable(Routes.PROGRESS) { ProgressScreen(vm, nav) }
        composable(Routes.SETTINGS) { SettingsScreen(vm, nav) }
        composable(Routes.ABOUT) { AboutScreen(nav) }
        composable(Routes.UPDATES) { OfficialUpdatesScreen(nav) }
        composable(Routes.FIX_REMINDERS) { FixRemindersScreen(vm, nav) }
        composable(Routes.MOCK) { MockScreen(vm, nav) }
        composable(Routes.MISTAKES) { MistakesScreen(vm, nav) }
        composable(Routes.FOCUS) { FocusScreen(vm, nav) }
        composable(Routes.MOCK_RESULT) { MockResultScreen(vm, nav) }
        composable(
            "${Routes.TOPICS}/{subject}",
            arguments = listOf(navArgument("subject") { type = NavType.StringType })
        ) { entry ->
            val subject = entry.arguments?.getString("subject").orEmpty()
            SubjectTopicsScreen(vm, subject, nav)
        }
    }
}
