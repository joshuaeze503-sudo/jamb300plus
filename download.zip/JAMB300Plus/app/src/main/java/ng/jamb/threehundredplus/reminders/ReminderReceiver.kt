package ng.jamb.threehundredplus.reminders

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import ng.jamb.threehundredplus.JambApp

class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra(ReminderScheduler.EXTRA_ID, 0)
        val title = intent.getStringExtra(ReminderScheduler.EXTRA_TITLE) ?: "Study session"
        val body = intent.getStringExtra(ReminderScheduler.EXTRA_BODY).orEmpty()
        val deepLink = intent.getStringExtra(ReminderScheduler.EXTRA_DEEP_LINK)
        val pending = goAsync()
        val app = context.applicationContext
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val container = (app as JambApp).container
                val settings = container.settingsStore.settings.first()
                if (settings.remindersEnabled) {
                    Notifications.show(app, id, title, body, deepLink)
                }
            } catch (_: Exception) {
                // A reminder that cannot be shown must never crash the app.
            } finally {
                runCatching { pending.finish() }
            }
        }
    }

    companion object { const val ACTION_FIRE = "ng.jamb.threehundredplus.FIRE_REMINDER" }
}
