package ng.jamb.threehundredplus.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface SubjectDao {
    @Query("SELECT * FROM selected_subjects ORDER BY orderIndex ASC")
    fun observe(): Flow<List<SelectedSubjectEntity>>

    @Query("SELECT * FROM selected_subjects ORDER BY orderIndex ASC")
    suspend fun get(): List<SelectedSubjectEntity>

    @Upsert
    suspend fun upsertAll(list: List<SelectedSubjectEntity>)

    @Query("UPDATE selected_subjects SET alocCode = :code WHERE subject = :subject")
    suspend fun updateCode(subject: String, code: String)

    @Query("DELETE FROM selected_subjects")
    suspend fun clear()
}

@Dao
interface TopicDao {
    @Query("SELECT * FROM topics WHERE subject = :subject ORDER BY orderIndex ASC, id ASC")
    fun observeBySubject(subject: String): Flow<List<TopicEntity>>

    @Query("SELECT * FROM topics WHERE subject = :subject ORDER BY orderIndex ASC, id ASC")
    suspend fun getBySubject(subject: String): List<TopicEntity>

    @Query("SELECT * FROM topics ORDER BY subject ASC, orderIndex ASC, id ASC")
    fun observeAll(): Flow<List<TopicEntity>>

    @Query("SELECT * FROM topics ORDER BY subject ASC, orderIndex ASC, id ASC")
    suspend fun getAll(): List<TopicEntity>

    @Query("SELECT COUNT(*) FROM topics")
    fun observeCount(): Flow<Int>

    @Query("UPDATE topics SET status = :status WHERE id = :id")
    suspend fun setStatus(id: Long, status: String)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(list: List<TopicEntity>)

    @Query("DELETE FROM topics WHERE isCustom = 1 AND id = :id")
    suspend fun deleteCustom(id: Long)

    @Query("SELECT COUNT(*) FROM topics WHERE subject = :subject AND isCustom = 0")
    suspend fun builtInCount(subject: String): Int

    @Query("DELETE FROM topics")
    suspend fun deleteAll()
}

@Dao
interface QuestionDao {
    @Query("SELECT * FROM questions WHERE subject = :subject ORDER BY year DESC, id ASC")
    fun observeBySubject(subject: String): Flow<List<QuestionEntity>>

    @Query("SELECT COUNT(*) FROM questions WHERE subject = :subject")
    fun observeCountBySubject(subject: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM questions WHERE subject = :subject")
    suspend fun countBySubject(subject: String): Int

    @Query("SELECT COUNT(*) FROM questions")
    fun observeTotalCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM questions")
    suspend fun totalCount(): Int

    @Query("SELECT DISTINCT year FROM questions WHERE subject = :subject AND year IS NOT NULL AND year != '' ORDER BY year DESC")
    fun observeYears(subject: String): Flow<List<String>>

    @Query("SELECT * FROM questions WHERE id IN (:ids)")
    suspend fun getByIds(ids: List<Long>): List<QuestionEntity>

    @Query("SELECT * FROM questions WHERE id = :id")
    suspend fun getById(id: Long): QuestionEntity?

    @Query("SELECT * FROM questions WHERE subject = :subject ORDER BY id DESC LIMIT :limit")
    suspend fun recent(subject: String, limit: Int): List<QuestionEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(list: List<QuestionEntity>)

    @Query("SELECT COUNT(*) FROM questions WHERE fingerprint = :fp")
    suspend fun countByFingerprint(fp: String): Int

    @Query("DELETE FROM questions")
    suspend fun clear()
}

@Dao
interface MockDao {
    @Query("SELECT * FROM mocks ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<MockEntity>>

    @Query("SELECT * FROM mocks WHERE id = :id")
    fun observeById(id: Long): Flow<MockEntity?>

    @Query("SELECT * FROM mocks WHERE id = :id")
    suspend fun getById(id: Long): MockEntity?

    @Query("SELECT * FROM mocks WHERE status = 'ACTIVE' ORDER BY createdAt DESC LIMIT 1")
    suspend fun activeMock(): MockEntity?

    @Query("SELECT * FROM mocks WHERE status = 'SUBMITTED' ORDER BY submittedAt DESC LIMIT :limit")
    fun observeSubmitted(limit: Int): Flow<List<MockEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(mock: MockEntity): Long

    @Query("DELETE FROM mocks WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT COUNT(*) FROM mocks WHERE status = 'SUBMITTED'")
    fun observeSubmittedCount(): Flow<Int>

    @Query("SELECT * FROM mocks ORDER BY createdAt DESC")
    suspend fun getAll(): List<MockEntity>
}

@Dao
interface AttemptDao {
    @Query("SELECT * FROM attempts WHERE mockId = :mockId")
    fun observeByMock(mockId: Long): Flow<List<AttemptEntity>>

    @Query("SELECT * FROM attempts ORDER BY answeredAt DESC")
    fun observeAll(): Flow<List<AttemptEntity>>

    @Query("SELECT COUNT(*) FROM attempts WHERE answeredAt >= :since")
    fun observeCountSince(since: Long): Flow<Int>

    @Query("SELECT * FROM attempts ORDER BY answeredAt DESC")
    suspend fun getAll(): List<AttemptEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<AttemptEntity>)

    @Query("DELETE FROM attempts")
    suspend fun clear()
}

@Dao
interface MistakeDao {
    @Query("SELECT * FROM mistakes WHERE resolved = 0 ORDER BY timesMissed DESC, nextReviewAt ASC")
    fun observeOpen(): Flow<List<MistakeEntity>>

    @Query("SELECT * FROM mistakes WHERE resolved = 0")
    suspend fun open(): List<MistakeEntity>

    @Query("SELECT * FROM mistakes ORDER BY timesMissed DESC, lastMissedAt DESC")
    fun observeAll(): Flow<List<MistakeEntity>>

    @Query("SELECT * FROM mistakes WHERE id = :id")
    suspend fun getById(id: Long): MistakeEntity?

    @Query("SELECT * FROM mistakes WHERE questionId = :qid")
    suspend fun getByQuestion(qid: Long): MistakeEntity?

    @Query("SELECT * FROM mistakes ORDER BY timesMissed DESC, lastMissedAt DESC")
    suspend fun getAll(): List<MistakeEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(m: MistakeEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<MistakeEntity>)

    @Query("UPDATE mistakes SET timesMissed = timesMissed + 1, lastMissedAt = :now, nextReviewAt = :next, reviewStage = 0, resolved = 0 WHERE questionId = :qid")
    suspend fun incrementMiss(qid: Long, now: Long, next: Long)

    @Query("UPDATE mistakes SET timesReviewed = timesReviewed + 1, reviewStage = :stage, nextReviewAt = :next WHERE id = :id")
    suspend fun markReviewed(id: Long, stage: Int, next: Long)

    @Query("UPDATE mistakes SET resolved = 1 WHERE id = :id")
    suspend fun resolve(id: Long)

    @Query("DELETE FROM mistakes")
    suspend fun clear()
}

@Dao
interface ScheduleDao {
    @Query("SELECT * FROM schedule_tasks WHERE dateEpochDay = :day ORDER BY slotIndex ASC, id ASC")
    fun observeDay(day: Long): Flow<List<ScheduleTaskEntity>>

    @Query("SELECT * FROM schedule_tasks WHERE dateEpochDay = :day ORDER BY slotIndex ASC, id ASC")
    suspend fun getDay(day: Long): List<ScheduleTaskEntity>

    @Query("SELECT * FROM schedule_tasks WHERE dateEpochDay >= :fromDay ORDER BY dateEpochDay ASC, slotIndex ASC")
    fun observeFrom(fromDay: Long): Flow<List<ScheduleTaskEntity>>

    @Query("SELECT * FROM schedule_tasks WHERE dateEpochDay >= :fromDay ORDER BY dateEpochDay ASC, slotIndex ASC")
    suspend fun getFrom(fromDay: Long): List<ScheduleTaskEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<ScheduleTaskEntity>): List<Long>

    @Query("UPDATE schedule_tasks SET done = :done WHERE id = :id")
    suspend fun setDone(id: Long, done: Boolean)

    @Query("UPDATE schedule_tasks SET skipped = 1 WHERE id = :id")
    suspend fun setSkipped(id: Long)

    @Query("DELETE FROM schedule_tasks WHERE dateEpochDay >= :fromDay")
    suspend fun deleteFrom(fromDay: Long)

    @Query("DELETE FROM schedule_tasks")
    suspend fun clear()

    @Query("SELECT COUNT(*) FROM schedule_tasks WHERE done = 1 AND dateEpochDay < :day")
    suspend fun completedBefore(day: Long): Int

    @Transaction
    suspend fun replaceFrom(fromDay: Long, list: List<ScheduleTaskEntity>) {
        deleteFrom(fromDay)
        if (list.isNotEmpty()) insertAll(list)
    }
}

@Dao
interface SessionDao {
    @Query("SELECT * FROM study_sessions ORDER BY startedAt DESC")
    fun observeAll(): Flow<List<StudySessionEntity>>

    @Query("SELECT * FROM study_sessions WHERE startedAt >= :since")
    fun observeSince(since: Long): Flow<List<StudySessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(s: StudySessionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<StudySessionEntity>)

    @Query("SELECT COUNT(DISTINCT date(startedAt/1000, 'unixepoch', 'localtime')) FROM study_sessions WHERE minutes >= :minMinutes")
    fun observeActiveDayCount(minMinutes: Int): Flow<Int>

    @Query("SELECT * FROM study_sessions ORDER BY startedAt DESC")
    suspend fun getAll(): List<StudySessionEntity>

    @Query("SELECT COALESCE(SUM(minutes),0) FROM study_sessions")
    fun observeTotalMinutes(): Flow<Int>

    @Query("DELETE FROM study_sessions")
    suspend fun clear()
}

@Dao
interface XpDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(e: XpLedgerEntity): Long

    @Query("SELECT COALESCE(SUM(xp),0) FROM xp_ledger")
    fun observeXp(): Flow<Int>

    @Query("SELECT * FROM xp_ledger WHERE dayEpoch = :day")
    suspend fun forDay(day: Long): List<XpLedgerEntity>

    @Query("SELECT DISTINCT dayEpoch FROM xp_ledger WHERE reason = 'STUDY_DAY' ORDER BY dayEpoch DESC LIMIT :limit")
    fun observeRecentStudyDays(limit: Int): Flow<List<Long>>

    @Query("SELECT COALESCE(SUM(xp),0) FROM xp_ledger WHERE dayEpoch = :day")
    fun observeXpOn(day: Long): Flow<Int>

    @Query("SELECT * FROM xp_ledger ORDER BY id ASC")
    suspend fun getAll(): List<XpLedgerEntity>

    @Query("SELECT COALESCE(SUM(xp),0) FROM xp_ledger")
    suspend fun totalXp(): Int

    @Query("DELETE FROM xp_ledger")
    suspend fun clear()
}
