package ng.jamb.threehundredplus.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

// ---------------- Subjects ----------------

@Entity(tableName = "selected_subjects")
data class SelectedSubjectEntity(
    @PrimaryKey val subject: String,
    val orderIndex: Int,
    val alocCode: String
)

// ---------------- Syllabus ----------------

enum class TopicStatus { NOT_STARTED, LEARNING, DONE, NEEDS_REVISION }

@Entity(
    tableName = "topics",
    indices = [Index("subject"), Index("fingerprint", unique = true)]
)
data class TopicEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subject: String,
    val fingerprint: String,
    val title: String,
    val orderIndex: Int,
    val status: String = TopicStatus.NOT_STARTED.name,
    val isCustom: Boolean = false
)

// ---------------- Cached real questions ----------------

@Entity(
    tableName = "questions",
    indices = [Index("subject"), Index("fingerprint", unique = true), Index(value = ["subject", "year"])]
)
data class QuestionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fingerprint: String,
    val subject: String,
    val year: String?,
    val examType: String?,
    val source: String?,
    val questionText: String,
    val optionsJson: String,
    val answerIndex: Int?,
    val explanation: String?,
    val fetchedAt: Long
)

// ---------------- Mocks / attempts ----------------

@Entity(tableName = "mocks", indices = [Index("createdAt")])
data class MockEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val createdAt: Long,
    val startEpochMs: Long,
    val endEpochMs: Long,
    val submittedAt: Long?,
    val mode: String, // FULL_MOCK | PRACTICE | SUBJECT
    val status: String, // ACTIVE | SUBMITTED
    val subjectsJson: String,
    val questionIdsJson: String,
    val answersJson: String,
    val flagsJson: String,
    val currentIndex: Int,
    val totalScore: Double,
    val perSubjectJson: String
)

@Entity(tableName = "attempts", indices = [Index("mockId"), Index("questionId")])
data class AttemptEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val mockId: Long,
    val questionId: Long,
    val subject: String,
    val selectedIndex: Int?,
    val correct: Boolean,
    val answeredAt: Long
)

// ---------------- Mistakes / spaced review ----------------

@Entity(tableName = "mistakes", indices = [Index("questionId", unique = true), Index("nextReviewAt")])
data class MistakeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val questionId: Long,
    val subject: String,
    val timesMissed: Int,
    val timesReviewed: Int,
    val firstMissedAt: Long,
    val lastMissedAt: Long,
    val nextReviewAt: Long,
    val reviewStage: Int,
    val resolved: Boolean
)

// ---------------- Schedule ----------------

@Entity(tableName = "schedule_tasks", indices = [Index("dateEpochDay"), Index("subject")])
data class ScheduleTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateEpochDay: Long,
    val slotIndex: Int,
    val subject: String,
    val topicId: Long?,
    val topicTitle: String,
    val type: String, // LEARN | REVISE | PRACTICE
    val done: Boolean,
    val skipped: Boolean,
    val createdAt: Long
)

// ---------------- Study sessions ----------------

@Entity(tableName = "study_sessions", indices = [Index("startedAt")])
data class StudySessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startedAt: Long,
    val endedAt: Long,
    val minutes: Int,
    val subject: String?,
    val topicTitle: String?,
    val source: String
)

// ---------------- XP ledger (one row per day+reason to avoid duplicate awards) -------------

@Entity(tableName = "xp_ledger", indices = [Index(value = ["dayEpoch", "reason"], unique = true)])
data class XpLedgerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dayEpoch: Long,
    val reason: String,
    val xp: Int,
    val createdAt: Long
)
