package ng.jamb.threehundredplus.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import ng.jamb.threehundredplus.data.db.AttemptDao
import ng.jamb.threehundredplus.data.db.AttemptEntity
import ng.jamb.threehundredplus.data.db.MockDao
import ng.jamb.threehundredplus.data.db.MockEntity
import ng.jamb.threehundredplus.data.db.QuestionEntity
import ng.jamb.threehundredplus.domain.SubjectCatalogue

object MockMode { const val FULL = "FULL_MOCK"; const val PRACTICE = "PRACTICE"; const val SUBJECT = "SUBJECT" }
object MockStatus { const val ACTIVE = "ACTIVE"; const val SUBMITTED = "SUBMITTED" }

data class SubjectScore(val subject: String, val correct: Int, val total: Int) {
    val score: Double get() = if (total == 0) 0.0 else correct * 100.0 / total
}

data class MockResult(
    val mockId: Long,
    val total: Double,
    val perSubject: List<SubjectScore>,
    val wrongQuestions: List<Pair<QuestionEntity, Int>>,
    val unanswered: Int
)

class MockRepository(
    private val mockDao: MockDao,
    private val attemptDao: AttemptDao,
    private val questionRepo: QuestionRepository
) {
    fun observeAll(): Flow<List<MockEntity>> = mockDao.observeAll()
    fun observeSubmitted(limit: Int = 20): Flow<List<MockEntity>> = mockDao.observeSubmitted(limit)
    fun observeSubmittedCount(): Flow<Int> = mockDao.observeSubmittedCount()
    fun observeById(id: Long): Flow<MockEntity?> = mockDao.observeById(id)
    fun observeAttempts(mockId: Long): Flow<List<AttemptEntity>> = attemptDao.observeByMock(mockId)
    fun observeAllAttempts(): Flow<List<AttemptEntity>> = attemptDao.observeAll()

    suspend fun activeMock(): MockEntity? = mockDao.activeMock()
    suspend fun getById(id: Long): MockEntity? = mockDao.getById(id)
    suspend fun activeOrNullQuestions(m: MockEntity): List<QuestionEntity> = questionRepo.getByIds(Json.readLongSet(m.questionIdsJson).toList())

    suspend fun startMock(
        subjects: List<String>,
        questionIds: List<Long>,
        durationMinutes: Int,
        mode: String
    ): Long = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val entity = MockEntity(
            createdAt = now,
            startEpochMs = now,
            endEpochMs = now + durationMinutes * 60_000L,
            submittedAt = null,
            mode = mode,
            status = MockStatus.ACTIVE,
            subjectsJson = Json.writeStringList(subjects),
            questionIdsJson = Json.writeLongSet(questionIds.toSet()),
            answersJson = "{}",
            flagsJson = "[]",
            currentIndex = 0,
            totalScore = 0.0,
            perSubjectJson = "{}"
        )
        mockDao.upsert(entity)
    }

    suspend fun saveProgress(m: MockEntity) = withContext(Dispatchers.IO) { mockDao.upsert(m) }

    /**
     * Grades the mock: every subject is scored out of 100, giving a maximum of 400.
     */
    suspend fun grade(m: MockEntity): MockResult = withContext(Dispatchers.IO) {
        val questions = questionRepo.getByIds(Json.readLongSet(m.questionIdsJson).toList()).associateBy { it.id }
        val answers = Json.readIntMap(m.answersJson)
        val subjects = Json.readStringList(m.subjectsJson)
        val orderedIds = Json.readLongSet(m.questionIdsJson).toList()

        val bySubject = LinkedHashMap<String, Pair<Int, Int>>()
        subjects.forEach { bySubject[it] = 0 to 0 }
        val attempts = ArrayList<AttemptEntity>()
        val wrong = ArrayList<Pair<QuestionEntity, Int>>()
        var correctTotal = 0
        var answered = 0

        for (id in orderedIds) {
            val q = questions[id] ?: continue
            val (c, t) = bySubject.getOrPut(q.subject) { 0 to 0 }
            bySubject[q.subject] = c to (t + 1)
            val selected = answers[id]
            val correctIndex = q.answerIndex
            val isCorrect = correctIndex != null && selected != null && selected == correctIndex
            if (selected != null) {
                answered++
                attempts.add(
                    AttemptEntity(
                        mockId = m.id,
                        questionId = q.id,
                        subject = q.subject,
                        selectedIndex = selected,
                        correct = isCorrect,
                        answeredAt = System.currentTimeMillis()
                    )
                )
                if (isCorrect) {
                    correctTotal++
                    bySubject[q.subject] = (c + 1) to (t + 1)
                } else {
                    wrong.add(q to (selected ?: -1))
                }
            }
        }

        val perSubject = bySubject.map { (s, ct) -> SubjectScore(s, ct.first, ct.second) }
        val total = perSubject.sumOf { it.score }

        if (attempts.isNotEmpty()) attemptDao.insertAll(attempts)
        mockDao.upsert(
            m.copy(
                status = MockStatus.SUBMITTED,
                submittedAt = System.currentTimeMillis(),
                totalScore = total,
                perSubjectJson = Json.writeDoubleMap(perSubject.associate { it.subject to it.score })
            )
        )

        MockResult(m.id, total, perSubject, wrong, orderedIds.size - answered)
    }

    suspend fun delete(id: Long) = withContext(Dispatchers.IO) { mockDao.delete(id) }

    companion object {
        fun subjectOrder(subjects: List<String>): List<String> = buildList {
            if (subjects.contains(SubjectCatalogue.ENGLISH)) add(SubjectCatalogue.ENGLISH)
            subjects.filter { it != SubjectCatalogue.ENGLISH }.forEach { add(it) }
        }
    }
}
