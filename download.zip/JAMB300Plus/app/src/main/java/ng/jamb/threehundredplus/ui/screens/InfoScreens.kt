package ng.jamb.threehundredplus.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import ng.jamb.threehundredplus.ui.AppViewModel
import ng.jamb.threehundredplus.ui.InfoCard
import ng.jamb.threehundredplus.ui.SectionTitle

private const val JAMB = "https://www.jamb.gov.ng/"

private fun openExternally(context: android.content.Context, url: String) {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { context.startActivity(intent) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OfficialUpdatesScreen(nav: NavHostController) {
    val context = LocalContext.current
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Official updates") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { p ->
        LazyColumn(
            modifier = Modifier.padding(p).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                InfoCard(
                    title = "Always confirm on jamb.gov.ng",
                    body = "Syllabus, brochures, set texts, registration dates and fees change. JAMB 300+ only links out to " +
                        "the official site rather than restating information that may be out of date."
                )
            }
            item { SectionTitle("Open on jamb.gov.ng") }
            item { LinkRow("JAMB home — syllabus, news, updates", JAMB, context) }
            item {
                OutlinedButton(
                    onClick = { openExternally(context, JAMB) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) { Text("Open jamb.gov.ng") }
            }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }
}

@Composable
private fun LinkRow(label: String, url: String, context: android.content.Context) {
    Card(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 60.dp)
            .clickable { openExternally(context, url) }
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(label, style = MaterialTheme.typography.titleSmall)
            Text(url, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(nav: NavHostController) {
    val context = LocalContext.current
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("About") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { p ->
        LazyColumn(
            modifier = Modifier.padding(p).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Text("JAMB 300+", style = MaterialTheme.typography.headlineSmall) }
            item {
                Text(
                    "A study planner for the four JAMB subjects: syllabus tracking, a spaced revision schedule, a CBT mock " +
                        "built from real past questions, a mistake notebook with spaced review, focus timers and progress " +
                        "tracking.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            item {
                InfoCard(
                    title = "Question data: ALOC",
                    body = "Past questions are provided by ALOC (aloc.com.ng) using your own API key. JAMB 300+ does not " +
                        "bundle a key and does not generate, invent or alter questions or explanations. Where the provider " +
                        "does not supply a year, source or explanation, the app shows that nothing was supplied.",
                    actionLabel = "Visit ALOC",
                    onAction = { openExternally(context, "https://aloc.com.ng") }
                )
            }
            item {
                InfoCard(
                    title = "Syllabus disclaimer",
                    body = "The bundled topic structures are a study checklist, not the official JAMB syllabus for any year. " +
                        "Confirm the current syllabus, brochure and set texts on jamb.gov.ng."
                )
            }
            item {
                InfoCard(
                    title = "Score estimate",
                    body = "The predicted score is derived only from your own recorded data. It is an estimate for planning " +
                        "and is not a guaranteed JAMB score."
                )
            }
            item {
                InfoCard(
                    title = "Privacy",
                    body = "Your progress, schedule and history stay on this device. Your API key is stored locally and is " +
                        "excluded from backups unless you explicitly opt in."
                )
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FixRemindersScreen(vm: AppViewModel, nav: NavHostController) {
    val context = LocalContext.current
    val settings by vm.settings.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Reminders not showing?") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { p ->
        LazyColumn(
            modifier = Modifier.padding(p).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                InfoCard(
                    title = "Start with these checks",
                    body = "1. Slot reminders are switched on in Settings.\n" +
                        "2. Android 13+ needs notification permission.\n" +
                        "3. The app needs the exact-alarm capability, or it falls back to an approximate delivery time.\n" +
                        "4. Your study slots are set to a time you actually keep free."
                )
            }
            item { SectionTitle("Android system settings") }
            item {
                OutlinedButton(
                    onClick = {
                        ng.jamb.threehundredplus.reminders.ReminderScheduler.notificationSettingsIntent(context)
                            ?.let { runCatching { context.startActivity(it) } }
                    },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) { Text("App notification settings") }
            }
            item {
                OutlinedButton(
                    onClick = {
                        ng.jamb.threehundredplus.reminders.ReminderScheduler.exactAlarmSettingsIntent(context)
                            ?.let { runCatching { context.startActivity(it) } }
                    },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) { Text("Alarms & reminders permission") }
            }
            item {
                OutlinedButton(
                    onClick = {
                        ng.jamb.threehundredplus.reminders.ReminderScheduler.batterySettingsIntent()
                            ?.let { runCatching { context.startActivity(it) } }
                    },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) { Text("Battery optimisation settings") }
            }

            item { SectionTitle("Manufacturer battery managers") }
            item {
                Text(
                    "Phone makers add their own power-saving layer on top of Android. These menus are named differently " +
                        "depending on the model and software version, so look for something similar to the examples below " +
                        "rather than expecting an exact label.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            item { MakerCard("Tecno", "Settings → Battery → Battery settings / Background power management. Allow the app in \"Auto start\" and remove it from the restricted list.") }
            item { MakerCard("Infinix", "Settings → Battery → Battery management or \"Power mode\". Switch the app off power saving and allow background activity.") }
            item { MakerCard("Itel", "Settings → Battery → Power saving. Choose \"Customise\" or disable optimisation for JAMB 300+.") }
            item { MakerCard("Xiaomi", "Settings → Apps → Manage apps → JAMB 300+ → Battery saver → \"No restrictions\", and enable Autostart.") }
            item { MakerCard("Samsung", "Settings → Battery → Background usage limits. Set the app to \"Unrestricted\" and remove it from \"Apps that are never put to sleep\".") }

            item {
                Text(
                    "If a menu is missing on your device, your model or Android version handles it differently — use the " +
                        "standard Android settings buttons above instead.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }
}

@Composable
private fun MakerCard(name: String, guidance: String) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(name, style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(4.dp))
            Text(guidance, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
