package ng.jamb.threehundredplus.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import ng.jamb.threehundredplus.AppContainer
import ng.jamb.threehundredplus.JambApp
import ng.jamb.threehundredplus.data.BackupManager
import ng.jamb.threehundredplus.data.Json
import ng.jamb.threehundredplus.data.MockMode
import ng.jamb.threehundredplus.data.MockRepository
import ng.jamb.threehundredplus.data.MockStatus
import ng.jamb.threehundredplus.data.QuestionRepository
import ng.jamb.threehundredplus.data.RestoreResult
import ng.jamb.threehundredplus.data.ScheduleCoordinator
import ng.jamb.threehundredplus.data.SyllabusRepository
import ng.jamb.threehundredplus.data.TopicProgress
import ng.jamb.threehundredplus.data.db.MockEntity
import ng.jamb.threehundredplus.data.db.QuestionEntity
import ng.jamb.threehundredplus.data.db.ScheduleTaskEntity
import ng.jamb.threehundredplus.data.db.TopicEntity
import ng.jamb.threehundredplus.data.db.TopicStatus
import ng.jamb.threehundredplus.data.net.ConfigResult
import ng.jamb.threehundredplus.data.net.RemoteConfigService
import ng.jamb.threehundredplus.data.prefs.AppSettings
import ng.jamb.threehundredplus.domain.Prediction
import ng.jamb.threehundredplus.domain.PredictionInputs
import ng.jamb.threehundredplus.domain.Rank
import ng.jamb.threehundredplus.domain.Ranks
import ng.jamb.threehundredplus.domain.ScheduleGenerator
import ng.jamb.threehundredplus.domain.ScorePredictor
import ng.jamb.threehundredplus.domain.SubjectCatalogue
import java.time.LocalDate

data class AsyncState(
    val loading: Boolean = false,
    val message: String? = null,
    val isError: Boolean = false
)

data class FocusState(
    val running: Boolean = false,
    val paused: Boolean = false,
    val elapsedSeconds: Int = 0,
    val mode: String = "POMODORO",
    val subject: String? = null,
    val topic: String? = null,
    val taskId: Long = 0L,
    val totalSeconds: Int = 25 * 60
) {
    val remaining: Int get() = (totalSeconds - elapsedSeconds).coerceAtLeast(0)
    val finished: Boolean get() = elapsedSeconds >= totalSeconds
}

class AppViewModel(app: Application) : AndroidViewModel(app) {

    val container: AppContainer = (app as JambApp).container
    private val settingsStore = container.settingsStore
    private val syllabusRepo = container.syllabusRepo
    private val questionRepo = container.questionRepo
    private val mockRepo = container.mockRepo
    private val statsRepo = container.statsRepo
    private val mistakeRepo = container.mistakeRepo
    private val subjectRepo = container.subjectRepo
    private val coordinator: ScheduleCoordinator = container.scheduleCoordinator
    private val backup: BackupManager = container.backupManager

    val settings: StateFlow<AppSettings> = settingsStore.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    val busy = MutableStateFlow(AsyncState())
    val busySubject = MutableStateFlow("")

    init {
        viewModelScope.launch { runCatching { syllabusRepo.seedIfNeeded() } }
    }

    // ---------------- subjects & progress ----------------

    val progress: StateFlow<Map<String, TopicProgress>> = syllabusRepo.observeAllTopics()
        .map { topics ->
            SubjectCatalogue.ALL.associate { def ->
                val mine = topics.filter { it.subject == def.id }
                val done = mine.count { it.status == TopicStatus.DONE.name }
                val learning = mine.count { it.status == TopicStatus.LEARNING.name }
                val revision = mine.count { it.status == TopicStatus.NEEDS_REVISION.name }
                def.id to TopicProgress(def.id, mine.size, done, learning, revision)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    fun topicsFor(subject: String) = syllabusRepo.observeTopics(subject)

    val overallPercent: StateFlow<Int> = progress.map { m ->
        val total = m.values.sumOf { it.total }
        val done = m.values.sumOf { it.done }
        if (total == 0) 0 else (done * 100.0 / total).toInt()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun subjectProgress(subject: String): TopicProgress =
        progress.value[subject] ?: TopicProgress(subject, 0, 0, 0, 0)

    // ---------------- schedule ----------------

    val today: LocalDate get() = LocalDate.now()

    val todayTasks: StateFlow<List<ScheduleTaskEntity>> =
        settings.flatMapLatest { s ->
            coordinator.ensureSchedule()
            container.scheduleDao.observeDay(LocalDate.now().toEpochDay())
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val upcomingTasks: StateFlow<List<ScheduleTaskEntity>> =
        container.scheduleDao.observeFrom(LocalDate.now().toEpochDay() + 1)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val nextSlot: StateFlow<Pair<Int, Long>?> = settings
        .map { s ->
            val slots = ScheduleGenerator.parseSlots(s.slotTimes)
            if (slots.isEmpty()) null else ScheduleGenerator.nextSlotStart(slots, java.time.ZonedDateTime.now())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun regenerateSchedule() = viewModelScope.launch {
        busy.value = AsyncState(true)
        runCatching { coordinator.regenerate() }
            .onSuccess { busy.value = AsyncState(false, "Schedule regenerated.") }
            .onFailure { busy.value = AsyncState(false, "The schedule could not be rebuilt.", true) }
    }

    fun toggleTask(task: ScheduleTaskEntity) = viewModelScope.launch {
        val next = !task.done
        container.scheduleDao.setDone(task.id, next)
        if (next) statsRepo.awardXp("TASK_DONE:${task.id}", 10)
        container.rescheduleReminders()
    }

    // ---------------- stats, streak, rank, prediction ----------------

    val xp: StateFlow<Int> = statsRepo.xp().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val totalMinutes: StateFlow<Int> = statsRepo.totalMinutes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val activeDays: StateFlow<Int> = statsRepo.activeDays(10)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val rank: StateFlow<Rank> = xp.map { Ranks.forXp(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Ranks.ALL.first())

    val streakDays: StateFlow<Int> = statsRepo.recentStudyDays(400)
        .map { days -> computeStreak(days) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private fun computeStreak(days: List<Long>): Int {
        if (days.isEmpty()) return 0
        val set = days.toHashSet()
        val today = LocalDate.now().toEpochDay()
        var cursor = when {
            set.contains(today) -> today
            set.contains(today - 1) -> today - 1
            else -> return 0
        }
        var count = 0
        while (set.contains(cursor)) { count++; cursor-- }
        return count
    }

    val prediction: StateFlow<Prediction> = combine(
        combine(progress, mockRepo.observeSubmitted(10), settings) { p, mocks, s ->
            Triple(p, mocks, s)
        },
        combine(streakDays, activeDays, mistakeRepo.observeOpen()) { st, days, mk ->
            Triple(st, days, mk.size)
        }
    ) { left, right ->
        val (p, mocks, s) = left
        val (streak, days, mistakeCount) = right
        val done = p.values.sumOf { it.done }
        val total = p.values.sumOf { it.total }
        val coverage = if (total == 0) 0 else (done * 100.0 / total).toInt()
        val submitted = mocks.filter { it.status == MockStatus.SUBMITTED }
        val avg = submitted.map { it.totalScore / 4.0 }.takeIf { it.isNotEmpty() }?.average()
        ScorePredictor.predict(
            PredictionInputs(
                syllabusCompletionPercent = coverage,
                lastMockPercent = avg?.toInt(),
                mocksTaken = submitted.size,
                activeStudyDays = days,
                currentStreakDays = streak,
                openMistakes = mistakeCount
            ),
            s.targetScore
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ScorePredictor.predict(PredictionInputs(0, null, 0, 0, 0, 0), 300))

    // ---------------- questions ----------------

    fun questionCount(subject: String) = questionRepo.countBySubject(subject)
    val totalCachedQuestions = questionRepo.totalCount()

    suspend fun yearsFor(subject: String): List<String> = questionRepo.years(subject).first()

    suspend fun availability(subjects: List<String>) = questionRepo.availability(subjects)

    fun fetchQuestions(subject: String, onDone: (Int, String?) -> Unit = { _, _ -> }) = viewModelScope.launch {
        val s = settings.value
        if (!s.hasApiKey) {
            onDone(0, "Add your ALOC API key in Settings → Question Source first.")
            return@launch
        }
        busySubject.value = subject
        busy.value = AsyncState(true)
        try {
            val code = container.database.subjectDao().get().firstOrNull { it.subject == subject }?.alocCode
            val outcome = questionRepo.fetch(s.apiKey, subject, code)
            busy.value = AsyncState(false, "Added ${outcome.inserted} real questions to ${SubjectCatalogue.shortOf(subject)}.")
            onDone(outcome.inserted, null)
        } catch (e: Throwable) {
            val msg = (e as? ng.jamb.threehundredplus.data.net.AlocError)?.userMessage
                ?: "Questions could not be downloaded. Please try again."
            busy.value = AsyncState(false, msg, true)
            onDone(0, msg)
        } finally {
            busySubject.value = ""
            busy.value = busy.value.copy(loading = false)
        }
    }

    fun fetchAllMissing(subjects: List<String>) = viewModelScope.launch {
        val s = settings.value
        if (!s.hasApiKey) {
            busy.value = AsyncState(false, "Add your ALOC API key in Settings → Question Source first.", true)
            return@launch
        }
        busy.value = AsyncState(true, "Downloading real past questions…")
        var added = 0
        var lastError: String? = null
        for (subject in subjects) {
            try {
                val code = container.database.subjectDao().get().firstOrNull { it.subject == subject }?.alocCode
                val outcome = questionRepo.fetch(s.apiKey, subject, code)
                added += outcome.inserted
            } catch (e: Throwable) {
                lastError = (e as? ng.jamb.threehundredplus.data.net.AlocError)?.userMessage
                    ?: "Download failed for ${SubjectCatalogue.shortOf(subject)}."
            }
        }
        busy.value = if (added > 0) AsyncState(false, "Added $added real questions.")
        else AsyncState(false, lastError ?: "No new questions were downloaded.", lastError != null)
    }

    // ---------------- practice ----------------

    private val _practice = MutableStateFlow<PracticeState?>(null)

    data class PracticeState(
        val title: String,
        val questions: List<QuestionEntity>,
        val index: Int = 0,
        val answers: Map<Long, Int> = emptyMap(),
        val flags: Set<Long> = emptySet(),
        val revealed: Set<Long> = emptySet(),
        val finished: Boolean = false,
        val durationMinutes: Int = 0,
        val mockId: Long = 0L
    )

    val practice = _practice.asStateFlow()

    fun startPractice(subject: String, year: String?, limit: Int) = viewModelScope.launch {
        val all = container.database.questionDao().recent(subject, 800)
        if (all.isEmpty()) {
            busy.value = AsyncState(
                false,
                "No real questions cached for ${SubjectCatalogue.shortOf(subject)} yet. Fetch them first.",
                true
            )
            return@launch
        }
        val filtered = all.filter { year == null || it.year == year }
        val chosen = filtered.take(limit)
        if (chosen.isEmpty()) {
            busy.value = AsyncState(
                false,
                "No cached questions match that year filter for ${SubjectCatalogue.shortOf(subject)}.",
                true
            )
            return@launch
        }
        _practice.value = PracticeState(
            title = if (year == null) "${SubjectCatalogue.nameOf(subject)} practice" else "$subject • $year",
            questions = chosen
        )
    }

    fun answerPractice(qid: Long, option: Int) {
        val st = _practice.value ?: return
        _practice.value = st.copy(answers = st.answers + (qid to option))
    }

    fun flagPractice(qid: Long) {
        val st = _practice.value ?: return
        val flags = st.flags.toMutableSet()
        if (!flags.add(qid)) flags.remove(qid)
        _practice.value = st.copy(flags = flags)
    }

    fun revealPractice(qid: Long) {
        val st = _practice.value ?: return
        _practice.value = st.copy(revealed = st.revealed + qid)
    }

    fun jumpPractice(i: Int) {
        val st = _practice.value ?: return
        _practice.value = st.copy(index = i.coerceIn(0, (st.questions.size - 1).coerceAtLeast(0)))
    }

    fun submitPractice() {
        val st = _practice.value ?: return
        viewModelScope.launch {
            st.questions.forEach { q ->
                val sel = st.answers[q.id]
                val correct = q.answerIndex != null && sel != null && sel == q.answerIndex
                if (sel != null && !correct) mistakeRepo.recordWrong(q)
            }
            statsRepo.awardXp("PRACTICE_DONE", 20)
            _practice.value = st.copy(finished = true)
        }
    }

    fun endPractice() { _practice.value = null }

    // ---------------- mock ----------------

    private val _activeMock = MutableStateFlow<MockEntity?>(null)
    val activeMock = _activeMock.asStateFlow()

    private val _mockQuestions = MutableStateFlow<List<QuestionEntity>>(emptyList())
    val mockQuestions = _mockQuestions.asStateFlow()

    private val _mockResult = MutableStateFlow<ng.jamb.threehundredplus.data.MockResult?>(null)
    val mockResult = _mockResult.asStateFlow()

    val mockRepoSubmitted = mockRepo.observeSubmitted(20)
    val allMocks = mockRepo.observeAll()

    private val _now = MutableStateFlow(System.currentTimeMillis())
    val now = _now.asStateFlow()

    init {
        viewModelScope.launch {
            while (true) {
                kotlinx.coroutines.delay(1000)
                _now.value = System.currentTimeMillis()
                val m = _activeMock.value
                if (m != null && System.currentTimeMillis() > m.endEpochMs && m.status == MockStatus.ACTIVE) {
                    gradeActiveMock()
                }
            }
        }
    }

    fun refreshActiveMock() = viewModelScope.launch {
        val m = mockRepo.activeMock() ?: return@launch
        _activeMock.value = m
        _mockQuestions.value = questionRepo.getByIds(Json.readLongSet(m.questionIdsJson).toList())
    }

    private val _availability = MutableStateFlow<List<ng.jamb.threehundredplus.data.SubjectAvailability>?>(null)
    val availability = _availability.asStateFlow()

    fun prepareFullMock() = viewModelScope.launch {
        _availability.value = questionRepo.availability(orderedSelected())
    }

    fun startFullMock() = viewModelScope.launch {
        val subjects = orderedSelected()
        val report = questionRepo.availability(subjects)
        val short = report.filter { !it.enough }
        if (short.isNotEmpty()) {
            busy.value = AsyncState(
                false,
                "Not enough real questions yet: " + short.joinToString(", ") {
                    "${SubjectCatalogue.shortOf(it.subject)} ${it.cached}/${it.required}"
                },
                true
            )
            return@launch
        }
        val ids = ArrayList<Long>()
        for (a in report) {
            val needed = a.required
            val available = container.database.questionDao().recent(a.subject, needed * 2)
            if (available.size < needed) {
                busy.value = AsyncState(false, "Not enough real questions for ${SubjectCatalogue.shortOf(a.subject)}.", true)
                return@launch
            }
            ids.addAll(available.take(needed).map { it.id })
        }
        val id = mockRepo.startMock(subjects, ids, QuestionRepository.MOCK_DURATION_MINUTES, MockMode.FULL)
        val created = mockRepo.getById(id)
        if (created != null) {
            _activeMock.value = created
            _mockQuestions.value = questionRepo.getByIds(Json.readLongSet(created.questionIdsJson).toList())
        }
    }

    fun setMockAnswer(qid: Long, option: Int) {
        val m = _activeMock.value ?: return
        val answers = Json.readIntMap(m.answersJson).toMutableMap()
        answers[qid] = option
        viewModelScope.launch { mockRepo.saveProgress(m.copy(answersJson = Json.writeIntMap(answers))) }
    }

    fun toggleMockFlag(qid: Long) {
        val m = _activeMock.value ?: return
        val flags = Json.readLongSet(m.flagsJson).toMutableSet()
        if (!flags.add(qid)) flags.remove(qid)
        viewModelScope.launch { mockRepo.saveProgress(m.copy(flagsJson = Json.writeLongSet(flags))) }
    }

    fun setMockIndex(i: Int) {
        val m = _activeMock.value ?: return
        viewModelScope.launch { mockRepo.saveProgress(m.copy(currentIndex = i.coerceAtLeast(0))) }
    }

    fun submitActiveMock() = viewModelScope.launch { gradeActiveMock() }

    fun discardActiveMock() = viewModelScope.launch {
        val m = _activeMock.value ?: return@launch
        mockRepo.delete(m.id)
        _activeMock.value = null
        _mockQuestions.value = emptyList()
    }

    private suspend fun gradeActiveMock() {
        val m = _activeMock.value ?: return
        val result = mockRepo.grade(m)
        result.wrongQuestions.forEach { (q, _) -> mistakeRepo.recordWrong(q) }
        statsRepo.awardXp("MOCK_SUBMITTED:${m.id}", 100)
        _mockResult.value = result
        _activeMock.value = null
        _mockQuestions.value = emptyList()
    }

    fun openMockResult(mock: MockEntity) = viewModelScope.launch {
        val qs = questionRepo.getByIds(Json.readLongSet(mock.questionIdsJson).toList())
        val answers = Json.readIntMap(mock.answersJson)
        val perSubject = Json.readDoubleMap(mock.perSubjectJson).map { (s, v) ->
            ng.jamb.threehundredplus.data.SubjectScore(
                s, (v / 100.0 * qs.count { it.subject == s }).toInt(), qs.count { it.subject == s }
            )
        }
        val wrong = qs.filter { q -> answers[q.id] != null && answers[q.id] != q.answerIndex }.map { q -> q to (answers[q.id] ?: -1) }
        _mockResult.value = ng.jamb.threehundredplus.data.MockResult(mock.id, mock.totalScore, perSubject, wrong, qs.size - answers.size)
    }

    fun clearMockResult() { _mockResult.value = null }

    // ---------------- mistakes ----------------

    val openMistakes = mistakeRepo.observeOpen()

    fun resolveMistake(id: Long) = viewModelScope.launch { mistakeRepo.resolve(id) }

    fun reviewMistake(m: ng.jamb.threehundredplus.data.db.MistakeEntity, correct: Boolean) = viewModelScope.launch {
        mistakeRepo.markReviewed(m, correct)
        if (correct) statsRepo.awardXp("REVIEW_OK:${m.id}", 5)
    }

    // ---------------- focus timer ----------------

    private val _focus = MutableStateFlow(FocusState())
    val focus = _focus.asStateFlow()
    private var focusJob: kotlinx.coroutines.Job? = null

    fun startFocus(subject: String?, topic: String?, taskId: Long, mode: String) {
        val total = if (mode == "SLOT") 60 * 60 else 25 * 60
        _focus.value = FocusState(
            running = true, elapsedSeconds = 0, mode = mode,
            subject = subject, topic = topic, taskId = taskId, totalSeconds = total
        )
        launchFocusTicker()
    }

    fun pauseFocus() {
        focusJob?.cancel()
        focusJob = null
        _focus.value = _focus.value.copy(running = false, paused = true)
    }

    fun resumeFocus() {
        _focus.value = _focus.value.copy(running = true, paused = false)
        launchFocusTicker()
    }

    private fun launchFocusTicker() {
        focusJob?.cancel()
        focusJob = viewModelScope.launch {
            while (true) {
                kotlinx.coroutines.delay(1000)
                val f = _focus.value
                if (!f.running) break
                val next = f.copy(elapsedSeconds = f.elapsedSeconds + 1)
                _focus.value = next
                if (next.finished) { completeFocus(); break }
            }
        }
    }

    private suspend fun completeFocus() {
        val f = _focus.value
        val minutes = (f.elapsedSeconds / 60).coerceAtLeast(1)
        statsRepo.logSession(minutes, f.subject, f.topic, f.mode)
        statsRepo.awardXp("FOCUS_${f.mode}_$minutes", 5 * minutes)
        focusJob = null
        _focus.value = f.copy(running = false, paused = true)
    }

    fun stopFocus() {
        focusJob?.cancel()
        focusJob = null
        _focus.value = FocusState()
    }

    // ---------------- syllabus mutations ----------------

    fun setTopicStatus(topic: TopicEntity, status: TopicStatus) = viewModelScope.launch {
        syllabusRepo.setStatus(topic.id, status)
        if (status == TopicStatus.DONE) statsRepo.awardXp("TOPIC_DONE:${topic.id}", 5)
    }

    fun addCustomTopic(subject: String, title: String) = viewModelScope.launch {
        syllabusRepo.addCustomTopic(subject, title)
        busy.value = AsyncState(false, "Topic added.")
    }

    fun deleteCustomTopic(id: Long) = viewModelScope.launch { syllabusRepo.deleteCustomTopic(id) }

    // ---------------- settings ----------------

    fun completeOnboarding(subjects: List<String>, target: Int) = viewModelScope.launch {
        subjectRepo.save(subjects)
        settingsStore.setSelectedSubjects(subjects)
        settingsStore.setTargetScore(target)
        syllabusRepo.seedIfNeeded()
        settingsStore.setOnboardingDone(true)
        coordinator.regenerate()
        container.rescheduleReminders()
    }

    fun setTheme(mode: String) = viewModelScope.launch { settingsStore.setTheme(mode) }
    fun setTarget(v: Int) = viewModelScope.launch { settingsStore.setTargetScore(v) }
    fun setApiKey(key: String) = viewModelScope.launch { settingsStore.setApiKey(key) }
    fun clearApiKey() = viewModelScope.launch { settingsStore.clearApiKey() }
    fun setReminders(on: Boolean) = viewModelScope.launch {
        settingsStore.setRemindersEnabled(on)
        if (on) coordinator.reschedule() else container.rescheduleReminders()
    }
    fun setLead(minutes: Int) = viewModelScope.launch {
        settingsStore.setReminderLead(minutes)
        coordinator.reschedule()
    }
    fun setSlots(slots: List<String>) = viewModelScope.launch {
        settingsStore.setSlots(slots)
        coordinator.reschedule()
    }
    fun setSubjectCode(subject: String, code: String) = viewModelScope.launch { subjectRepo.setCode(subject, code) }
    fun setBackupIncludeKey(v: Boolean) = viewModelScope.launch { settingsStore.setBackupIncludeKey(v) }
    fun setRemoteConfigUrl(url: String) = viewModelScope.launch { settingsStore.setRemoteConfigUrl(url) }

    fun fetchRemoteConfig() = viewModelScope.launch {
        val url = settings.value.remoteConfigUrl
        busy.value = AsyncState(true, "Checking configuration…")
        when (val r = container.remoteConfig.fetch(url)) {
            is ConfigResult.Loaded -> busy.value = AsyncState(false, "Configuration updated.")
            is ConfigResult.Failed -> busy.value = AsyncState(false, r.message, true)
        }
    }

    fun exportBackup(uri: android.net.Uri, onDone: (String?) -> Unit) = viewModelScope.launch {
        busy.value = AsyncState(true, "Preparing backup…")
        runCatching { backup.export(uri, settings.value) }
            .onSuccess { onDone("Backup saved (${it.topics} topics, ${it.schedule} scheduled tasks).") }
            .onFailure { onDone("The backup could not be written.") }
        busy.value = busy.value.copy(loading = false)
    }

    fun importBackup(uri: android.net.Uri) = viewModelScope.launch {
        busy.value = AsyncState(true, "Restoring…")
        when (val r = backup.import(uri, settings.value)) {
            is RestoreResult.Success -> {
                syllabusRepo.seedIfNeeded()
                container.rescheduleReminders()
                busy.value = AsyncState(false, "Restored ${r.summary.topics} topics and ${r.summary.schedule} tasks.")
            }
            is RestoreResult.Failure -> busy.value = AsyncState(false, r.reason, true)
        }
    }

    fun resetEverything() = viewModelScope.launch {
        runCatching {
            container.database.clearAllTables()
            settingsStore.setOnboardingDone(false)
            settingsStore.setSelectedSubjects(listOf(SubjectCatalogue.ENGLISH, "mathematics", "physics", "chemistry"))
            settingsStore.setTargetScore(300)
            syllabusRepo.seedIfNeeded()
        }
        busy.value = AsyncState(false, "All app data was reset.")
    }

    fun clearMessage() { busy.value = AsyncState() }

    fun orderedSelected(): List<String> = MockRepository.subjectOrder(settings.value.selectedSubjects)

    companion object {
        fun factory(app: Application): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = AppViewModel(app) as T
        }
    }
}
