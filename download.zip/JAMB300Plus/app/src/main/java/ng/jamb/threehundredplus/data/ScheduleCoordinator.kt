package ng.jamb.threehundredplus.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import ng.jamb.threehundredplus.data.db.MistakeDao
import ng.jamb.threehundredplus.data.db.ScheduleDao
import ng.jamb.threehundredplus.data.db.ScheduleTaskEntity
import ng.jamb.threehundredplus.data.db.TopicDao
import ng.jamb.threehundredplus.data.prefs.SettingsStore
import ng.jamb.threehundredplus.domain.ScheduleGenerator
import ng.jamb.threehundredplus.reminders.ReminderScheduler
import java.time.LocalDate

class ScheduleCoordinator(
    private val context: Context,
    private val scheduleDao: ScheduleDao,
    private val topicDao: TopicDao,
    private val mistakeDao: MistakeDao,
    private val settingsStore: SettingsStore
) {
    /** Days of plan to produce. When the exam date is known, plan right up to it. */
    private fun horizonDays(examDate: LocalDate?): Int {
        if (examDate == null) return DEFAULT_HORIZON
        val days = java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), examDate).toInt()
        return days.coerceIn(7, 365)
    }

    suspend fun ensureSchedule() = withContext(Dispatchers.IO) {
        val today = LocalDate.now()
        val existing = scheduleDao.getFrom(today.toEpochDay())
        if (existing.isNotEmpty()) return@withContext
        regenerate()
    }

    suspend fun regenerate(): Int = withContext(Dispatchers.IO) {
        val settings = settingsStore.settings.first()
        val subjects = settings.selectedSubjects.ifEmpty { listOf("use_of_english") }
        val topics = topicDao.getAll().groupBy { it.subject }
        val openMistakes = mistakeDao.open().groupingBy { it.subject }.eachCount()
        val examDate = examDateOrNull(settings.examDateEpochMs)

        val today = LocalDate.now()
        val carried = scheduleDao.getFrom(today.toEpochDay())
            .filter { !it.done && !it.skipped && it.dateEpochDay > today.toEpochDay() }

        val plan = ScheduleGenerator.generate(
            ScheduleGenerator.Input(
                subjects = subjects,
                topicsBySubject = topics,
                slots = settings.slotTimes,
                startDate = today,
                horizonDays = horizonDays(examDate),
                carriedOver = carried,
                mistakesBySubject = openMistakes
            )
        )
        if (plan.isEmpty()) return@withContext 0
        scheduleDao.replaceFrom(today.toEpochDay(), plan)
        reschedule(settings.slotTimes, settings.reminderLeadMinutes, settings.remindersEnabled)
        plan.size
    }

    suspend fun reschedule() = withContext(Dispatchers.IO) {
        val settings = settingsStore.settings.first()
        reschedule(settings.slotTimes, settings.reminderLeadMinutes, settings.remindersEnabled)
    }

    private suspend fun reschedule(slots: List<String>, lead: Int, enabled: Boolean) {
        if (!enabled) {
            ReminderScheduler.cancelAll(context)
            return
        }
        val tasks = scheduleDao.getFrom(LocalDate.now().toEpochDay())
        ReminderScheduler.cancelAll(context)
        ReminderScheduler.rescheduleAll(context, tasks, lead, slots)
    }

    private fun examDateOrNull(epochMs: Long): LocalDate? =
        if (epochMs <= 0) null else runCatching {
            java.time.Instant.ofEpochMilli(epochMs).atZone(java.time.ZoneId.systemDefault()).toLocalDate()
        }.getOrNull()

    companion object { const val DEFAULT_HORIZON = 42 }
}
