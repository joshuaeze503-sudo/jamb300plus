package ng.jamb.threehundredplus.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import ng.jamb.threehundredplus.data.db.AttemptDao
import ng.jamb.threehundredplus.data.db.AttemptEntity
import ng.jamb.threehundredplus.data.db.MistakeDao
import ng.jamb.threehundredplus.data.db.MistakeEntity
import ng.jamb.threehundredplus.data.db.QuestionEntity
import ng.jamb.threehundredplus.data.db.SelectedSubjectEntity
import ng.jamb.threehundredplus.data.db.QuestionDao
import ng.jamb.threehundredplus.data.db.SessionDao
import ng.jamb.threehundredplus.data.db.StudySessionEntity
import ng.jamb.threehundredplus.data.db.SubjectDao
import ng.jamb.threehundredplus.data.db.TopicDao
import ng.jamb.threehundredplus.data.db.TopicEntity
import ng.jamb.threehundredplus.data.db.TopicStatus
import ng.jamb.threehundredplus.data.db.XpDao
import ng.jamb.threehundredplus.data.db.XpLedgerEntity
import ng.jamb.threehundredplus.domain.SubjectCatalogue
import java.time.LocalDate

class SyllabusRepository(
    private val topicDao: TopicDao,
    private val subjectDao: SubjectDao
) {
    fun observeTopics(subject: String): Flow<List<TopicEntity>> = topicDao.observeBySubject(subject)
    fun observeAllTopics(): Flow<List<TopicEntity>> = topicDao.observeAll()
    fun observeTopicCount(): Flow<Int> = topicDao.observeCount()
    fun observeSelectedSubjects(): Flow<List<SelectedSubjectEntity>> = subjectDao.observe()

    suspend fun seedIfNeeded() = withContext(Dispatchers.IO) {
        val existing = topicDao.getAll().map { it.fingerprint }.toHashSet()
        val rows = ArrayList<TopicEntity>()
        for (def in SubjectCatalogue.ALL) {
            def.topics.forEachIndexed { index, title ->
                val fp = SubjectCatalogue.fingerprint(def.id, title)
                if (fp !in existing) {
                    rows.add(TopicEntity(subject = def.id, fingerprint = fp, title = title, orderIndex = index))
                }
            }
        }
        if (rows.isNotEmpty()) topicDao.insertAll(rows)
    }

    suspend fun setStatus(topicId: Long, status: TopicStatus) = topicDao.setStatus(topicId, status.name)

    suspend fun addCustomTopic(subject: String, title: String) = withContext(Dispatchers.IO) {
        val clean = title.trim()
        if (clean.isEmpty()) return@withContext
        val base = TopicEntity(
            subject = subject,
            fingerprint = SubjectCatalogue.fingerprint(subject, clean),
            title = clean,
            orderIndex = (9000 + (System.currentTimeMillis() % 1000)).toInt()
        )
        topicDao.insertAll(listOf(base))
    }

    suspend fun deleteCustomTopic(id: Long) = topicDao.deleteCustom(id)

    suspend fun subjectProgress(): Map<String, TopicProgress> = withContext(Dispatchers.IO) {
        val all = topicDao.getAll()
        SubjectCatalogue.ALL.associate { def ->
            val mine = all.filter { it.subject == def.id }
            val done = mine.count { it.status == TopicStatus.DONE.name }
            val learning = mine.count { it.status == TopicStatus.LEARNING.name }
            val revision = mine.count { it.status == TopicStatus.NEEDS_REVISION.name }
            def.id to TopicProgress(def.id, mine.size, done, learning, revision)
        }
    }
}

data class TopicProgress(
    val subject: String,
    val total: Int,
    val done: Int,
    val learning: Int,
    val needsRevision: Int
) {
    val percent: Int get() = if (total == 0) 0 else ((done * 100.0) / total).toInt()
}

class StatsRepository(
    private val xpDao: XpDao,
    private val sessionDao: SessionDao,
    private val attemptDao: AttemptDao
) {
    fun xp(): Flow<Int> = xpDao.observeXp()
    fun totalMinutes(): Flow<Int> = sessionDao.observeTotalMinutes()
    fun activeDays(minMinutes: Int): Flow<Int> = sessionDao.observeActiveDayCount(minMinutes)
    fun recentStudyDays(limit: Int): Flow<List<Long>> = xpDao.observeRecentStudyDays(limit)
    fun attemptsSince(since: Long): Flow<Int> = attemptDao.observeCountSince(since)
    fun sessionsSince(since: Long): Flow<List<StudySessionEntity>> = sessionDao.observeSince(since)

    /**
     * Awards XP once per day per reason. The unique index on (dayEpoch, reason)
     * means a repeat call is a no-op, so XP cannot be farmed by retrying an action.
     */
    suspend fun awardXp(reason: String, xp: Int, day: Long = LocalDate.now().toEpochDay()) =
        withContext(Dispatchers.IO) {
            xpDao.insert(XpLedgerEntity(dayEpoch = day, reason = reason, xp = xp, createdAt = System.currentTimeMillis()))
        }

    suspend fun logSession(minutes: Int, subject: String?, topicTitle: String?, source: String) =
        withContext(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            sessionDao.insert(
                StudySessionEntity(
                    startedAt = now - minutes * 60_000L,
                    endedAt = now,
                    minutes = minutes,
                    subject = subject,
                    topicTitle = topicTitle,
                    source = source
                )
            )
        }
}

class MistakeRepository(
    private val mistakeDao: MistakeDao,
    private val questionDao: QuestionDao
) {
    fun observeOpen(): Flow<List<MistakeEntity>> = mistakeDao.observeOpen()
    fun observeAll(): Flow<List<MistakeEntity>> = mistakeDao.observeAll()

    suspend fun recordWrong(question: QuestionEntity, now: Long = System.currentTimeMillis()) =
        withContext(Dispatchers.IO) {
            val existing = mistakeDao.getByQuestion(question.id)
            if (existing == null) {
                mistakeDao.insert(
                    MistakeEntity(
                        questionId = question.id,
                        subject = question.subject,
                        timesMissed = 1,
                        timesReviewed = 0,
                        firstMissedAt = now,
                        lastMissedAt = now,
                        nextReviewAt = now + REVIEW_DAYS[0],
                        reviewStage = 0,
                        resolved = false
                    )
                )
            } else {
                mistakeDao.incrementMiss(question.id, now, now + REVIEW_DAYS[0])
            }
        }

    suspend fun markReviewed(m: MistakeEntity, answeredCorrectly: Boolean, now: Long = System.currentTimeMillis()) =
        withContext(Dispatchers.IO) {
            val stage = if (answeredCorrectly) (m.reviewStage + 1).coerceAtMost(REVIEW_DAYS.lastIndex) else 0
            val next = now + REVIEW_DAYS[stage]
            mistakeDao.markReviewed(m.id, stage, next)
            if (answeredCorrectly && stage >= REVIEW_DAYS.lastIndex) mistakeDao.resolve(m.id)
        }

    suspend fun resolve(id: Long) = withContext(Dispatchers.IO) { mistakeDao.resolve(id) }
    suspend fun clearAll() = withContext(Dispatchers.IO) { mistakeDao.clear() }
    suspend fun questionsFor(mistakes: List<MistakeEntity>): List<QuestionEntity> =
        withContext(Dispatchers.IO) {
            val ids = mistakes.map { it.questionId }
            if (ids.isEmpty()) emptyList() else questionDao.getByIds(ids).sortedBy { ids.indexOf(it.id) }
        }

    companion object {
        val REVIEW_DAYS = listOf(1L, 3L, 7L, 14L).map { it * 24L * 60L * 60L * 1000L }
    }
}

class SubjectSelectionRepository(private val subjectDao: SubjectDao) {
    fun observe(): Flow<List<SelectedSubjectEntity>> = subjectDao.observe()
    suspend fun save(subjects: List<String>) = withContext(Dispatchers.IO) {
        val english = SubjectCatalogue.ENGLISH
        val ordered = buildList {
            if (subjects.contains(english)) add(english)
            subjects.filter { it != english }.forEach { add(it) }
        }.distinct().take(4)
        subjectDao.upsertAll(
            ordered.mapIndexed { index, s ->
                SelectedSubjectEntity(
                    subject = s,
                    orderIndex = index,
                    alocCode = SubjectCatalogue.defaultCode(s)
                )
            }
        )
    }
    suspend fun setCode(subject: String, code: String) = subjectDao.updateCode(subject, code.trim())
    suspend fun replaceAll(subjects: List<String>) = withContext(Dispatchers.IO) {
        subjectDao.clear()
        val ordered = buildList {
            if (subjects.contains(SubjectCatalogue.ENGLISH)) add(SubjectCatalogue.ENGLISH)
            subjects.filter { it != SubjectCatalogue.ENGLISH }.forEach { add(it) }
        }.distinct().take(4)
        subjectDao.upsertAll(
            ordered.mapIndexed { index, s ->
                SelectedSubjectEntity(subject = s, orderIndex = index, alocCode = SubjectCatalogue.defaultCode(s))
            }
        )
    }
}
