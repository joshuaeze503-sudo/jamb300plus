package ng.jamb.threehundredplus.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Brand = Color(0xFF1B6EF3)
private val BrandDark = Color(0xFF0B1F3A)
private val Mint = Color(0xFF2FBF8F)
private val Amber = Color(0xFFF2B705)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8FB8FF),
    onPrimary = Color(0xFF002E60),
    primaryContainer = Color(0xFF1B4E9B),
    onPrimaryContainer = Color(0xFFD6E3FF),
    secondary = Mint,
    onSecondary = Color(0xFF00382A),
    secondaryContainer = Color(0xFF005140),
    onSecondaryContainer = Color(0xFF8CF6D1),
    tertiary = Amber,
    onTertiary = Color(0xFF3E2E00),
    background = Color(0xFF0E1116),
    onBackground = Color(0xFFE2E6EC),
    surface = Color(0xFF0E1116),
    onSurface = Color(0xFFE2E6EC),
    surfaceVariant = Color(0xFF1B2027),
    onSurfaceVariant = Color(0xFFC2C8D2),
    surfaceContainer = Color(0xFF161A20),
    surfaceContainerHigh = Color(0xFF1E232B),
    outline = Color(0xFF8C93A0),
    outlineVariant = Color(0xFF3A414C),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
)

private val LightColors = lightColorScheme(
    primary = Brand,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E3FF),
    onPrimaryContainer = BrandDark,
    secondary = Color(0xFF0E7A5E),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFA6F2D8),
    onSecondaryContainer = Color(0xFF00281D),
    tertiary = Color(0xFF8A6400),
    onTertiary = Color.White,
    background = Color(0xFFF7F9FC),
    onBackground = Color(0xFF10141A),
    surface = Color(0xFFF7F9FC),
    onSurface = Color(0xFF10141A),
    surfaceVariant = Color(0xFFE6EAF1),
    onSurfaceVariant = Color(0xFF454B54),
    surfaceContainer = Color(0xFFEFF2F7),
    surfaceContainerHigh = Color(0xFFE9EDF4),
    outline = Color(0xFF757B85),
    outlineVariant = Color(0xFFC6CBD4),
    error = Color(0xFFBA1A1A),
    onError = Color.White,
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
)

enum class ThemeMode { DARK, LIGHT }

@Composable
fun JambTheme(themeMode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (themeMode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    val colors = if (dark || isSystemInDarkTheme() && themeMode == ThemeMode.DARK) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = JambTypography,
        content = content
    )
}
