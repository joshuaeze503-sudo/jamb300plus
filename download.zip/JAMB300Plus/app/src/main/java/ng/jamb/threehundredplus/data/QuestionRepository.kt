package ng.jamb.threehundredplus.data

import ng.jamb.threehundredplus.data.db.QuestionDao
import ng.jamb.threehundredplus.data.db.QuestionEntity
import ng.jamb.threehundredplus.data.net.AlocClient
import ng.jamb.threehundredplus.data.net.AlocError
import ng.jamb.threehundredplus.data.net.AlocQuestionDto
import ng.jamb.threehundredplus.domain.SubjectCatalogue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

data class SubjectAvailability(val subject: String, val cached: Int, val required: Int) {
    val enough: Boolean get() = cached >= required
    val shortfall: Int get() = (required - cached).coerceAtLeast(0)
}

data class FetchOutcome(val subject: String, val inserted: Int, val fromCache: Int, val endpoint: String)

class QuestionRepository(
    private val dao: QuestionDao,
    private val client: AlocClient
) {

    fun countBySubject(subject: String): Flow<Int> = dao.observeCountBySubject(subject)
    fun totalCount(): Flow<Int> = dao.observeTotalCount()
    fun years(subject: String): Flow<List<String>> = dao.observeYears(subject)

    suspend fun availability(subjects: List<String>): List<SubjectAvailability> =
        withContext(Dispatchers.IO) {
            subjects.map { s ->
                SubjectAvailability(s, dao.countBySubject(s), requiredFor(s))
            }
        }

    fun requiredFor(subject: String): Int =
        if (subject == SubjectCatalogue.ENGLISH) MOCK_ENGLISH_COUNT else MOCK_OTHER_COUNT

    fun questionsBySubject(subject: String): Flow<List<QuestionEntity>> = dao.observeBySubject(subject)

    suspend fun getByIds(ids: List<Long>): List<QuestionEntity> =
        withContext(Dispatchers.IO) {
            if (ids.isEmpty()) emptyList() else dao.getByIds(ids).sortedBy { ids.indexOf(it.id) }
        }

    suspend fun getById(id: Long): QuestionEntity? = withContext(Dispatchers.IO) { dao.getById(id) }

    /**
     * Fetches real past questions from ALOC and caches them locally.
     * Never invents questions: if the service returns nothing usable, nothing is stored
     * and the caller receives a safe, user-presentable error.
     */
    suspend fun fetch(apiKey: String, subject: String, customCode: String?, year: String? = null): FetchOutcome =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) throw AlocError.NoKey

            val candidates = buildList {
                customCode?.trim()?.takeIf { it.isNotEmpty() }?.let { add(it) }
                val def = SubjectCatalogue.byId[subject]
                if (def != null) {
                    add(def.defaultAlocCode)
                    addAll(def.altAlocCodes)
                }
                add(subject)
            }.distinct()

            var lastError: AlocError = AlocError.Empty
            var anySuccessResponse = false

            for (code in candidates) {
                // 1) Primary endpoint
                val primaryOutcome = runCatching { client.fetchPrimary(apiKey, code, year) }
                if (primaryOutcome.isSuccess) {
                    anySuccessResponse = true
                    val parsed = client.parse(primaryOutcome.getOrThrow())
                    if (parsed.isNotEmpty()) {
                        return@withContext store(subject, parsed, "ALOC v1 ($code)")
                    }
                } else {
                    val e = primaryOutcome.exceptionOrNull()
                    if (e is AlocError) {
                        lastError = e
                        // Hard failures that are not subject-specific: stop immediately.
                        if (e is AlocError.Unauthorized || e is AlocError.Forbidden ||
                            e is AlocError.RateLimited || e is AlocError.NoNetwork
                        ) throw e
                    }
                }

                // 2) Fallback endpoint
                val fallbackOutcome = runCatching { client.fetchFallback(apiKey, code) }
                if (fallbackOutcome.isSuccess) {
                    anySuccessResponse = true
                    val parsed = client.parse(fallbackOutcome.getOrThrow())
                    if (parsed.isNotEmpty()) {
                        return@withContext store(subject, parsed, "ALOC v2 ($code)")
                    }
                } else {
                    val e = fallbackOutcome.exceptionOrNull()
                    if (e is AlocError) {
                        lastError = e
                        if (e is AlocError.Unauthorized || e is AlocError.Forbidden ||
                            e is AlocError.RateLimited || e is AlocError.NoNetwork
                        ) throw e
                    }
                }
            }

            if (!anySuccessResponse) throw lastError
            throw AlocError.Empty
        }

    private suspend fun store(subject: String, dtos: List<AlocQuestionDto>, source: String): FetchOutcome {
        val now = System.currentTimeMillis()
        val existing = dao.recent(subject, 4000).associateBy { it.fingerprint }.keys
        val entities = dtos.mapNotNull { dto ->
            val fp = SubjectCatalogue.sha256("${dto.subject ?: subject}|${dto.question.trim().lowercase()}")
            if (fp in existing) null
            else QuestionEntity(
                fingerprint = fp,
                subject = subject,
                year = dto.year,
                examType = dto.examType,
                source = dto.source ?: source,
                questionText = dto.question.trim(),
                optionsJson = Json.writeStringList(dto.options),
                answerIndex = dto.answerIndex,
                explanation = dto.explanation,
                fetchedAt = now
            )
        }
        val before = dao.countBySubject(subject)
        if (entities.isNotEmpty()) dao.insertAll(entities)
        val after = dao.countBySubject(subject)
        return FetchOutcome(subject, after - before, before, source)
    }

    companion object {
        const val MOCK_ENGLISH_COUNT = 60
        const val MOCK_OTHER_COUNT = 40
        const val MOCK_DURATION_MINUTES = 120
        const val MOCK_MAX_TOTAL = 400.0
    }
}
