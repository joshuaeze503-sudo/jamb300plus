package ng.jamb.threehundredplus.data

import com.squareup.moshi.JsonReader
import com.squareup.moshi.JsonWriter
import okio.Buffer

/** Small Moshi-backed JSON helpers. Nothing here throws on malformed input. */
object Json {

    fun writeStringList(list: List<String>): String {
        val buffer = Buffer()
        JsonWriter.of(buffer).use { w -> w.beginArray(); list.forEach { w.value(it) }; w.endArray() }
        return buffer.readUtf8()
    }

    fun readStringList(raw: String?): List<String> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val reader = JsonReader.of(Buffer().writeUtf8(raw))
            reader.isLenient = true
            val out = ArrayList<String>()
            if (reader.peek() == JsonReader.Token.BEGIN_ARRAY) {
                reader.beginArray()
                while (reader.hasNext()) {
                    out.add(
                        when (reader.peek()) {
                            JsonReader.Token.STRING, JsonReader.Token.NUMBER, JsonReader.Token.BOOLEAN -> reader.nextString()
                            else -> { reader.skipValue(); "" }
                        }
                    )
                }
                reader.endArray()
            } else reader.skipValue()
            out.filter { it.isNotBlank() }
        } catch (_: Exception) { emptyList() }
    }

    /** {"1":"0","4":"2"} — questionId -> selected option index (as string keys). */
    fun writeIntMap(map: Map<Long, Int>): String {
        val buffer = Buffer()
        JsonWriter.of(buffer).use { w ->
            w.beginObject()
            map.forEach { (k, v) -> w.name(k.toString()).value(v) }
            w.endObject()
        }
        return buffer.readUtf8()
    }

    fun readIntMap(raw: String?): Map<Long, Int> {
        if (raw.isNullOrBlank()) return emptyMap()
        return try {
            val reader = JsonReader.of(Buffer().writeUtf8(raw))
            reader.isLenient = true
            val out = LinkedHashMap<Long, Int>()
            if (reader.peek() == JsonReader.Token.BEGIN_OBJECT) {
                reader.beginObject()
                while (reader.hasNext()) {
                    val key = reader.nextName()
                    val v = when (reader.peek()) {
                        JsonReader.Token.NUMBER -> reader.nextInt()
                        JsonReader.Token.STRING -> reader.nextString().toIntOrNull() ?: 0
                        else -> { reader.skipValue(); 0 }
                    }
                    key.toLongOrNull()?.let { out[it] = v }
                }
                reader.endObject()
            } else reader.skipValue()
            out
        } catch (_: Exception) { emptyMap() }
    }

    fun writeLongSet(set: Set<Long>): String {
        val buffer = Buffer()
        JsonWriter.of(buffer).use { w -> w.beginArray(); set.forEach { w.value(it) }; w.endArray() }
        return buffer.readUtf8()
    }

    fun readLongSet(raw: String?): Set<Long> {
        if (raw.isNullOrBlank()) return emptySet()
        return try {
            val reader = JsonReader.of(Buffer().writeUtf8(raw))
            reader.isLenient = true
            val out = LinkedHashSet<Long>()
            if (reader.peek() == JsonReader.Token.BEGIN_ARRAY) {
                reader.beginArray()
                while (reader.hasNext()) {
                    when (reader.peek()) {
                        JsonReader.Token.NUMBER, JsonReader.Token.STRING -> reader.nextString().toLongOrNull()?.let { out.add(it) }
                        else -> reader.skipValue()
                    }
                }
                reader.endArray()
            } else reader.skipValue()
            out
        } catch (_: Exception) { emptySet() }
    }

    /** {"mathematics":"72.5"} */
    fun writeDoubleMap(map: Map<String, Double>): String {
        val buffer = Buffer()
        JsonWriter.of(buffer).use { w ->
            w.beginObject()
            map.forEach { (k, v) -> w.name(k).value(v) }
            w.endObject()
        }
        return buffer.readUtf8()
    }

    fun readDoubleMap(raw: String?): Map<String, Double> {
        if (raw.isNullOrBlank()) return emptyMap()
        return try {
            val reader = JsonReader.of(Buffer().writeUtf8(raw))
            reader.isLenient = true
            val out = LinkedHashMap<String, Double>()
            if (reader.peek() == JsonReader.Token.BEGIN_OBJECT) {
                reader.beginObject()
                while (reader.hasNext()) {
                    val key = reader.nextName()
                    val v = when (reader.peek()) {
                        JsonReader.Token.NUMBER -> reader.nextDouble()
                        JsonReader.Token.STRING -> reader.nextString().toDoubleOrNull() ?: 0.0
                        else -> { reader.skipValue(); 0.0 }
                    }
                    out[key] = v
                }
                reader.endObject()
            } else reader.skipValue()
            out
        } catch (_: Exception) { emptyMap() }
    }

    /** Escapes a string for safe embedding in the exported backup document. */
    fun escape(s: String): String {
        val sb = StringBuilder(s.length + 16)
        s.forEach { c ->
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> if (c < ' ') sb.append("\\u%04x".format(c.code)) else sb.append(c)
            }
        }
        return sb.toString()
    }
}
