package ng.jamb.threehundredplus.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import ng.jamb.threehundredplus.domain.SubjectCatalogue
import ng.jamb.threehundredplus.ui.AppViewModel
import ng.jamb.threehundredplus.ui.InfoCard
import ng.jamb.threehundredplus.ui.Routes
import ng.jamb.threehundredplus.ui.StatTile

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FocusScreen(vm: AppViewModel, nav: NavHostController) {
    val focus by vm.focus.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val upcoming by vm.upcomingTasks.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Focus timer") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { p ->
        Column(
            Modifier.padding(p).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                clock(focus.remaining),
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center
            )
            Text(
                if (focus.mode == "SLOT") "Full slot session" else "Pomodoro session",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { if (focus.totalSeconds == 0) 0f else focus.elapsedSeconds / focus.totalSeconds.toFloat() },
                modifier = Modifier.fillMaxWidth().height(8.dp)
            )
            Spacer(Modifier.height(20.dp))

            if (focus.running) {
                OutlinedButton(
                    onClick = { vm.pauseFocus() },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)
                ) { Text("Pause") }
            } else if (focus.paused) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.resumeFocus() }, modifier = Modifier.weight(1f).heightIn(min = 52.dp)) {
                        Text("Resume")
                    }
                    OutlinedButton(onClick = { vm.stopFocus() }, modifier = Modifier.weight(1f).heightIn(min = 52.dp)) {
                        Text("Stop")
                    }
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { vm.startFocus(settings.selectedSubjects.firstOrNull(), null, 0L, "POMODORO") },
                        modifier = Modifier.weight(1f).heightIn(min = 52.dp)
                    ) { Text("Pomodoro 25m") }
                    Button(
                        onClick = { vm.startFocus(settings.selectedSubjects.firstOrNull(), null, 0L, "SLOT") },
                        modifier = Modifier.weight(1f).heightIn(min = 52.dp)
                    ) { Text("Full slot 60m") }
                }
            }

            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatTile("${focus.elapsedSeconds / 60}m", "Elapsed", Modifier.weight(1f))
                StatTile("${focus.totalSeconds / 60}m", "Target", Modifier.weight(1f), MaterialTheme.colorScheme.secondary)
            }

            Spacer(Modifier.height(18.dp))
            InfoCard(
                title = "Study time is saved",
                body = "Completed sessions are stored with the subject and topic so they count towards your streak, XP and " +
                    "the study-consistency part of your score estimate."
            )

            Spacer(Modifier.height(18.dp))
            Text("Start from a scheduled task", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            if (upcoming.isEmpty()) {
                Text(
                    "No scheduled tasks yet. Generate a schedule first.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(Modifier.height(240.dp)) {
                    items(upcoming.take(12), key = { it.id }) { task ->
                        Card(Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(task.topicTitle, style = MaterialTheme.typography.bodyMedium)
                                    Text(
                                        SubjectCatalogue.shortOf(task.subject),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                OutlinedButton(
                                    onClick = {
                                        vm.startFocus(task.subject, task.topicTitle, task.id, "SLOT")
                                    },
                                    modifier = Modifier.heightIn(min = 44.dp)
                                ) { Text("Start") }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun clock(seconds: Int): String = "%02d:%02d".format(seconds / 60, seconds % 60)
