package ng.jamb.threehundredplus.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "jamb_settings")

data class AppSettings(
    val onboardingDone: Boolean = false,
    val selectedSubjects: List<String> = listOf("use_of_english", "mathematics", "physics", "chemistry"),
    val targetScore: Int = 300,
    val themeMode: String = "DARK",
    val apiKey: String = "",
    val remoteConfigUrl: String = "",
    val reminderLeadMinutes: Int = 15,
    val remindersEnabled: Boolean = true,
    val slotTimes: List<String> = DEFAULT_SLOTS,
    val examDateOverride: String = "",
    val examDateEpochMs: Long = 0L,
    val cachedConfigJson: String = "",
    val includeApiKeyInBackup: Boolean = false
) {
    val darkTheme: Boolean get() = themeMode != "LIGHT"
    val hasApiKey: Boolean get() = apiKey.isNotBlank()

    companion object {
        val DEFAULT_SLOTS = listOf("06:00-07:00", "10:00-11:00", "13:00-14:00", "16:00-17:00", "19:00-20:00")
    }
}

class SettingsStore(private val context: Context) {

    private object Keys {
        val ONBOARDING = booleanPreferencesKey("onboarding_done")
        val SUBJECTS = stringSetPreferencesKey("selected_subjects")
        val TARGET = intPreferencesKey("target_score")
        val THEME = stringPreferencesKey("theme_mode")
        val API_KEY = stringPreferencesKey("aloc_api_key")
        val RC_URL = stringPreferencesKey("remote_config_url")
        val LEAD = intPreferencesKey("reminder_lead_minutes")
        val REMINDERS = booleanPreferencesKey("reminders_enabled")
        val SLOTS = stringPreferencesKey("slot_times")
        val EXAM_DATE_OVERRIDE = stringPreferencesKey("exam_date_override")
        val EXAM_DATE_MS = doublePreferencesKey("exam_date_ms")
        val CACHED_CONFIG = stringPreferencesKey("cached_config_json")
        val BACKUP_KEY = booleanPreferencesKey("include_api_key_in_backup")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { p ->
        val slots = p[Keys.SLOTS]
            ?.split("|")
            ?.map { it.trim() }
            ?.filter { it.contains("-") && it.length >= 11 }
            ?.takeIf { it.isNotEmpty() }
            ?: AppSettings.DEFAULT_SLOTS
        AppSettings(
            onboardingDone = p[Keys.ONBOARDING] ?: false,
            selectedSubjects = p[Keys.SUBJECTS]?.toList()?.sortedBy { it }
                ?: listOf("use_of_english", "mathematics", "physics", "chemistry"),
            targetScore = (p[Keys.TARGET] ?: 300).coerceIn(1, 400),
            themeMode = p[Keys.THEME] ?: "DARK",
            apiKey = p[Keys.API_KEY] ?: "",
            remoteConfigUrl = p[Keys.RC_URL] ?: "",
            reminderLeadMinutes = (p[Keys.LEAD] ?: 15).coerceIn(0, 120),
            remindersEnabled = p[Keys.REMINDERS] ?: true,
            slotTimes = slots,
            examDateOverride = p[Keys.EXAM_DATE_OVERRIDE] ?: "",
            examDateEpochMs = (p[Keys.EXAM_DATE_MS] ?: 0.0).toLong(),
            cachedConfigJson = p[Keys.CACHED_CONFIG] ?: "",
            includeApiKeyInBackup = p[Keys.BACKUP_KEY] ?: false
        )
    }

    suspend fun setOnboardingDone(v: Boolean) = edit { it[Keys.ONBOARDING] = v }
    suspend fun setSelectedSubjects(v: List<String>) = edit { it[Keys.SUBJECTS] = v.toSet() }
    suspend fun setTargetScore(v: Int) = edit { it[Keys.TARGET] = v.coerceIn(1, 400) }
    suspend fun setTheme(v: String) = edit { it[Keys.THEME] = v }
    suspend fun setApiKey(v: String) = edit { it[Keys.API_KEY] = v.trim() }
    suspend fun clearApiKey() = edit { it.remove(Keys.API_KEY) }
    suspend fun setRemoteConfigUrl(v: String) = edit { it[Keys.RC_URL] = v.trim() }
    suspend fun setReminderLead(v: Int) = edit { it[Keys.LEAD] = v.coerceIn(0, 120) }
    suspend fun setRemindersEnabled(v: Boolean) = edit { it[Keys.REMINDERS] = v }
    suspend fun setSlots(v: List<String>) = edit { it[Keys.SLOTS] = v.joinToString("|") }
    suspend fun setExamDateOverride(iso: String, epochMs: Long) = edit {
        it[Keys.EXAM_DATE_OVERRIDE] = iso
        it[Keys.EXAM_DATE_MS] = epochMs.toDouble()
    }
    suspend fun setCachedConfig(json: String) = edit { it[Keys.CACHED_CONFIG] = json }
    suspend fun setBackupIncludeKey(v: Boolean) = edit { it[Keys.BACKUP_KEY] = v }

    /** Used by Restore: writes every preference at once so restore is atomic. */
    suspend fun applyAll(s: AppSettings) = edit { p ->
        p[Keys.ONBOARDING] = s.onboardingDone
        p[Keys.SUBJECTS] = s.selectedSubjects.toSet()
        p[Keys.TARGET] = s.targetScore
        p[Keys.THEME] = s.themeMode
        p[Keys.RC_URL] = s.remoteConfigUrl
        p[Keys.LEAD] = s.reminderLeadMinutes
        p[Keys.REMINDERS] = s.remindersEnabled
        p[Keys.SLOTS] = s.slotTimes.joinToString("|")
        p[Keys.EXAM_DATE_OVERRIDE] = s.examDateOverride
        p[Keys.EXAM_DATE_MS] = s.examDateEpochMs.toDouble()
        p[Keys.CACHED_CONFIG] = s.cachedConfigJson
        p[Keys.BACKUP_KEY] = s.includeApiKeyInBackup
        // The API key is only ever written to settings by the user typing it, or by an
        // explicit opt-in restore from a backup the user themselves exported.
        if (s.apiKey.isNotBlank()) p[Keys.API_KEY] = s.apiKey
    }

    private suspend fun edit(block: (androidx.datastore.preferences.core.MutablePreferences) -> Unit) {
        context.dataStore.edit(block)
    }
}
