package ng.jamb.threehundredplus.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import ng.jamb.threehundredplus.data.Json
import ng.jamb.threehundredplus.data.db.QuestionEntity
import ng.jamb.threehundredplus.domain.SubjectCatalogue
import ng.jamb.threehundredplus.ui.AppViewModel
import ng.jamb.threehundredplus.ui.EmptyState
import ng.jamb.threehundredplus.ui.InfoCard
import ng.jamb.threehundredplus.ui.Pill
import ng.jamb.threehundredplus.ui.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PracticeScreen(vm: AppViewModel, nav: NavHostController) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val practice by vm.practice.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()

    if (practice != null) {
        PracticeRunner(vm = vm, nav = nav)
        return
    }

    var subject by remember { mutableStateOf(settings.selectedSubjects.getOrNull(1) ?: "use_of_english") }
    var years by remember { mutableStateOf<List<String>>(emptyList()) }
    var year by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf(false) }
    var missingKeyDialog by remember { mutableStateOf(false) }

    val count by vm.questionCount(subject).collectAsStateWithLifecycle(initialValue = 0)
    LaunchedEffect(subject) {
        years = emptyList()
        year = null
        runCatching { vm.yearsFor(subject) }.onSuccess { years = it }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Practice") }) }
    ) { p ->
        LazyColumn(
            modifier = Modifier.padding(p).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("Subject", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    settings.selectedSubjects.forEach { s ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .clickable { subject = s }
                        ) {
                            if (subject == s) {
                                Icon(Icons.Filled.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(8.dp))
                            }
                            Text(SubjectCatalogue.nameOf(s), style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
            }

            item {
                Text("Cached questions: $count", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            item {
                OutlinedButton(
                    onClick = {
                        if (!settings.hasApiKey) missingKeyDialog = true
                        else vm.fetchQuestions(subject)
                    },
                    enabled = !busy.loading,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) { Text(if (busy.loading) "Fetching…" else "Fetch more real questions") }
            }

            item {
                Text("Year filter", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                if (years.isEmpty()) {
                    Text(
                        "Year filters appear here only when the questions you have downloaded carry real year metadata.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("All", year == null) { year = null }
                        years.forEach { y -> Pill(y, year == y) { year = if (year == y) null else y } }
                    }
                }
            }

            item {
                if (count == 0) {
                    EmptyState(
                        title = "No cached questions for ${SubjectCatalogue.shortOf(subject)}",
                        body = "Add your ALOC API key, then fetch real past questions. The app never invents questions, " +
                            "so this section stays empty until real data is downloaded.",
                        actionLabel = "Question source",
                        onAction = { nav.navigate(Routes.SETTINGS) }
                    )
                } else {
                    Button(
                        onClick = { confirm = true },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)
                    ) { Text("Start untimed practice") }
                }
            }

            item {
                InfoCard(
                    title = "Untimed practice",
                    body = "Practice uses whatever real questions are already cached for the subject. There is no timer and " +
                        "no scoring limit — wrong answers are added to your mistake notebook for spaced review."
                )
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Start practice?") },
            text = {
                Text(
                    if (year == null) "Up to 40 cached ${SubjectCatalogue.nameOf(subject)} questions, untimed."
                    else "Cached $year questions for ${SubjectCatalogue.nameOf(subject)}, untimed."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false
                    vm.startPractice(subject, year, 40)
                }) { Text("Start") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
        )
    }

    if (missingKeyDialog) {
        AlertDialog(
            onDismissRequest = { missingKeyDialog = false },
            title = { Text("API key needed") },
            text = { Text("Add your ALOC API key before downloading past questions. It is stored only on this device.") },
            confirmButton = {
                TextButton(onClick = { missingKeyDialog = false; nav.navigate(Routes.SETTINGS) }) { Text("Open settings") }
            },
            dismissButton = { TextButton(onClick = { missingKeyDialog = false }) { Text("Not now") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PracticeRunner(vm: AppViewModel, nav: NavHostController) {
    val state by vm.practice.collectAsStateWithLifecycle()
    val st = state ?: return
    val q = st.questions.getOrNull(st.index)
    var showPalette by remember { mutableStateOf(false) }
    var showFinish by remember { mutableStateOf(false) }

    if (st.finished) {
        val correct = st.questions.count { q2 -> st.answers[q2.id] != null && st.answers[q2.id] == q2.answerIndex }
        val answered = st.questions.count { st.answers[it.id] != null }
        Scaffold(
            topBar = { TopAppBar(title = { Text("Practice result") }) }
        ) { p ->
            Column(
                Modifier.padding(p).padding(16.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("$correct correct out of $answered answered", style = MaterialTheme.typography.headlineSmall)
                Text(
                    "${st.questions.size - answered} questions were left blank. Blank answers are not scored as wrong.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(
                    onClick = { vm.endPractice(); nav.popBackStack() },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) { Text("Back to practice") }
            }
        }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("${st.index + 1} / ${st.questions.size}") },
                navigationIcon = {
                    IconButton(onClick = { vm.endPractice(); nav.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    TextButton(onClick = { showPalette = true }) { Text("Palette") }
                }
            )
        }
    ) { p ->
        Column(
            Modifier
                .padding(p)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            LinearProgressIndicator(
                progress = { if (st.questions.isEmpty()) 0f else (st.index + 1) / st.questions.size.toFloat() },
                modifier = Modifier.fillMaxWidth().height(6.dp)
            )
            Spacer(Modifier.height(12.dp))
            if (q == null) {
                Text("No questions loaded.").also { vm.endPractice() }
                return@Column
            }

            Text(q.questionText, style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(8.dp))
            MetaLine(q)

            Spacer(Modifier.height(14.dp))
            val options = Json.readStringList(q.optionsJson)
            options.forEachIndexed { i, opt ->
                val selected = st.answers[q.id] == i
                val revealed = q.id in st.revealed
                val isCorrect = q.answerIndex == i
                val bg = when {
                    revealed && isCorrect -> MaterialTheme.colorScheme.secondaryContainer
                    revealed && selected && !isCorrect -> MaterialTheme.colorScheme.errorContainer
                    selected -> MaterialTheme.colorScheme.primaryContainer
                    else -> MaterialTheme.colorScheme.surfaceContainerHigh
                }
                Card(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 52.dp)
                        .padding(vertical = 4.dp)
                        .clickable { vm.answerPractice(q.id, i) },
                    colors = CardDefaults.cardColors(containerColor = bg)
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            ('A'.code + i).toString() + ".",
                            style = MaterialTheme.typography.titleSmall,
                            modifier = Modifier.width(28.dp)
                        )
                        Text(opt, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        if (revealed && isCorrect) {
                            Icon(Icons.Filled.CheckCircle, contentDescription = "Correct", tint = MaterialTheme.colorScheme.secondary)
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            if (q.explanation != null && q.id in st.revealed) {
                InfoCard(
                    title = "Explanation (from ${q.source ?: "the question source"})",
                    body = q.explanation
                )
                Spacer(Modifier.height(12.dp))
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { vm.revealPractice(q.id) },
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                ) { Text("Reveal") }
                OutlinedButton(
                    onClick = { vm.flagPractice(q.id) },
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                ) { Text(if (q.id in st.flags) "Unflag" else "Flag") }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { vm.jumpPractice(st.index - 1) },
                    enabled = st.index > 0,
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                ) { Text("Previous") }
                if (st.index < st.questions.size - 1) {
                    Button(
                        onClick = { vm.jumpPractice(st.index + 1) },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                    ) { Text("Next") }
                } else {
                    Button(
                        onClick = { showFinish = true },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                    ) { Text("Finish") }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showPalette) {
        AlertDialog(
            onDismissRequest = { showPalette = false },
            title = { Text("Question palette") },
            text = {
                LazyColumn(Modifier.height(320.dp)) {
                    items(st.questions.size) { i ->
                        val qq = st.questions[i]
                        val answered = st.answers.containsKey(qq.id)
                        val flagged = qq.id in st.flags
                        TextButton(
                            onClick = { vm.jumpPractice(i); showPalette = false },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                        ) {
                            Text(
                                "${i + 1} ${if (answered) "✓" else "·"} ${if (flagged) "⚑" else ""}",
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPalette = false }) { Text("Close") } }
        )
    }

    if (showFinish) {
        AlertDialog(
            onDismissRequest = { showFinish = false },
            title = { Text("Finish practice?") },
            text = { Text("Unanswered questions will be left blank. Wrong answers go to your mistake notebook.") },
            confirmButton = {
                TextButton(onClick = { showFinish = false; vm.submitPractice() }) { Text("Submit") }
            },
            dismissButton = { TextButton(onClick = { showFinish = false }) { Text("Keep going") } }
        )
    }
}

@Composable
fun MetaLine(q: QuestionEntity) {
    val bits = buildList {
        q.year?.let { add("Year $it") }
        q.examType?.let { add(it) }
        q.source?.let { add("Source: $it") }
    }
    if (bits.isEmpty()) {
        Text(
            "This question carries no year, exam type or source metadata from the provider.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    } else {
        Text(
            bits.joinToString(" • "),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
