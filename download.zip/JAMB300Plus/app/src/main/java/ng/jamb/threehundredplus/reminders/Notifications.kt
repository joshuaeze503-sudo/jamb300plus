package ng.jamb.threehundredplus.reminders

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import ng.jamb.threehundredplus.MainActivity
import ng.jamb.threehundredplus.R

object Notifications {
    const val CHANNEL_SLOTS = "study_slots"
    const val CHANNEL_MISC = "misc"

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        val slot = NotificationChannel(
            CHANNEL_SLOTS,
            "Study slot reminders",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Alerts before each scheduled study slot"
            enableVibration(true)
        }
        val misc = NotificationChannel(
            CHANNEL_MISC,
            "General updates",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply { description = "Other app notifications" }
        nm.createNotificationChannel(slot)
        nm.createNotificationChannel(misc)
    }

    fun canPost(context: Context): Boolean = NotificationManagerCompat.from(context).areNotificationsEnabled()

    fun show(context: Context, id: Int, title: String, body: String, deepLink: String?) {
        if (!canPost(context)) return
        ensureChannels(context)
        val open = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(MainActivity.EXTRA_DEEP_LINK, deepLink)
        }
        val contentPi = PendingIntent.getActivity(
            context, id, open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val start = actionIntent(context, ReminderScheduler.ACTION_START, id, title, body, deepLink)
        val snooze = actionIntent(context, ReminderScheduler.ACTION_SNOOZE, id, title, body, deepLink)
        val skip = actionIntent(context, ReminderScheduler.ACTION_SKIP, id, title, body, deepLink)

        val builder = NotificationCompat.Builder(context, CHANNEL_SLOTS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(contentPi)
            .addAction(0, "Start", start)
            .addAction(0, "Snooze 10 min", snooze)
            .addAction(0, "Skip", skip)

        try {
            NotificationManagerCompat.from(context).notify(id, builder.build())
        } catch (_: SecurityException) {
            // POST_NOTIFICATIONS not granted: nothing to do, the app stays usable.
        }
    }

    private fun actionIntent(
        context: Context,
        action: String,
        id: Int,
        title: String,
        body: String,
        deepLink: String?
    ): PendingIntent {
        val intent = Intent(context, ActionReceiver::class.java).apply {
            this.action = action
            putExtra(ReminderScheduler.EXTRA_ID, id)
            putExtra(ReminderScheduler.EXTRA_TITLE, title)
            putExtra(ReminderScheduler.EXTRA_BODY, body)
            putExtra(ReminderScheduler.EXTRA_DEEP_LINK, deepLink)
        }
        return PendingIntent.getBroadcast(
            context,
            id * 10 + action.hashCode().and(0xFF),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun cancel(context: Context, id: Int) {
        try { NotificationManagerCompat.from(context).cancel(id) } catch (_: Exception) { }
    }
}
