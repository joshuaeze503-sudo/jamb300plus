package ng.jamb.threehundredplus.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import ng.jamb.threehundredplus.data.net.RemoteConfigService
import ng.jamb.threehundredplus.data.prefs.AppSettings
import ng.jamb.threehundredplus.domain.SubjectCatalogue
import ng.jamb.threehundredplus.reminders.ReminderScheduler
import ng.jamb.threehundredplus.ui.AppViewModel
import ng.jamb.threehundredplus.ui.InfoCard
import ng.jamb.threehundredplus.ui.Routes
import ng.jamb.threehundredplus.ui.SectionTitle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: AppViewModel, nav: NavHostController) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var keyDialog by remember { mutableStateOf(false) }
    var resetDialog by remember { mutableStateOf(false) }
    var slotDialog by remember { mutableStateOf(false) }

    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* the UI reflects the real state on resume */ }

    var notificationsGranted by remember { mutableStateOf(true) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? -> if (uri != null) vm.exportBackup(uri) {} }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> if (uri != null) vm.importBackup(uri) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { p ->
        LazyColumn(
            modifier = Modifier.padding(p).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { SectionTitle("Appearance") }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Dark theme", Modifier.weight(1f))
                    Switch(
                        checked = settings.darkTheme,
                        onCheckedChange = { vm.setTheme(if (it) "DARK" else "LIGHT") }
                    )
                }
            }

            item { SectionTitle("Goal") }
            item {
                var targetText by remember(settings.targetScore) { mutableStateOf(settings.targetScore.toString()) }
                OutlinedTextField(
                    value = targetText,
                    onValueChange = { targetText = it.filter { c -> c.isDigit() }.take(3) },
                    label = { Text("Target score (1-400)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { targetText.toIntOrNull()?.let { vm.setTarget(it) } },
                    modifier = Modifier.heightIn(min = 48.dp)
                ) { Text("Save target") }
            }

            item { SectionTitle("Question source (ALOC)") }
            item {
                InfoCard(
                    title = if (settings.hasApiKey) "API key saved on this device" else "No API key set",
                    body = if (settings.hasApiKey) {
                        "The key is stored only in this app's local settings and is never included in a backup unless you " +
                            "explicitly opt in below."
                    } else {
                        "Past questions are supplied by ALOC using your own API key. JAMB 300+ never bundles a key and " +
                            "never generates questions."
                    },
                    actionLabel = if (settings.hasApiKey) "Change key" else "Add key",
                    onAction = { keyDialog = true }
                )
            }
            if (settings.hasApiKey) {
                item {
                    OutlinedButton(
                        onClick = { vm.clearApiKey() },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                    ) { Text("Remove API key") }
                }
            }
            item {
                OutlinedButton(
                    onClick = {
                        val url = "https://aloc.com.ng"
                        runCatching {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                        }
                    },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) { Text("Get free key (opens browser)") }
            }

            item { SectionTitle("ALOC subject codes") }
            item {
                Text(
                    "These codes are sent as the subject parameter when downloading questions. Change one if your key uses " +
                        "a different code.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            items(settings.selectedSubjects) { s ->
                var code by remember(s, settings.selectedSubjects) { mutableStateOf(SubjectCatalogue.defaultCode(s)) }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = code,
                        onValueChange = { code = it },
                        label = { Text(SubjectCatalogue.shortOf(s)) },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { vm.setSubjectCode(s, code) },
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) { Text("Save") }
                }
            }

            item { SectionTitle("Study slots") }
            item {
                InfoCard(
                    title = "Current slots",
                    body = settings.slotTimes.joinToString("\n") { "• $it" },
                    actionLabel = "Edit slot times",
                    onAction = { slotDialog = true }
                )
            }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Slot reminders", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "Alerts before each slot",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = settings.remindersEnabled, onCheckedChange = { vm.setReminders(it) })
                }
            }
            item {
                Text("Reminder lead time: ${settings.reminderLeadMinutes} minutes", style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(5, 15, 30, 60).forEach { m ->
                        OutlinedButton(
                            onClick = { vm.setLead(m) },
                            modifier = Modifier.heightIn(min = 44.dp)
                        ) { Text("${m}m") }
                    }
                }
            }

            item { SectionTitle("Permissions and reminders") }
            item {
                PermissionCard(
                    title = "Notifications",
                    body = "Android 13 and newer require your permission before reminders can be shown.",
                    granted = notificationsGranted,
                    actionLabel = "Grant",
                    onAction = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            ReminderScheduler.notificationSettingsIntent(context)
                                ?.let { runCatching { context.startActivity(it) } }
                        }
                    }
                )
            }
            item {
                val exact = ReminderScheduler.canScheduleExact(context)
                PermissionCard(
                    title = "Exact alarms",
                    body = if (exact) {
                        "Reminders fire at the exact minute you chose."
                    } else {
                        "Exact alarms are not permitted on this device. Reminders still work, but the system may deliver " +
                            "them a few minutes late. You can grant this in Android settings."
                    },
                    granted = exact,
                    actionLabel = "Open Settings",
                    onAction = {
                        ReminderScheduler.exactAlarmSettingsIntent(context)
                            ?.let { runCatching { context.startActivity(it) } }
                    }
                )
            }
            item {
                OutlinedButton(
                    onClick = { nav.navigate(Routes.FIX_REMINDERS) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) { Text("Reminders not showing?") }
            }

            item { SectionTitle("Configuration source") }
            item {
                var url by remember(settings.remoteConfigUrl) { mutableStateOf(settings.remoteConfigUrl) }
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("https:// config URL") },
                    placeholder = { Text("https://example.org/jamb.json") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { vm.setRemoteConfigUrl(url) },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                    ) { Text("Save URL") }
                    Button(
                        onClick = {
                            vm.setRemoteConfigUrl(url)
                            vm.fetchRemoteConfig()
                        },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                    ) { Text("Fetch") }
                }
            }
            item {
                val cached = settings.cachedConfigJson
                InfoCard(
                    title = "Cached configuration",
                    body = if (cached.isBlank()) {
                        "Nothing cached. Exam date and any other values show as “${RemoteConfigService.UNCONFIRMED}” until a " +
                            "configuration source supplies them."
                    } else cached,
                    container = MaterialTheme.colorScheme.surfaceContainer
                )
            }
            item {
                Text(
                    "This app does not treat any configuration source as official JAMB data unless the source is controlled " +
                        "by JAMB. Always confirm dates, fees and the syllabus on jamb.gov.ng.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            item { SectionTitle("Backup") }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Include API key in backup", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "Off by default. Keep it off unless you are moving your own install to another device.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = settings.includeApiKeyInBackup, onCheckedChange = { vm.setBackupIncludeKey(it) })
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { exportLauncher.launch("jamb300plus-backup.json") },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                    ) { Text("Export") }
                    OutlinedButton(
                        onClick = { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                    ) { Text("Restore") }
                }
            }

            item { SectionTitle("More") }
            item {
                OutlinedButton(
                    onClick = { nav.navigate(Routes.UPDATES) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) { Text("Official updates") }
            }
            item {
                OutlinedButton(
                    onClick = { nav.navigate(Routes.ABOUT) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) { Text("About") }
            }
            item {
                OutlinedButton(
                    onClick = { resetDialog = true },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) { Text("Reset app data") }
            }
            item { Spacer(Modifier.height(30.dp)) }
        }
    }

    if (keyDialog) {
        var key by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { keyDialog = false },
            title = { Text("ALOC API key") },
            text = {
                Column {
                    Text(
                        "Paste the key from your own ALOC account. It is saved on this device only.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = key,
                        onValueChange = { key = it },
                        label = { Text("API key") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (key.isNotBlank()) vm.setApiKey(key)
                    keyDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { keyDialog = false }) { Text("Cancel") } }
        )
    }

    if (slotDialog) {
        SlotDialog(
            initial = settings.slotTimes,
            onDismiss = { slotDialog = false },
            onSave = { vm.setSlots(it); slotDialog = false }
        )
    }

    if (resetDialog) {
        AlertDialog(
            onDismissRequest = { resetDialog = false },
            title = { Text("Reset all app data?") },
            text = {
                Text(
                    "This deletes your topics progress, schedule, cached questions, mocks, mistakes and study history. " +
                        "It cannot be undone."
                )
            },
            confirmButton = {
                TextButton(onClick = { resetDialog = false; vm.resetEverything() }) { Text("Reset everything") }
            },
            dismissButton = { TextButton(onClick = { resetDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun PermissionCard(
    title: String,
    body: String,
    granted: Boolean,
    actionLabel: String,
    onAction: () -> Unit
) {
    InfoCard(
        title = "$title — ${if (granted) "allowed" else "not granted"}",
        body = body,
        container = if (granted) MaterialTheme.colorScheme.surfaceContainerHigh
        else MaterialTheme.colorScheme.errorContainer,
        actionLabel = if (granted) null else actionLabel,
        onAction = if (granted) null else onAction
    )
}

@Composable
private fun SlotDialog(initial: List<String>, onDismiss: () -> Unit, onSave: (List<String>) -> Unit) {
    var text by remember { mutableStateOf(initial.joinToString("\n")) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Slot times") },
        text = {
            Column {
                Text(
                    "One slot per line in the form 06:00-07:00. Sunday slots are always revision or practice only.",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("Slots") },
                    minLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val parsed = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
                    .filter { slot ->
                        val parts = slot.split("-")
                        parts.size == 2 &&
                            parts[0].split(":").size == 2 && parts[1].split(":").size == 2 &&
                            runCatching {
                                val s = parts[0].split(":").map { it.trim().toInt() }
                                val e = parts[1].split(":").map { it.trim().toInt() }
                                s[0] in 0..23 && s[1] in 0..59 && e[0] in 0..23 && e[1] in 0..59
                            }.getOrDefault(false)
                    }
                if (parsed.isNotEmpty()) onSave(parsed) else onDismiss()
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
